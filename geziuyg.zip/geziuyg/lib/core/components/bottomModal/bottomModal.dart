import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/button/icon_text_button.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
class radioModel {
  String name;
  int index;
  radioModel({this.name, this.index});
}
Widget bottomModal({
  BuildContext context,
  String toptext,
  String title,
  String store_id,
  String code,
  Icon icon,
  String image,
  String buttonType,
  GestureTapCallback onTap,
  double leftPadding,
  double topPadding,
  double topMargin,
  Color backgroundColor,
  Color textColor,
  Color buttonColor,
  Function onClickAction,
  String favorite,
  List worktypefList,
  model,
}) {

  return Container(
    height: MediaQuery.of(context).size.height * 0.95,
    color: Colors.transparent, //could change this to Color(0xFF737373),
    //so you don't have to change MaterialApp canvasColor
    child: new Container(
        decoration: new BoxDecoration(
            color: backgroundColor !=null ? backgroundColor : Colors.white,
            borderRadius: new BorderRadius.only(
                topLeft: const Radius.circular(10.0),
                topRight: const Radius.circular(10.0)
            )
        ),
        child:Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                    padding: EdgeInsets.only(left:20,top: 10.0,right: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child:Text(
                        toptext,
                        style: TextStyle(
                            color: Color(0xFF808080),
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                    )
                ),
                Padding(
                    padding: EdgeInsets.only(top: 10.0,right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child:GestureDetector(
                        onTap: (){
                          print("skip v");
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.close,
                          color: Colors.grey,
                          size: 30.0,
                        ),
                      ),
                    )
                ),
              ],
            ),
            SizedBox(height: 20,),
            Container(
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20.0,right: 20),
                child: Text(
                  title,
                  textAlign: TextAlign.left,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: textColor !=null ? textColor : Colors.black,
                      fontWeight: FontWeight.w700,
                      fontSize: 20),
                )
            ),
            SizedBox(height: 10,),
            Row(
                children: <Widget>[
                  Expanded(
                    child: new Container(
                        margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Divider(
                          color: Color(0xFFDBDBDB),
                          height: 5,
                        )),
                  ),
                ]
            ),
            SizedBox(height: 10,),
            Container(
                margin: EdgeInsets.only(left:0,right: 10),
                // padding: EdgeInsets.on(10),
                width: MediaQuery.of(context).size.width * 0.90,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.48,
                          margin: EdgeInsets.only(left:0,bottom:15),
                          child: Column(
                            children:
                            worktypefList.map((data) => Theme(
                                data: Theme.of(context).copyWith(
                                  unselectedWidgetColor: Color(0xffBF0025),
                                  disabledColor: Color(0xffBF0025),
                                ),
                                child:RadioListTile(
                                  title: Text("${data.name}"),
                                  groupValue: model.worktypeid,
                                  value: data.index,
                                  onChanged: (val) {
                                    print("val ${val}");
                                    print("data.index ${data.index}");
                                    print("data.name ${data.name}");
                                    // setState(() {
                                    //   worktyperadioItem = data.name ;
                                    //   worktypeid = data.index;
                                    // });
                                    model.changeworktype(data.index,data.name);
                                  },
                                ))).toList(),
                          ),
                        )
                    ),
                  ],
                )
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Align(
                    alignment: FractionalOffset.center,
                    child: Container(
                      margin: const EdgeInsets.only(left: 10.0),
                      height: 45,
                      width: MediaQuery.of(context).size.width * 0.6,
                      child: FlatButton(
                          padding: EdgeInsets.all(7.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.0),
                            // side: BorderSide(color: buttonColor !=null ? buttonColor :Color(0xFFF2F2F2))
                          ),
                          onPressed: () {
                            print("copyToClipBoard1");
                            // Clipboard.setData(new ClipboardData(text: code));
                            // locator<DialogService>().showToast(title: "Copy Successful");
                            onClickAction("deneme","used");
                            Navigator.pop(context);
                          },
                          color: buttonColor,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              Text(
                                  code,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 17.0,
                                      fontWeight: FontWeight.w400
                                  )
                              )
                            ],
                          ),
                      ),
                    )
                )
              ],
            )
          ],
        )
    ),
  );
}