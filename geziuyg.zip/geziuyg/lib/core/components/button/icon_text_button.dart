import 'package:flutter/material.dart';

class IconTextButton extends StatelessWidget {
  final Widget child;
  final Icon icon;
  final double sizedboxWidth;
  final double fontSize;
  final String text;
  final Color buttonColor;
  final Color textColor;
  final Color backgroundColor;
  final String favorite;

  final VoidCallback onPressed;

  const IconTextButton({Key key,
    this.child,
    this.onPressed,
    this.icon,
    this.text,
    this.sizedboxWidth,
    this.backgroundColor,
    this.buttonColor,
    this.textColor,
    this.fontSize,
    this.favorite,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    if(favorite=="1"){
      return FlatButton(
          padding: EdgeInsets.all(7.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
            // side: BorderSide(color: buttonColor !=null ? buttonColor :Color(0xFFF2F2F2))
          ),
          onPressed: onPressed,
          color: textColor,
          textColor: buttonColor,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              icon !=null ? icon : Text(""),
              sizedboxWidth !=null ? SizedBox(width: sizedboxWidth,) : SizedBox(width: 0,),
              Text(
                  text !=null ? text : "empty",
                  style: TextStyle(fontSize: fontSize !=null ? fontSize : 14,color: buttonColor)
              ),
            ],
          )
      );
    }else{
      return FlatButton(
          padding: EdgeInsets.all(7.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
            // side: BorderSide(color: buttonColor !=null ? buttonColor :Color(0xFFF2F2F2))
          ),
          onPressed: onPressed,
          color: text =="ARA" || text=="CEVAPLA" ? Colors.red :buttonColor,
          textColor: text =="ARA" || text=="CEVAPLA" ? Colors.white : textColor,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              icon !=null ? icon : Text(""),
              sizedboxWidth !=null ? SizedBox(width: sizedboxWidth,) : SizedBox(width: 0,),
              Text(
                  text !=null ? text : "empty",
                  style: TextStyle(fontSize: fontSize !=null ? fontSize : 14,color: text =="ARA" || text=="CEVAPLA" ? Colors.white :textColor)
              ),
              text =="ARA" || text=="CEVAPLA" ? Transform.rotate(
                angle: 180,
                child:Icon(Icons.call,color: Colors.white)) : SizedBox(width: 0,),
            ],
          )
      );
    }

  }
}
