import 'package:flutter/material.dart';

class NotFoundNavigationWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('Not Found'),
    );
  }
}
