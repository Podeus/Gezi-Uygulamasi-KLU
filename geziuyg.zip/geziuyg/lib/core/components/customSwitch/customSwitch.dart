import 'dart:math';
import 'package:flutter/material.dart';
import 'package:simple_animations/simple_animations.dart';
import 'package:supercharged/supercharged.dart';
enum _SwitchBoxProps { paddingLeft, color, text, rotation }


class CustomSwitch extends StatelessWidget {
  final bool switched;

  CustomSwitch({this.switched});

  @override
  Widget build(BuildContext context) {
    var tween = MultiTween<_SwitchBoxProps>()
      ..add(_SwitchBoxProps.paddingLeft, 0.0.tweenTo(20.0), 500.milliseconds)
      ..add(_SwitchBoxProps.color, Color(0xFFE5E5E5).tweenTo(Color(0xFF26B13C)), 500.milliseconds)
      ..add(_SwitchBoxProps.text, ConstantTween("OFF"), 500.milliseconds)
      ..add(_SwitchBoxProps.text, ConstantTween("ON"), 500.milliseconds)
      ..add(_SwitchBoxProps.rotation, (-2 * pi).tweenTo(0.0), 500.milliseconds);

    return CustomAnimation<MultiTweenValues<_SwitchBoxProps>>(
      control: switched
          ? CustomAnimationControl.PLAY
          : CustomAnimationControl.PLAY_REVERSE,
      startPosition: switched ? 1.0 : 0.0,
      duration: tween.duration * 1.2,
      tween: tween,
      curve: Curves.easeInOut,
      builder: _buildSwitchBox,
    );
  }

  Widget _buildSwitchBox(
      context, child, MultiTweenValues<_SwitchBoxProps> value) {
    return Container(
      decoration: new BoxDecoration(
        color: value.get(_SwitchBoxProps.color),
        borderRadius: new BorderRadius.all(Radius.circular(15.0),),
      ),
      width: 50,
      height: 30,
      padding: const EdgeInsets.all(3.0),
      child: Stack(
        children: [
          Positioned(
              child: Padding(
                padding: EdgeInsets.only(left: value.get(_SwitchBoxProps.paddingLeft)),
                child: Transform.rotate(
                  angle: value.get(_SwitchBoxProps.rotation),
                  child: Container(
                      decoration: new BoxDecoration(
                        color: Color(0xFFFFFFFF),
                        borderRadius: new BorderRadius.only(
                            topLeft: const Radius.circular(10.0),
                            topRight: const Radius.circular(10.0),
                            bottomLeft: const Radius.circular(10.0),
                            bottomRight: const Radius.circular(10.0)
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(1),
                            spreadRadius: 0,
                            blurRadius: 0,
                            offset: Offset(0, 0), // changes position of shadow
                          ),
                        ],
                      ),
                      margin: EdgeInsets.all(2),
                      width: 20,
                      height: 20,
                      child: Text("")
                  ),
                ),
              ))
        ],
      ),
    );
  }

  BoxDecoration _innerBoxDecoration(Color color) => BoxDecoration(
      borderRadius: BorderRadius.all(Radius.circular(25)), color: color);

  BoxDecoration _outerBoxDecoration(Color color) => BoxDecoration(
    borderRadius: BorderRadius.all(Radius.circular(30)),
    border: Border.all(
      width: 2,
      color: color,
    ),
  );

  static final labelStyle = TextStyle(
      height: 1.3,
      fontWeight: FontWeight.bold,
      fontSize: 12,
      color: Colors.white);
}