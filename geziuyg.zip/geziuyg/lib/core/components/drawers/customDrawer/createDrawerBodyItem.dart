import 'package:flutter/material.dart';
Widget createDrawerBodyItem({
  Icon icon,
  String image,
  String image2,
  String text,
  GestureTapCallback onTap,
  double leftPadding,
  double topPadding,
  double topMargin,
  double leftMargin,
  int active,
  Color textColor,
  bool bottomDivider,
  bool bottombigDivider
}) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        height: 30.0,
        padding: EdgeInsets.only(left:5),
        // margin: EdgeInsets.only(top:topMargin !=null ? topMargin : 0,left:leftMargin !=null ? leftMargin : 0,right:leftMargin !=null ? leftMargin : 0),
        child:InkWell(
          onTap: onTap,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              image !=null ?
              Padding(
                padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                child: Image.asset(image,height: 20,),
              ) : Container(),
              icon !=null ?
              Padding(
                padding: EdgeInsets.only(left: 8.0,top:0,bottom:0,right: 0),
                child: icon,
              ) : Container(),
              Padding(
                padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                child: Text(text,style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,color: textColor !=null ? textColor : Colors.black),),
              ),
              image2 !=null ?
              Padding(
                padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                child: Image.asset(image2,height: 20,),
              ) : Container(),
            ],
          ),
        )
        // decoration: active==1 ? new BoxDecoration(
        //     color: Color(0xFF26B13C),
        //     borderRadius: new BorderRadius.only(
        //         topLeft: const Radius.circular(5.0),
        //         topRight: const Radius.circular(5.0),
        //         bottomLeft: const Radius.circular(5.0),
        //         bottomRight: const Radius.circular(5.0)
        //     )
        // ) : null,
      ),
      bottomDivider == true ? Container(
        height: 1,
        padding: EdgeInsets.only(left:0,right: 25,top:5,bottom: 5),
        margin: EdgeInsets.only(bottom: 5),
        child: Divider(
          height:2,
          thickness: 1,
          color: Color(0xFFe6e6e6),
        ),
      ) : Container(),
      bottombigDivider == true ? Container(
          height: 15,
          width: double.infinity,
          color: Color(0xFFf2f2f2),
          child: Text("")
      ) : Container(),
    ],
  );
}