import 'package:flutter/material.dart';
import 'dart:math' as math;
Widget createDrawerFooter({Icon icon,String image, String text, GestureTapCallback onTap,double leftPadding,double topPadding,double topMargin,Color backgroundColor}) {
  return Container(
    color: backgroundColor,
    height: 80,
    width: double.infinity,
    margin:EdgeInsets.only(top: 0.0),
    child: Column(
      children: <Widget>[
        new Expanded(
          child: ListTile(
            title: Row(
              children: <Widget>[
                image !=null ?
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:1),
                  child: Image.asset(image,width:25,height: 25,),
                ) : Text(""),
                icon !=null ?
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:1),
                  child: Transform.rotate(
                    angle: 180 * math.pi / 180,
                    child: IconButton(
                      icon: icon,
                      onPressed: null,
                    ),
                  ),
                ) : Text(""),
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:1),
                  child: Text(text,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.grey),),
                ),
              ],
            ),
            onTap: onTap,
          ),
        ),
      ],
    ),
  );
}