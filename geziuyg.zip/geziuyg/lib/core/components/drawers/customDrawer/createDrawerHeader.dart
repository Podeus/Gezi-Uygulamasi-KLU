import 'package:flutter/material.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
import 'dart:math' as math;

import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
Widget createDrawerHeader() {
  return Container(
    height: 65.0,
    width:double.infinity,
    // margin:EdgeInsets.only(bottom: 3.0),
    child:DrawerHeader(
      padding: EdgeInsets.zero,
      margin: EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 45,
            height: 45,
            child:Center(
              child:  IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => locator<NavigationService>().goBack(),
              ),
            )
          ),
          SizedBox(width: 20,),
          // Image.asset("asset/image/logo.png",height: 30,)
          Text("Gezi Uygulaması")
        ],
      ),
      decoration: BoxDecoration(
        // color: Color(0xffe6e6e6),
      ),
    ),
  );
}