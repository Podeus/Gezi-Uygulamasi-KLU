import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
// import 'package:flutter_base/core/models/auth.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/components/drawers/customDrawer/createDrawerBodyItem.dart';
import 'package:flutter_base/core/components/drawers/customDrawer/createDrawerHeader.dart';
import 'package:flutter_base/core/components/drawers/customDrawer/createDrawerFooter.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import "package:flutter_base/core/components/string/string_extension.dart";
class customDrawer extends StatefulWidget {
  String currentPage;
  customDrawer(this.currentPage);
  @override
  _customDrawerState createState() => _customDrawerState();
}

class _customDrawerState extends State<customDrawer> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  @override
  Widget build(BuildContext context) {
    final _auth = Provider.of<LoginViewModel>(context, listen: false);
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return Drawer(
      child: Container(
        padding: EdgeInsets.zero,
        color: _currentTheme.backgroundColor,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            createDrawerHeader(),
            SizedBox(height: 10),
            createDrawerBodyItem(
              image: "asset/image/hesabim.png",
              //   icon:  Icon(
              //     Icons.home_outlined,
              //     color: Color(0xff808080) ,
              //     size: 30.0,
              //   ),
                topMargin: 0,
                // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                topPadding: 0,
                bottomDivider:true,
                bottombigDivider:false,
                text: '${getTranslated(context, 'home_page')}',
                active: widget.currentPage =="HomeView" ? 1 : 0,
                textColor: widget.currentPage =="HomeView" ? Color(0xffe6e6e6): Color(0xff808080),
                onTap: () =>
                    locator<NavigationService>().navigateTo(routes.homeRoute)
            ),
            Spacer(),
            // createDrawerBodyItem(
            //     image: "asset/image/ayarlar.png",
            //     image2: "asset/image/listright.png",
            //     //   icon:  Icon(
            //     //     Icons.home_outlined,
            //     //     color: Color(0xff808080) ,
            //     //     size: 30.0,
            //     //   ),
            //     topMargin: 0,
            //     // leftMargin: widget.currentPage =="MyCollaborationsView" ? 0 : 0,
            //     topPadding: 0,
            //     bottomDivider:false,
            //     bottombigDivider:true,
            //     text: '${getTranslated(context, 'settings').capitalize()}',
            //     active: widget.currentPage =="SettingsView" ? 1 : 0,
            //     textColor: widget.currentPage =="SettingsView" ? Color(0xffe6e6e6): Color(0xFF808080),
            //     onTap: () =>
            //         locator<NavigationService>().navigateTo(routes.settingsRoute)
            // ),
            // createDrawerBodyItem(
            //     image: "asset/image/sirket.png",
            //     //   icon:  Icon(
            //     //     Icons.home_outlined,
            //     //     color: Color(0xff808080) ,
            //     //     size: 30.0,
            //     //   ),
            //     topMargin: 0,
            //     // leftMargin: widget.currentPage =="MyCollaborationsView" ? 0 : 0,
            //     topPadding: 0,
            //     bottomDivider:true,
            //     bottombigDivider:false,
            //     text: '${getTranslated(context, 'Establish_a_Company')}',
            //     active: widget.currentPage =="StartCompanyView" ? 1 : 0,
            //     textColor: widget.currentPage =="StartCompanyView" ? Color(0xffe6e6e6): Color(0xFF808080),
            //     onTap: () {
            //       // locator<NavigationService>().navigateTo(
            //       //     routes.startcompanyRoute);
            //       locator<NavigationService>().navigateTo(routes.contentRoute,arguments: {"id":"4","text":"Şirket Kur (bilgi)"});
            //     }
            // ),
            createDrawerBodyItem(
                // image: "asset/image/sirket.png",
                  icon:  Icon(
                    Icons.logout,
                    color: Color(0xff808080) ,
                    size: 25.0,
                  ),
                topMargin: 0,
                // leftMargin: widget.currentPage =="MyCollaborationsView" ? 0 : 0,
                topPadding: 0,
                bottomDivider:false,
                bottombigDivider:false,
                text: 'Çıkış Yap',
                active: 0,
                textColor: Color(0xFF808080),
                onTap: () =>
                    _auth.signOut()
            ),
           SizedBox(height: 15,)
            // Expanded(
            //   child: Align(
            //       alignment: Alignment.bottomCenter,
            //       child: Container(
            //         margin: EdgeInsets.only(top:25),
            //         height: 65,
            //         color: Color(0xffe6e6e6),
            //         child:Row(
            //           mainAxisAlignment: MainAxisAlignment.center,
            //           crossAxisAlignment: CrossAxisAlignment.center,
            //           children: [
            //             Text("${getTranslated(context, 'GET_INFO_detail_text')}",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),),
            //             SizedBox(width: 10,),
            //             FlatButton(
            //               padding: EdgeInsets.all(3.0),
            //               shape: RoundedRectangleBorder(
            //                 borderRadius: BorderRadius.circular(12.0),
            //                 // side: BorderSide(color: buttonColor !=null ? buttonColor :Color(0xFFF2F2F2))
            //               ),
            //               onPressed: () {
            //                 print("bilgi al");
            //                 locator<NavigationService>().navigateTo(routes.contentRoute,arguments: {"id":"7","text":"${getTranslated(context, 'GET_INFO')}"});
            //               },
            //               color: Color(0xFFbd0829),
            //               child: Row(
            //                 mainAxisAlignment: MainAxisAlignment.center,
            //                 mainAxisSize: MainAxisSize.max,
            //                 children: <Widget>[
            //                   Text(
            //                       "${getTranslated(context, 'GET_INFO')}",
            //                       style: TextStyle(
            //                           color: Colors.white,
            //                           fontSize: 12.0,
            //                           fontWeight: FontWeight.w400
            //                       )
            //                   )
            //                 ],
            //               ),
            //             ),
            //           ],
            //         )
            //       )
            //   ),
            // ),
          ],
        ),
      )
    );
  }
}