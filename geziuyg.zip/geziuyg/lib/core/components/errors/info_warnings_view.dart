import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:math';
import 'dart:convert';
import 'dart:async';
import 'dart:io';

import 'package:share/share.dart';
class InfoWarningsView extends StatelessWidget {
  final String topText;
  final String topImage;

  const InfoWarningsView({Key key,
    this.topText,
    this.topImage,
  }) : super(key: key);
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 30,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(width: 20,),
              Container(
                  height: 45,
                  width: 75,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(topImage!=null ? topImage : "asset/image/info.png"),
                      fit: BoxFit.contain,
                    ),
                  ),
                  child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(width: 15,),
                      Container(
                        margin:EdgeInsets.only(),
                        child: Text("${topText}",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 12)),
                      ),
                      // SizedBox(width: 15,)
                    ],
                  )

              ),
            ],
          ),
        ),
      ],
    );
  }
}