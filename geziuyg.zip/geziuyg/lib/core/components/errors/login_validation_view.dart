import 'package:flutter/material.dart';
Widget loginValidationView({
  Icon icon,
  String image,
  String text,
  GestureTapCallback onTap,
  double leftPadding,
  double topPadding,
  double topMargin,
  double leftMargin,
  int active,
  Color textColor
}) {
  return Align(
      alignment: Alignment.topLeft,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(
              Radius.circular(15)
          ),
          // color: Colors.red,
          // boxShadow: [
          //   BoxShadow(
          //       color: Colors.white,
          //       blurRadius: 5
          //   )
          // ],
        ),
        padding: EdgeInsets.only(top:5,bottom: 5,left:5,right:5),
        margin: EdgeInsets.only(left:45),
        child: Text(text !=null ? text : 'Value Can\'t Be Empty',style: TextStyle(color: Colors.red,fontSize: 12),),
      )
  );
}