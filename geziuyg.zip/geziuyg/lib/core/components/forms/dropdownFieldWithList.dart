import 'package:flutter/material.dart';

class DropdownFieldWithList extends StatelessWidget {
  final String selectedItem;
  final List<DropdownMenuItem> dropdownMenuItems;
  final Function onChanged;

  const DropdownFieldWithList({
    this.selectedItem,
    this.dropdownMenuItems,
    this.onChanged,
  });
  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: selectedItem,
        items: dropdownMenuItems,
        onChanged: onChanged,
        style: TextStyle(color: Colors.black),
        iconEnabledColor:Colors.black,
        hint: Text(
          "",
          style: TextStyle(
              color: Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
