import 'package:flutter/material.dart';

class LabeledCheckbox extends StatelessWidget {
  const LabeledCheckbox({
    this.label,
    this.padding,
    this.value,
    this.onChanged,
    this.onClicked,
  });

  final String label;
  final EdgeInsets padding;
  final bool value;
  final Function onChanged;
  final Function onClicked;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        onChanged(!value);
      },
      child: Padding(
        padding: padding,
        child: Row(
          children: <Widget>[

            Checkbox(
              value: value,
              onChanged: (bool newValue) {
                onChanged(newValue);
              },
            ),
            Expanded(
                child: GestureDetector(
                  onTap: () {
                    print('Tap Here onTap');
                    // locator<NavigationService>().navigateTo(routes.contentRoute,arguments: "7"),
                    onClicked();
                  },
                  child: Text.rich(
                      TextSpan(
                        text: "${label}",
                        style: TextStyle(fontSize: 13,decoration: TextDecoration.none,),
                      )

                  ),
                )
            ),
            // SwitchListTile(
            //   value: value,
            //   onChanged: (bool newValue) {
            //     onChanged(newValue);
            //   },
            // )
          ],
        ),
      ),
    );
  }
}