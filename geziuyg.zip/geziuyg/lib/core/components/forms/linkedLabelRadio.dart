import 'package:flutter/material.dart';

class LinkedLabelRadio extends StatelessWidget {
  const LinkedLabelRadio({
    this.label,
    this.padding,
    this.groupValue,
    this.value,
    this.onChanged,
  });

  final String label;
  final EdgeInsets padding;
  final bool groupValue;
  final bool value;
  final Function onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left:15,right:15,top: 5),
      decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFFFFF),
              Color(0xFFFFFFFF),
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.all(
              Radius.circular(10)
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 5,
            )
          ]
      ),
      child:  Theme(
        data: Theme.of(context).copyWith(
        unselectedWidgetColor: Color(0xffBF0025),
        disabledColor: Color(0xffBF0025),
    ),
    child:RadioListTile<bool>(
          activeColor: Color(0xffBF0025),
          title: Container(
            // width: MediaQuery.of(context).size.width,
            // height: 45,
            padding: EdgeInsets.only(top:0,bottom:0,left:0),

            child: Text(
              label,
              textAlign: TextAlign.start,
              style: TextStyle(fontSize: 13,fontWeight: FontWeight.w500,color: Color(0xFF666666)),
            ),
          ),
          groupValue: groupValue,
          value: value,
          onChanged: (bool newValue) {
            // model.setLanguage("tr");
            print(newValue);
            onChanged(newValue);
          }
      ),
      ),
    );
  }
}
