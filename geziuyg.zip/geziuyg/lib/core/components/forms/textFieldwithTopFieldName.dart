import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
class textFieldWithTopLabel extends StatelessWidget {
  final TextEditingController textController;
  final String name;
  final Color color;
  final Color textColor;
  final String type;
  final BuildContext context;
  final bool readonly;
  final bool enabled;
  final double border;
  final String format;
  final double leftpadding;

  const textFieldWithTopLabel({
    this.textController,
    this.name,
    this.color,
    this.textColor,
    this.type,
    this.context,
    this.readonly,
    this.enabled,
    this.border,
    this.format,
    this.leftpadding,
  });
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        border > 0 ? Container() : getLabel(context,name,leftpadding),
        Container(
          width: MediaQuery.of(context).size.width * 0.90,
          height: 45,
          padding: EdgeInsets.only(
              top: 0,right: 0, bottom: 0
          ),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                  border > 0 ? Radius.circular(border) : Radius.circular(10)
              ),
              color: color,
              boxShadow: [
                BoxShadow(
                    color: Colors.black12,
                    blurRadius: 5
                )
              ]
          ),
          child: TextField(
            // key: Key('__RIKEY2__${name}'),
            // autovalidate: false,
            controller: textController,
            obscureText: type != "password" ? false :true,
            readOnly: readonly == true ? true: false,
            enabled: enabled == false ? true: false,
            keyboardType: format == "number" || format == "phone" || format == "iban" ? TextInputType.number :
            format == "text" ? TextInputType.text :
            format == "email" ? TextInputType.emailAddress :
            null,
            inputFormatters: format == "number" || format == "phone" || format == "iban" ? <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly] :
            format == "text" ? null:
            format == "email" ? null:
            null,
            // validator: (value){
            //   return value.length < 2 ? 'Name must be greater than two characters' : null;
            // },
            decoration: InputDecoration(
              // border: new OutlineInputBorder(
              //   borderRadius: const BorderRadius.all(
              //     const Radius.circular(50.0),
              //   ),
              // ),
              contentPadding: EdgeInsets.only(left:format == "phone" || format == "iban" ? 10 : 3,right:10,top:format == "phone" || format == "iban" ? 12 : 0),
              prefixText: "   ",
              prefixIcon: format == "phone" ?
              Container(
                decoration: BoxDecoration(
                  // border: Border.all(
                  //     color: Color(0xFFFFBC00), //  0xFF0071BC
                  //     width: 1.0
                  // ),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                    topLeft: Radius.circular(10.0),
                  ),
                  color: Color(0xffE6E6E6),
                ),
                width: 20,
                child: Center(
                  child: Text("+90",style: TextStyle(fontSize: 15,color: Color(0xff808080),fontWeight: FontWeight.bold),),
                ),
              ) :
              format == "iban" ? Container(
                decoration: BoxDecoration(
                  // border: Border.all(
                  //     color: Color(0xFFFFBC00), //  0xFF0071BC
                  //     width: 1.0
                  // ),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                    topLeft: Radius.circular(10.0),
                  ),
                  color: Color(0xffE6E6E6),
                ),
                width: 20,
                child: Center(
                  child: Text("TR",style: TextStyle(fontSize: 15,color: Color(0xff808080),fontWeight: FontWeight.bold),),
                ),
              ) : null,
              border: InputBorder.none,
              // hintText: '$name',
              hintStyle: TextStyle(color:textColor),

              // labelText: 'Ad',
            ),
          ),
        )
      ],
    );
  }
}

Widget getLabel(BuildContext context,String name,double leftpadding){
  return Container(
    width: MediaQuery.of(context).size.width * 0.95,
    margin: EdgeInsets.only(left:leftpadding!=null ? leftpadding : 25,top:15,bottom:5),
    height:20,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "$name",
          style: TextStyle(color:Color(0xFF666666),fontSize: 12,fontWeight: FontWeight.bold),
        )
      ],
    ),
  );
}