import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/components/forms/dropdownFieldWithList.dart';
class twinChildDetails extends StatelessWidget {
  final String name1;
  final String name2;
  final Function func1;
  final Function func2;
  final String selectedItem1;
  final String selectedItem2;

  const twinChildDetails({
    this.name1,
    this.name2,
    this.func1,
    this.func2,
    this.selectedItem1,
    this.selectedItem2,
  });
  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[

        Container(
            width: MediaQuery.of(context).size.width * 0.45,
            margin: EdgeInsets.only(left:10),
            child:Column(
              children: [

                getLabel1(context,name2,15),
                Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(10)
                        ),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    width: MediaQuery.of(context).size.width * 0.40,
                    // margin: EdgeInsets.only(left:5),
                    child:
                    DropdownFieldWithList(
                      selectedItem:selectedItem2,
                      dropdownMenuItems: [
                        'Erkek','Kız'
                      ].map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child:new Row(
                              children:[
                                Container(
                                  height: 45,
                                  padding:new EdgeInsets.only(top:10.0,left:10.0,right:15.0),
                                  decoration: BoxDecoration(
                                    // color: dropdownValue == 2 ? Colors.white : Colors.black12,
                                  ),
                                  child: Column(
                                    children: [
                                      Padding(
                                          padding:new EdgeInsets.only(top:5.0),
                                          child: Center(
                                            child: Text(
                                              value,
                                              style:TextStyle(fontSize: 13),
                                              textAlign: TextAlign.center,
                                            ),
                                          )
                                      ),
                                    ],
                                  ),
                                ),
                              ]
                          ),
                        );
                      }).toList(),
                      onChanged:(String value) => func2(value),
                      // onChanged:(String value) {
                      // setState(() {
                      //   child1gender = value;
                      // });
                      // },
                    )
                ),
              ],
            )
        ),
        Container(
            width: MediaQuery.of(context).size.width * 0.45,
            margin: EdgeInsets.only(left:15),
            child:Column(
              children: [

                getLabel1(context,name1,15),
                Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(10)
                        ),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    width: MediaQuery.of(context).size.width * 0.40,
                    // margin: EdgeInsets.only(left:5),
                    child: DropdownFieldWithList(
                      selectedItem:selectedItem1,
                      dropdownMenuItems: [
                        '0','1','2','3','4','5','6','7','8','9','10',
                        '11','12','13','14','15','16','17','18','19','20',
                        '21','22','23','24','25','26','27','28','29','30',
                      ].map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child:new Row(
                              children:[
                                Container(
                                  height: 45,
                                  padding:new EdgeInsets.only(top:10.0,left:10.0,right:15.0),
                                  decoration: BoxDecoration(
                                    // color: dropdownValue == 2 ? Colors.white : Colors.black12,
                                  ),
                                  child: Column(
                                    children: [
                                      Padding(
                                          padding:new EdgeInsets.only(top:5.0),
                                          child: Center(
                                            child: Text(
                                              value,
                                              style:TextStyle(fontSize: 13),
                                              textAlign: TextAlign.center,
                                            ),
                                          )
                                      ),
                                    ],
                                  ),
                                ),
                              ]
                          ),
                        );
                      }).toList(),
                      onChanged:(String value) => func1(value),
                      // onChanged:(String value) {
                      // setState(() {
                      //   child1age = value;
                      // });
                      // },
                    )
                ),
              ],
            )
        ),
      ],
    );
  }
}

Widget getLabel1(BuildContext context,String name,double leftpadding){
  return Container(
    width: MediaQuery.of(context).size.width * 0.95,
    margin: EdgeInsets.only(left:leftpadding!=null ? leftpadding : 25,top:15,bottom:5),
    height:20,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "$name",
          style: TextStyle(color:Color(0xFF666666),fontSize: 12,fontWeight: FontWeight.bold),
        )
      ],
    ),
  );
}