import 'package:flutter/material.dart';
Widget twinFieldWithTopLabel(TextEditingController textController,String name,Color color,Color textColor,String type,BuildContext context,bool readonly) {
  return Container(
      width: MediaQuery.of(context).size.width * 0.43,
      margin: EdgeInsets.only(left:15),
      child:Column(
        children: [
          getLabel(name,context),
          Container(
            width: MediaQuery.of(context).size.width * 0.95,
            height: 45,
            padding: EdgeInsets.only(
                top: 0,left: 16, right: 16, bottom: 0
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                    Radius.circular(50)
                ),
                color: color,
                boxShadow: [
                  BoxShadow(
                      color: Colors.black12,
                      blurRadius: 5
                  )
                ]
            ),
            child: TextField(
              controller: textController,
              obscureText: type != "password" ? false :true,
              readOnly: readonly == true ? true: false,
              decoration: InputDecoration(
                // border: new OutlineInputBorder(
                //   borderRadius: const BorderRadius.all(
                //     const Radius.circular(50.0),
                //   ),
                // ),
                border: InputBorder.none,
                // hintText: '$name',
                hintStyle: TextStyle(color:textColor),
                // labelText: 'Ad',
              ),
            ),
          )
        ],
      )
  );
}
Widget getLabel(String name,BuildContext context){
  return Container(
    width:MediaQuery.of(context).size.width,
    margin: EdgeInsets.only(left:0,top:15,bottom:5),
    height:20,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          "$name",
          style: TextStyle(color:Color(0xFF666666),fontSize: 12,fontWeight: FontWeight.bold),
        )
      ],
    ),
  );
}