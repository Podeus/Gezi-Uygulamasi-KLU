import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/bottomModal/bottomModal.dart';
import 'package:flutter_base/core/components/button/icon_text_button.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;

class GeneralListView extends StatelessWidget {
  final int itemCount;
  final int currentIndex;
  final bool scroll;
  final String buttonType;
  final List onListItem;
  final Color textColor;
  final Color backgroundColor;
  final Color buttonColor;
  final Function onClickAction;
  final Function onClickAction2;

  const GeneralListView({Key key,
    this.itemCount,
    this.onListItem,
    this.currentIndex,
    this.scroll,
    this.buttonType,
    this.textColor,
    this.backgroundColor,
    this.buttonColor,
    this.onClickAction,
    this.onClickAction2,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: scroll== false ? NeverScrollableScrollPhysics() : null,
      shrinkWrap: true,
      // scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      padding: new EdgeInsets.all(15.0),
      itemBuilder: (context, index) => buildCard(context, index),
    );
  }
  // void _modalBottomSheetMenu(context,index){
  //   showModalBottomSheet(
  //       shape: RoundedRectangleBorder(
  //           borderRadius: new BorderRadius.only(
  //               topLeft: const Radius.circular(10.0),
  //               topRight: const Radius.circular(10.0)
  //           )
  //       ),
  //       context: context,
  //       builder: (builder){
  //         return bottomModal(
  //           context: context,
  //           toptext: "Code coupon",
  //           title: onListItem[index]["title"],
  //           coupon_id: onListItem[index]["coupon_id"],
  //           store_id: onListItem[index]["store_id"],
  //           companyLogo: onListItem[index]["companyLogo"],
  //           company: onListItem[index]["company"],
  //           uses: onListItem[index]["usesText"],
  //           lastuse: onListItem[index]["lastuseText"],
  //           code: onListItem[index]["code"],
  //           backgroundColor: backgroundColor,
  //           textColor: textColor,
  //           buttonColor: buttonColor,
  //           buttonType:onListItem[index]["buttonType"],
  //           favorite:onListItem[index]["favorite"],
  //           onClickAction: onClickAction,
  //         );
  //       }
  //   );
  // }
  Card buildCard(BuildContext context, int index) {
    return Card(
      elevation: 1.7,
      color: backgroundColor,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.all(Radius.circular(15.0)),
      ),
      child: new Padding(
        padding: new EdgeInsets.all(0.0),
        child: new Column(
          children: [
            new Row(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  child: new Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      new Container(
                          margin:EdgeInsets.only(left:10,top:10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Color(0xFF26B13C),
                                Color(0xFF000000)
                              ],
                              begin: Alignment.topRight,
                              end: Alignment.bottomLeft,
                            ),
                            borderRadius: const BorderRadius.all(
                              Radius.circular(15.0),
                            ),
                          ),
                          width: 82,
                          height: 82,
                          child: Icon(Icons.person_pin,size: 75,color: Color(0xffffc929),),
                          // child: Center(
                          //   child: Text(
                          //     onListItem !=null ? onListItem[index]["discountText"] : "",
                          //     overflow: TextOverflow.ellipsis,
                          //     style: TextStyle(
                          //         fontSize: 25,fontWeight: FontWeight.w700,color: Colors.white
                          //     ),
                          //   ),
                          // )
                      ),
                    ],
                  ),
                  onTap: () {
                    print("discount button");
                    // _modalBottomSheetMenu(context,index);
                  },
                ),
                Expanded(
                  child:  new Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          print("go to detail page");
                          // _modalBottomSheetMenu(context,index);
                        },
                        child:
                         Container(
                          margin: new EdgeInsets.only(
                              left: 10.0,
                              right: 8.0,
                              bottom: 8.0,
                              top: 8.0),
                          child: RichText(
                            overflow: TextOverflow.ellipsis,maxLines: 3,
                            strutStyle: StrutStyle(fontSize: 12.0),
                            text: TextSpan(
                              style: TextStyle(  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: textColor),
                              text:  onListItem != null ? onListItem[index]["title"] : "",),
                          ),
                        ),

                      ),
                      GestureDetector(
                          onTap: () {
                            print("go to company detail page");
                            // locator<NavigationService>().navigateTo(routes.notificationDetailRoute,arguments: {"id":onListItem[index]["store_id"]});
                          },
                          child:Container(
                            margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Flexible(
                                  child: RichText(
                                    overflow: TextOverflow.ellipsis,maxLines: 3,
                                    strutStyle: StrutStyle(fontSize: 12.0),
                                    text: TextSpan(
                                      style: TextStyle( color: Color(0xFF808080), fontWeight: FontWeight.w500,),
                                      text:  onListItem !=null ? "${onListItem[index]["brans"]}" : "",),
                                  ),
                                ),
                              ],
                            ),
                          )
                      )
                    ],
                  ),
                ),
              ],
            ),
            // Row(
            //     children: <Widget>[
            //       Expanded(
            //         child: new Container(
            //             margin: const EdgeInsets.only(left: 10.0, right: 10.0),
            //             child: Divider(
            //               color: Color(0xFFDBDBDB),
            //               height: 5,
            //             )),
            //       ),
            //     ]
            // ),
            new Row(
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.max,
              children: [
                Align(
                    alignment: FractionalOffset.topRight,
                    child: Container(
                        margin: const EdgeInsets.only(left: 0.0,right: 25,bottom:10),
                        child: IconTextButton(
                          onPressed: () {
                            if(onListItem[index]["favorite"]=="2"){
                              onClickAction(onListItem[index]["id"],"${onListItem[index]["title"]}",onListItem[index]["request_id"]);
                            }else{
                              onClickAction(onListItem[index]["id"],"${onListItem[index]["title"]}",onListItem[index]["request_id"]);
                            }
                          },
                          // icon: Icon(Icons.bookmark_border),
                          sizedboxWidth: 10,
                          fontSize: 14,
                          text: "${onListItem[index]["favorite"]=="0" ? "ARA" : onListItem[index]["favorite"]=="2" ?  "CEVAPLA" : "İptal Et" }",
                          buttonColor: buttonColor,
                          textColor: textColor,
                          favorite: onListItem[index]["favorite"],
                        )
                    )
                ),
                buttonType == "3" ? Align(
                    alignment: FractionalOffset.topRight,
                    child: Container(
                        margin: const EdgeInsets.only(left: 0.0,right: 25,bottom:10),
                        child: IconTextButton(
                          onPressed: () {
                            onClickAction2(onListItem[index]["id"],"${onListItem[index]["title"]}",onListItem[index]["request_id"]);
                          },
                          // icon: Icon(Icons.bookmark_border),
                          sizedboxWidth: 10,
                          fontSize: 14,
                          text:  "Talep Sil",
                          buttonColor: buttonColor,
                          textColor: textColor,
                          favorite: onListItem[index]["favorite"],
                        )
                    )
                ) :Container()
              ],
            ),
          ],
        ), ////
      ),
    );
  }

  // CircleAvatar buildCircleAvatar(int index, BuildContext context) {
  //   return CircleAvatar(
  //     backgroundColor: isCurrentIndex(index) ? Colors.black12 : Colors.blue,
  //     // radius: isCurrentIndex(index) ? context.width * 0.03 : context.width * 0.015,
  //     child: AnimatedOpacity(
  //       opacity: opacityValue(index),
  //       // duration: context.normalDuration,
  //       child: onListItem(index),
  //     ),
  //   );
  // }

  double opacityValue(int index) => isCurrentIndex(index) ? 1 : 0;

  bool isCurrentIndex(int index) => currentIndex == index;
}
