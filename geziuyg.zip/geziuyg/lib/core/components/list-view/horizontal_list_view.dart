import 'package:flutter/material.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';

// import '../../extension/context_extension.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
class HorizontalListView extends StatelessWidget {
  final int itemCount;
  final int currentIndex;
  final bool scroll;
  final String buttonType;
  final List onListItem;
  final Color backgroundColor;
  final Color textColor;

  const HorizontalListView({Key key,
    this.itemCount,
    this.onListItem,
    this.currentIndex,
    this.scroll,
    this.buttonType,
    this.backgroundColor,
    this.textColor,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      shrinkWrap: true,
      padding:  EdgeInsets.only(top: 10,bottom: 10),
      itemBuilder: (context, index) => buildCard(context, index),
    );
  }

  Card buildCard(BuildContext context, int index) {
    return Card(
        elevation: 1.7,
        color: backgroundColor,
        semanticContainer: true,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        // margin: EdgeInsets.all(10),
        shape: RoundedRectangleBorder(
          borderRadius: const BorderRadius.all(Radius.circular(15.0)),
        ),
        child: Row(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            GestureDetector(
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Container(
                    margin:EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      // gradient: LinearGradient(
                      //   colors: [
                      //     Color(0xFF000000),
                      //     Color(0xFF000000),
                      //   ],
                      //   begin: Alignment.centerLeft,
                      //   end: Alignment.centerRight,
                      // ),
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: onListItem[index]["logo"] !=null ? NetworkImage(onListItem[index]["logo"]) : AssetImage("asset/image/onboard1.png"),
                      ),
                      border: Border.all(
                          color: Colors.white,
                          width: 1.0
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(15.0),
                      ),
                    ),
                    width: 60,
                    height: 60,
                    // child: Center(
                    //   child: Text(
                    //     "Nike",
                    //     style: TextStyle(
                    //         fontSize: 20,fontWeight: FontWeight.w700,color: Colors.white
                    //     ),
                    //   ),
                    // )
                  ),
                  Container(
                    margin:EdgeInsets.only(right: 15,top:15),
                    // width: MediaQuery.of(context).size.width * 0.2,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        new Padding(
                          padding: new EdgeInsets.only(
                              left: 0.0,
                              right: 0.0,
                              bottom: 8.0,
                              top: 5.0),
                          child: new Text(
                            onListItem[index]["name"],
                            textAlign: TextAlign.left,
                            style: new TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              color: textColor
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        new Padding(
                          padding: new EdgeInsets.only(
                              left: 0.0,
                              right: 4.0,
                              bottom: 4.0),
                          child: new Text(
                            "${onListItem[index]["couponsCount"]} Coupons",
                            style: new TextStyle(
                              color: Colors.grey[500],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              onTap: () {
                print("go to detail page 2");
                locator<NavigationService>().navigateTo(routes.notificationDetailRoute,arguments: {"id":onListItem[index]["store_id"]});
                // _modalBottomSheetMenu(context);
              },
            ),
          ],
        )
    );
  }

  // CircleAvatar buildCircleAvatar(int index, BuildContext context) {
  //   return CircleAvatar(
  //     backgroundColor: isCurrentIndex(index) ? Colors.black12 : Colors.blue,
  //     // radius: isCurrentIndex(index) ? context.width * 0.03 : context.width * 0.015,
  //     child: AnimatedOpacity(
  //       opacity: opacityValue(index),
  //       // duration: context.normalDuration,
  //       child: onListItem(index),
  //     ),
  //   );
  // }

  double opacityValue(int index) => isCurrentIndex(index) ? 1 : 0;

  bool isCurrentIndex(int index) => currentIndex == index;
}
