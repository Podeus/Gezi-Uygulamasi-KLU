import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/bottomModal/bottomModal.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/constants/api_urls.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
class NotificationListView extends StatelessWidget {
  final int itemCount;
  final int currentIndex;
  final bool scroll;
  final String buttonType;
  final List onListItem;
  final Color textColor;
  final Color backgroundColor;
  final Color canvasColor;

  const NotificationListView({Key key,
    this.itemCount,
    this.onListItem,
    this.currentIndex,
    this.scroll,
    this.buttonType,
    this.textColor,
    this.backgroundColor,
    this.canvasColor,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: scroll== false ? NeverScrollableScrollPhysics() : null,
      shrinkWrap: true,
      // scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      padding: new EdgeInsets.all(0.0),
      itemBuilder: (context, index) => buildPadding(context, index),
    );
  }
  Widget buildPadding(BuildContext context, int index) {
    return Container(
        // padding: new EdgeInsets.all(0.0),
      width: MediaQuery.of(context).size.width,
        child: InkWell(
            onTap: () => {
              locator<NavigationService>().navigateTo(routes.notificationDetailRoute,arguments: {"id":"","jsonencode":json.encode(onListItem[index])}),
              // locator<NavigationService>().navigateTo(routes.notificationDetailRoute,arguments: {"id":onListItem[index]["store_id"]}),
            },
            child: new Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      // padding: const EdgeInsets.only(top: 0, bottom: 0, left: 0, right: 5),
                      child: Dismissible(
                        // Each Dismissible must contain a Key. Keys allow Flutter to
                        // uniquely identify widgets.
                          key: Key(onListItem[index]["id"]),
                          // Provide a function that tells the app
                          // what to do after an item has been swiped away.
                          secondaryBackground: Container(
                            color: canvasColor,
                            child: Align(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Icon(
                                    Icons.delete_rounded,
                                    size: 30,
                                    color: Color(0xFF808080),
                                  ),
                                  Text(
                                    " Delete",
                                    style: TextStyle(
                                      color: Colors.transparent,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ],
                              ),
                              alignment: Alignment.centerLeft,
                            ),
                          ),
                          background:  Container(
                            color: canvasColor,
                            child: Align(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Icon(
                                    Icons.delete_rounded,
                                    size: 30,
                                    color: Color(0xFF808080),
                                  ),
                                  Text(
                                    " Delete",
                                    style: TextStyle(
                                      color: Colors.transparent,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                ],
                              ),
                              alignment: Alignment.centerLeft,
                            ),
                          ),
                          onDismissed: (direction) {
                            // Remove the item from the data source.
                            // setState(() {
                            //   items.removeAt(index);
                            // });
                            // model.user_cards.removeAt(index);
                            // model.delete_card_data(item["card_id"]);
                            // Then show a snackbar.
                            Scaffold.of(context)
                                .showSnackBar(SnackBar(content: Text("${index} deleted")));
                          },
                          confirmDismiss: (DismissDirection direction) async {
                            return await showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: Text("deleted"),
                                  content: Text("are you sure"),
                                  actions: <Widget>[
                                    FlatButton(
                                        onPressed: ()  {
                                          Navigator.of(context).pop(true);
                                        },
                                        child: Text("Delete")
                                    ),
                                    FlatButton(
                                      onPressed: () {
                                        Navigator.of(context).pop(false);
                                      },
                                      child: Text("cancel"),
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                          child: CustomListItemTwo(
                            thumbnail: Container(
                              height: 50,
                              width: 60,
                              decoration: BoxDecoration(
                                color: backgroundColor,
                                borderRadius: const BorderRadius.only(
                                  topRight: Radius.circular(15.0),
                                  bottomRight: Radius.circular(15.0),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text("${onListItem[index]["readed"] == "0" ? "1" : "0"}"),
                                  SizedBox(width: 5,),
                                  Container(
                                    height: 15.0,
                                    width: 15.0,
                                    decoration: BoxDecoration(
                                      // shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.contain,
                                        image: onListItem[index]["type"] == "1" ? AssetImage("asset/image/mektup1.png") :
                                                  onListItem[index]["type"] == "2" ? AssetImage("asset/image/info1.png") :
                                                  onListItem[index]["type"] == "3" ? AssetImage("asset/image/unlem1.png") :
                                                  onListItem[index]["type"] == "4" ? AssetImage("asset/image/warning1.png") :
                                                  onListItem[index]["type"] == "5" ? AssetImage("asset/image/anons1.png")
                                                      : AssetImage("asset/image/mektup1.png"),
                                      ),
                                      border: Border.all(
                                          color: Colors.transparent,
                                          width: 1.0
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(5.0),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            title: onListItem[index]["title"],
                            subtitle: onListItem[index]["body"],
                            author: onListItem[index]["title"],
                            publishDate:  onListItem[index]["created_at"],
                            readDuration: "Editor",
                            textColor: textColor,
                            backgroundColor: backgroundColor,
                            canvasColor: canvasColor,
                          )
                      )
                  )
                  ,Row(
                      children: <Widget>[
                        Expanded(
                          child: new Container(
                              margin: const EdgeInsets.only(left: 65.0, right: 10.0),
                              child: Divider(
                                color: Colors.white,
                                thickness: 2,
                                height: 2,
                              )),
                        ),
                      ]
                  ),
                ]
            )
        )
    );
  }

  // CircleAvatar buildCircleAvatar(int index, BuildContext context) {
  //   return CircleAvatar(
  //     backgroundColor: isCurrentIndex(index) ? Colors.black12 : Colors.blue,
  //     // radius: isCurrentIndex(index) ? context.width * 0.03 : context.width * 0.015,
  //     child: AnimatedOpacity(
  //       opacity: opacityValue(index),
  //       // duration: context.normalDuration,
  //       child: onListItem(index),
  //     ),
  //   );
  // }

  double opacityValue(int index) => isCurrentIndex(index) ? 1 : 0;

  bool isCurrentIndex(int index) => currentIndex == index;
}
class CustomListItemTwo extends StatelessWidget {
  CustomListItemTwo({
    Key key,
    this.thumbnail,
    this.title,
    this.subtitle,
    this.author,
    this.publishDate,
    this.readDuration,
    this.backgroundColor,
    this.textColor,
    this.canvasColor,
  }) : super(key: key);

  final Widget thumbnail;
  final String title;
  final String subtitle;
  final String author;
  final String publishDate;
  final String readDuration;
  final Color backgroundColor;
  final Color textColor;
  final Color canvasColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: const EdgeInsets.all(5.0),
      padding: const EdgeInsets.only(top:10.0,bottom:10),
      // decoration: BoxDecoration(
      //   color: backgroundColor,
      //   borderRadius: const BorderRadius.all(
      //     Radius.circular(15.0),
      //   ),
      // ),
      child:Container(
        padding: const EdgeInsets.only(top: 5.0),
        child: SizedBox(
          height: 35,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Container(
                  // padding: const EdgeInsets.fromLTRB(20.0, 0.0, 2.0, 0.0),
                  child: _ArticleDescription(
                    title: title,
                    subtitle: subtitle,
                    author: author,
                    publishDate: publishDate,
                    readDuration: readDuration,
                    thumbnail: thumbnail,
                    textColor: textColor,
                    backgroundColor: backgroundColor,
                    canvasColor: canvasColor,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ArticleDescription extends StatelessWidget {
  _ArticleDescription({
    Key key,
    this.title,
    this.subtitle,
    this.author,
    this.publishDate,
    this.readDuration,
    this.thumbnail,
    this.backgroundColor,
    this.textColor,
    this.canvasColor,

  }) : super(key: key);

  final String title;
  final String subtitle;
  final String author;
  final String publishDate;
  final String readDuration;
  final Widget thumbnail;
  final Color backgroundColor;
  final Color textColor;
  final Color canvasColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              thumbnail,
              // Container(padding: EdgeInsets.only(left: 10.0)),
              Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(left:15,right:15,top:5),
                    child: Text(
                        '$title',
                      style: TextStyle(color:Color(0xFF666666),fontSize: 12,fontWeight: FontWeight.bold),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.justify,
                    ),
                  )
              ),
            ],
          ),
        ),
        // Row(
        //     children: <Widget>[
        //       Expanded(
        //         child: new Container(
        //             margin: const EdgeInsets.only(left: 10.0, right: 10.0),
        //             child: Divider(
        //               color: Colors.white,
        //               thickness: 2,
        //               height: 2,
        //             )),
        //       ),
        //     ]
        // ),
      ],
    );
  }
}