import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/bottomModal/bottomModal.dart';
import 'package:flutter_base/core/components/button/icon_text_button.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:stacked/stacked.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_html/flutter_html.dart';

import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
class ShowSampleImageView extends StatefulWidget {
  String src;
  String text;
  ShowSampleImageView({this.src,this.text});
  @override
  _ShowSampleImageViewState createState() => _ShowSampleImageViewState();
}

class _ShowSampleImageViewState extends State<ShowSampleImageView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    return Scaffold(
      appBar: BaseAppBar(
        title: Text("${widget.text}",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: _currentTheme.textSelectionColor)),
        // image: Image.asset("asset/image/logo.png",height: 30,),
        appBar: AppBar(),
        // backgroundColor:Color(0xffe6e6e6),
        leading: (Navigator.canPop(context) ? IconButton(
          icon: FaIcon(
            FontAwesomeIcons.longArrowAltLeft,
            color: Colors.black,
            size: 25,
          ),
          onPressed: () => locator<NavigationService>().goBack(),
        ) : null),
      ),
      backgroundColor: _currentTheme.backgroundColor,
      body: Container(
          decoration: BoxDecoration(
            // image: DecorationImage(
            //   image: AssetImage("asset/image/bg1.png"),
            //   fit: BoxFit.cover,
            // ),
            // boxShadow: [
            //   BoxShadow(
            //     color: Colors.grey[200],
            //   ),
            //   BoxShadow(
            //     color: Colors.transparent,
            //     spreadRadius: -12.0,
            //     blurRadius: 12.0,
            //   ),
            // ],
          ),
          child: Center(
            child: Image.network(widget.src),
          )
      ),
    );
  }
}

