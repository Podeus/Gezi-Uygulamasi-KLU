import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf_viewer_plugin/pdf_viewer_plugin.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

import '../appbar/baseAppbar.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
class ShowPdfView extends StatefulWidget {
  String url;
  String text;
  ShowPdfView({this.url,this.text});
  @override
  _ShowPdfViewState createState() => _ShowPdfViewState();
}

class _ShowPdfViewState extends State<ShowPdfView> {
  String path;
  bool opened =false;

  @override
  initState() {
    super.initState();
  }

  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();

    return directory.path;
  }

  Future<File> get _localFile async {
    final path = await _localPath;
    return File('$path/teste.pdf');
  }

  Future<File> writeCounter(Uint8List stream) async {
    final file = await _localFile;

    // Write the file
    return file.writeAsBytes(stream);
  }

  Future<Uint8List> fetchPost() async {
    // final response = await http.get(
    //     '${widget.url}');
    // final responseJson = response.bodyBytes;
    //
    // return responseJson;
  }

  loadPdf() async {
    writeCounter(await fetchPost());
    path = (await _localFile).path;
    opened = !opened;

    if (!mounted) return;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    return Scaffold(
      appBar: BaseAppBar(
        title: Text("${widget.text}",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: _currentTheme.textSelectionColor)),
        // image: Image.asset("asset/image/logo.png",height: 30,),
        appBar: AppBar(),
        // backgroundColor:Color(0xffe6e6e6),
        leading: (Navigator.canPop(context) ? IconButton(
          icon: FaIcon(
            FontAwesomeIcons.longArrowAltLeft,
            color: Colors.black,
            size: 25,
          ),
          onPressed: () => locator<NavigationService>().goBack(),
        ) : null),
      ),
      backgroundColor: _currentTheme.backgroundColor,
        body: Container(
          decoration: BoxDecoration(
            // image: DecorationImage(
            //   image: AssetImage("asset/image/bg1.png"),
            //   fit: BoxFit.cover,
            // ),
            // boxShadow: [
            //   BoxShadow(
            //     color: Colors.grey[200],
            //   ),
            //   BoxShadow(
            //     color: Colors.transparent,
            //     spreadRadius: -12.0,
            //     blurRadius: 12.0,
            //   ),
            // ],
          ),
          child:Center(
          child: Column(
            children: <Widget>[
              path != null ?
                Container(
                  height: MediaQuery.of(context).size.height * 0.8,
                  child: PdfView(
                    path: path,
                  ),
                )
              :
                Text(""),
              opened == false ? FlatButton(
                child: Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    border: Border.all(
                        color: Colors.orange,
                        width: 1.0
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(15.0),
                    ),
                    color: Colors.white,
                  ),
                  child: Column(
                    children: [
                      Text("Pdf Görüntülemek için tıklayın"),
                    ],
                  ),
                ),
                onPressed: loadPdf,
              ) : Text(""),
            ],
          ),
        ),
        ),
      );
  }
}