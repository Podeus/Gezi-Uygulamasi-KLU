import 'package:intl/intl.dart';
extension StringExtension on String {
  String totcapitalize() {
    return "${this[0].toUpperCase()}${this.substring(1)}";
  }
}
extension EasyString on String {
  String capitalize() {
    var lowerCased = this.toLowerCase();
    var lowerCased_split = lowerCased.split(" ");
    var new_string = "";
    lowerCased_split.forEach((String rune) {
      new_string += toBeginningOfSentenceCase(rune[0]).toUpperCase() + toBeginningOfSentenceCase(rune).substring(1) + " ";
    });
    return new_string;
  }
}