const String mainPath = "";
const String mainUrl = mainPath+"/api";
const String registerOrUpdateActionUrl = mainUrl+"/device/registerOrUpdateAction";
const String loginActionUrl = mainUrl+"/users/LoginAction";
const String signupActionUrl = mainUrl+"/users/SignupAction";
const String forgetActionUrl = mainUrl+"/users/forgetAction";
const String forgetAcceptActionUrl = mainUrl+"/users/forgetAcceptAction";
const String logoutActionUrl = mainUrl+"/users/logoutAction";
const String checkUserActionUrl = mainUrl+"/users/checkUserAction";

const String get_all_notificationUrl = mainUrl+"/notifications/get_all_notification";
const String contactFormActionUrl = mainUrl+"/forms/contactFormAction";
const String contentget_get_faq_textUrl = mainUrl+"/content/get_faq";
const String contentget_headUrl = mainUrl+"/content/get_head";
const String contentget_get_head_textUrl = mainUrl+"/content/get_head_text";
const String saveUserInfoActionUrl = mainUrl+"/users/saveUserInfo";
const String setSettingsUrl = mainUrl+"/users/setSettings";
const String save_user_infosUrl = mainUrl+"/users/save_user_infos";



const String get_all_couponsUrl = mainUrl+"/coupons/get_all_coupons";
const String get_all_users_couponsUrl = mainUrl+"/coupons/get_all_users_coupons";
const String couponsfavoriteActionUrl = mainUrl+"/coupons/favoriteAction";

const String get_all_storesUrl = mainUrl+"/stores/get_all_stores";
const String get_all_users_storesUrl = mainUrl+"/stores/get_all_users_stores";
const String storesfavoriteActionUrl = mainUrl+"/stores/favoriteAction";

const String getCategoriesStoresFromCatgegoryIdUrl = mainUrl+"/stores/get_all_stores_from_category_id";
