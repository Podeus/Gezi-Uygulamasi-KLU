import 'dart:io';
import 'dart:math';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/handlers/notification_handler.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:audioplayers/audioplayers.dart';
class FirebaseNotifications{
  FirebaseMessaging _messaging;
  BuildContext myContext;
  FirebaseAuth auth = FirebaseAuth.instance;
  Stream<String> _tokenStream;
  DialogService _dialogService = locator<DialogService>();
  void update_user_token(token)async{
    print("updateable token ${token}");
    var _prefs = await SharedPreferences.getInstance();
    _prefs.setString('push_token',token);
    var user = FirebaseAuth.instance.currentUser;
    if(user!=null){
      FirebaseFirestore db = FirebaseFirestore.instance;
      var roomRef = db
          .collection('users')
          .where('user_id',isEqualTo: user.uid)
      ;
      var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
        querySnapshot.docs.forEach((doc) async{
          print("doc ${doc.id}");
          DocumentReference userRef = db.collection('users').doc(doc.id);
          Map<String, dynamic> roomWithOffer;
          roomWithOffer = {
            'push_token': token
          };
          await userRef.update(roomWithOffer);
        });

      });
    }else{
      print("token updatede edilemedi 1");
    }
  }
  void setupFirebase(BuildContext context){

    _messaging = FirebaseMessaging.instance;
    if(kIsWeb){

    }else{
      NotificationHandler.initNotification(context);
    }
    firebaseCloudMessageListener(context);
    myContext = context;
  }

  void firebaseCloudMessageListener(BuildContext context) async{
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      announcement: true,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true
    );
    print("firebaseCloudMessageListener Settings ${settings.authorizationStatus}");
    //Get Token
    // We will use tokken to receive notification
    if(kIsWeb){
      _messaging.getToken().then(update_user_token);
      _tokenStream = _messaging.onTokenRefresh;
      _tokenStream.listen(update_user_token);
    }else{
      _messaging.getToken().then((token) async{
        print("MyToken: $token");
        await update_user_token(token);
      });

      _messaging.subscribeToTopic("edmtdev_demo")
          .whenComplete(() => print("Subscribe OK"));
    }


    //handle message
    FirebaseMessaging.onMessage.listen((remoteMessage) async{
      // print("Receive $remoteMessage");

      if(kIsWeb){
        // try{
        //   print("ses çalıyor3");
        //   AudioCache player = new AudioCache();
        //   const alarmAudioPath = "sound/base.mp3";
        //   player.play(alarmAudioPath);
        // } catch (e) {
        //   print("Could Not Load Data backgroundMessageHandler: $e");
        //   return null;
        // }
        print("kIsWeb içinde 1");
        if (remoteMessage.notification != null) {
          print(
              'Message also contained a notification: ${remoteMessage.notification.body}');
          // await _dialogService.showDialog(
          //     title: "unlem",
          //     description: remoteMessage.notification.body,
          //     buttonTitle: "Tamam"
          // );
        }
      }else{
        if(Platform.isAndroid){
          showNotification(remoteMessage.data["title"],remoteMessage.data["body"]);
        }else if(Platform.isIOS){
          showNotification(remoteMessage.notification.title,remoteMessage.notification.body);
        }
        // await _dialogService.showDialog(
        //     title: "unlem",
        //     description: remoteMessage.notification.body,
        //     buttonTitle: "Tamam"
        // );
      }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((remoteMessage) async{
      // print("Receive open app : $remoteMessage");
      if(kIsWeb){
        // try{
        //   print("ses çalıyor2");
        //   AudioCache player = new AudioCache();
        //   const alarmAudioPath = "sound/base.mp3";
        //   await player.play(alarmAudioPath);
        // } catch (e) {
        //   print("Could Not Load Data backgroundMessageHandler: $e");
        //   return null;
        // }
        print("kIsWeb içinde 2");
        if (remoteMessage.notification != null) {
          print(
              'Message also contained a notification: ${remoteMessage.notification.body}');
          // await _dialogService.showDialog(
          //       title: "unlem",
          //       description: remoteMessage.notification.body,
          //       buttonTitle: "Tamam"
          //   );
        }
      }else{
        if(Platform.isIOS || Platform.isAndroid){
          await _dialogService.showDialog(
              title: "unlem",
              description: remoteMessage.notification.body,
              buttonTitle: "Tamam"
          );
        }
      }
    });
    // FirebaseMessaging.onBackgroundMessage((message) => null);

  }

  static Future<void> showNotification(title,body) async {
    // try{
    //   print("ses çalıyor3");
    //   AudioCache player = new AudioCache();
    //   const alarmAudioPath = "sound/base.mp3";
    //   player.play(alarmAudioPath);
    // } catch (e) {
    //   print("Could Not Load Data backgroundMessageHandler: $e");
    //   return null;
    // }
    var androidChannel = AndroidNotificationDetails(
        'com.geziuygulamasi.app', 'Gezi Uygulaması',
        autoCancel: false,
        ongoing: true,
        importance: Importance.max,
        priority: Priority.high,
        ticker: 'ticker',
        playSound: true,
        sound: RawResourceAndroidNotificationSound('arrive')
    );
    var iosChannel = IOSNotificationDetails();

    var platform = NotificationDetails(android: androidChannel,iOS: iosChannel);
    await NotificationHandler.flutterLocalNotificationPlugin.show(
        Random().nextInt(1000), title, body, platform,payload: 'My Payload'
    );

  }

}
