
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter_base/core/locator.dart';
class NotificationHandler{
  static final flutterLocalNotificationPlugin = FlutterLocalNotificationsPlugin();
  static BuildContext myContext;
  DialogService _dialogService = locator<DialogService>();
  static void initNotification(BuildContext context){
    myContext = context;
    var initAndroid = AndroidInitializationSettings("@mipmap/ic_launcher");
    var initIOS = IOSInitializationSettings(
      onDidReceiveLocalNotification: onDidReceiveLocalNotification
    );

    var initSettings = InitializationSettings(android: initAndroid,iOS: initIOS);
    flutterLocalNotificationPlugin.initialize(initSettings,onSelectNotification: onSelectNotification);

  }
  static Future onSelectNotification(String payload){
    if (payload != null){
      print("Get payload $payload");
    }
  }
  static Future onDidReceiveLocalNotification (int id,String title,String body,String payload)async{
    // showDialog(context: myContext, builder: (context) => CupertinoAlertDialog(
    //   title: Text(title),
    //   content: Text(body),
    //   actions: [
    //     CupertinoDialogAction(
    //       isDefaultAction: true,
    //         child: Text("ok"),
    //       onPressed: () => {
    //         Navigator.of(context,rootNavigator: true).pop(),
    //       },
    //     )
    //   ],
    // ));

    DialogService _dialogService = locator<DialogService>();
    await _dialogService.showDialog(
        title: "unlem",
        description: body,
        buttonTitle: "Tamam"
    );
  }
}