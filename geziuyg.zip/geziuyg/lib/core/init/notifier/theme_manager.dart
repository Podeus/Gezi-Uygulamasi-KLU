import 'package:flutter/material.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/theme/themes/light.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:shared_preferences/shared_preferences.dart';
class ThemeManager with ChangeNotifier {
  ThemeData _themeData;

  final _kThemePreference = "theme_preference";
  int _themeDataIndex = 0;
  int get themeDataIndex => _themeDataIndex;
  final Api _Api = locator<Api>();
  ThemeManager() {
    // We load theme at the start
    checkUserAction();
    // _loadTheme();
  }
  // ThemeData _currentTheme = lightTheme;
  // ThemeData get currentTheme => _currentTheme;
  void _loadTheme() {
    debugPrint("Entered loadTheme()");
    SharedPreferences.getInstance().then((prefs) {
      int preferredTheme = prefs.getInt(_kThemePreference) !=null ? prefs.getInt(_kThemePreference) : 0;
      // _themeData = appThemeData[AppTheme.values[preferredTheme]];
      setTheme(AppTheme.values[preferredTheme]);
      // Once theme is loaded - notify listeners to update UI
      // _currentTheme = _themeData;
      print("_themeData geldi");
      notifyListeners();
    });
  }
  Future<dynamic> checkUserAction() async {
    // await Future.delayed(Duration(seconds: 1));

    try {
      // final response = await _Api.checkUserAction();
      // // var _prefs = await SharedPreferences.getInstance();
      // // print("checkUserAction ${response}");
      // // print("checkUserAction ${response["access_token"]}");
      // if (response ==null) {
      // } else {
      //   SharedPreferences prefs = await SharedPreferences.getInstance();
      //   prefs.setInt('theme_preference', response["device"]["dark_mode"] =="1" ? 1 : 0);
      //   notifyListeners();
      //
      //   _loadTheme();
      // }
    } catch (e) {
      print(e);
    }
  }

  /// Use this method on UI to get selected theme.
  ThemeData get themeData {
    if (_themeData == null) {
      _themeData = appThemeData[AppTheme.White];
    }
    return _themeData;
  }


  /// Sets theme and notifies listeners about change.
  setTheme(AppTheme theme) async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setInt(_kThemePreference, AppTheme.values.indexOf(theme));

    _themeData = appThemeData[theme];
    _themeDataIndex =  AppTheme.values.indexOf(theme);
    // Here we notify listeners that theme changed
    // so UI have to be rebuild
    notifyListeners();
  }
}