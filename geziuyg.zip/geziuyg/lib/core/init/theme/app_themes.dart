import 'package:flutter/material.dart';

enum AppTheme {
  White, Dark
}

/// Returns enum value name without enum class name.
String enumName(AppTheme anyEnum) {
  return anyEnum.toString().split('.')[1];
}

final appThemeData = {
  AppTheme.White : ThemeData(
      brightness: Brightness.light,
      primaryColor: Colors.black,
      primaryColorBrightness: Brightness.dark,
      primaryColorLight: Color(0xffFFFFFF),
      primaryColorDark: Color(0xff000000),
      accentColor: Color(0xfff44336),
      accentColorBrightness: Brightness.dark,
      canvasColor: Color(0xFFF5F5F5), //XX
      scaffoldBackgroundColor: Color(0xfffafafa), //xx
      bottomAppBarColor: Color(0xffffffff),
      cardColor: Color(0xffffffff),
      dividerColor: Color(0xFFE5E5E5), //XX
      highlightColor: Color(0x66bcbcbc),
      splashColor: Color(0xffE8E8E8),
      selectedRowColor: Color(0xfff5f5f5),
      unselectedWidgetColor: Color(0xFFE5E5E5),
      disabledColor: Color(0x61000000), //xx
      buttonColor: Color(0xffe0e0e0),
      toggleableActiveColor: Color(0xffe53935),
      secondaryHeaderColor: Color(0xffF2F2F2),
      textSelectionColor: Color(0xff000000),
      cursorColor: Color(0xff4285f4),
      textSelectionHandleColor: Color(0xff808080),
      backgroundColor: Colors.white,
  ),
  AppTheme.Dark : ThemeData(
      brightness: Brightness.dark,
      primaryColor: Colors.white,
      primaryColorBrightness: Brightness.dark,
      primaryColorLight: Color(0xffFFFFFF),
      primaryColorDark: Color(0xff000000),
      accentColor: Color(0xfff44336),
      accentColorBrightness: Brightness.dark,
      canvasColor: Color(0xFF000000), //XX
      scaffoldBackgroundColor: Color(0xfffafafa), //xx
      bottomAppBarColor: Color(0xffffffff),
      cardColor: Color(0xff3D3D3D),

      dividerColor: Color(0xFFE5E5E5), //XX
      highlightColor: Color(0x66bcbcbc),
      splashColor: Color(0xffE8E8E8),
      selectedRowColor: Color(0xfff5f5f5),
      unselectedWidgetColor: Color(0xFF4D4D4D),
      disabledColor: Color(0x61000000), //xx
      buttonColor: Color(0xffe0e0e0),
      toggleableActiveColor: Color(0xffe53935),
      secondaryHeaderColor: Color(0xFF292929),
      textSelectionColor: Color(0xffffffff),
      cursorColor: Color(0xff4285f4),
      textSelectionHandleColor: Color(0xff808080),
      backgroundColor: Colors.black,
  )
};