import 'package:get_it/get_it.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/device_info_service.dart';
import 'package:flutter_base/core/services/view/authentication_service.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:flutter_base/core/services/view/firebase_service.dart';
// import 'package:flutter_base/src/services/firestore_service.dart';
// import 'package:flutter_base/src/utils/image_selector.dart';

GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton(() => NavigationService());
  locator.registerLazySingleton(() => DialogService());
  locator.registerLazySingleton(() => DeviceInfoService());
  locator.registerLazySingleton(() => AuthenticationService());
  // locator.registerLazySingleton(() => PushNotificationService());
  locator.registerLazySingleton(() => FirebaseService());

  // locator.registerLazySingleton(() => FirestoreService());
  // locator.registerLazySingleton(() => AuthenticationService());
  // locator.registerLazySingleton(() => FirestoreService());
  // locator.registerLazySingleton(() => CloudStorageService());
  // locator.registerLazySingleton(() => ImageSelector());

  locator.registerLazySingleton(() => Api());
}
