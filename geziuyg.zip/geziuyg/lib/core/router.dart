import'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/view/authenticate/login/view/login_email_view.dart';

import 'package:flutter_base/view/authenticate/signup/view/signup_email_view.dart';
import 'package:flutter_base/view/basic/splash/view/splash_view.dart';
import 'package:flutter_base/view/basic/home/view/home_view.dart';
import 'package:flutter_base/view/custom/categorilist/view/category_screen_view.dart';
import 'package:flutter_base/view/custom/categorilist/view/product_screen_view.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  print("settings ${settings}");
  switch (settings.name) {
    case routes.splashRoute:
      return MaterialPageRoute(builder: (context) => SplashView());
    case routes.loginEmailRoute:
      return MaterialPageRoute(builder: (context) => LoginEmailView());
    case routes.signupRoute:
      return MaterialPageRoute(builder: (context) => SignupEmailView());
    // case routes.forgetRoute:
    //   return MaterialPageRoute(builder: (context) => ForgetView());
    // case routes.forgetAcceptRoute:
    //   // var Datas = settings.arguments as String;
    //   var newDatas = json.decode(json.encode(settings.arguments));
    //   var email = newDatas["email"] !=null ? newDatas["email"] : "";
    //   var username = newDatas["username"] !=null ? newDatas["username"] : "";
    //   var phone_number = newDatas["phone_number"] !=null ? newDatas["phone_number"] : "";
    //   var type = newDatas["type"] !=null ? newDatas["type"] : "";
    //   return MaterialPageRoute(builder: (context) => ForgetAcceptView(email:email,username:username,type: type,phone_number:phone_number));

    case routes.homeRoute:
      return MaterialPageRoute(builder: (context) => HomeView());
    case routes.categoryRoute:
      var newDatas = json.decode(json.encode(settings.arguments));
      var id = newDatas["id"] !=null ? newDatas["id"] : "";
      var name = newDatas["name"] !=null ? newDatas["name"] : "";
      return MaterialPageRoute(builder: (context) => CategoryScreenView(id:id,name:name));
    case routes.productViewRoute:
      var newDatas = json.decode(json.encode(settings.arguments));
      var id = newDatas["id"] !=null ? newDatas["id"] : "";
      var title = newDatas["title"] !=null ? newDatas["title"] : "";
      var desc = newDatas["desc"] !=null ? newDatas["desc"] : "";
      var price = newDatas["price"] !=null ? newDatas["price"] : "";
      var image = newDatas["image"] !=null ? newDatas["image"] : "";
      var work_hour = newDatas["work_hour"] !=null ? newDatas["work_hour"] : "";
      return MaterialPageRoute(builder: (context) => ProductScreenView(id:id,title:title,desc:desc,price:price,image: image,work_hour:work_hour,));
    // case routes.settingsRoute:
    //   return MaterialPageRoute(builder: (context) => SettingsView());
    // case routes.notificationRoute:
    //   return MaterialPageRoute(builder: (context) => NotificationView());
    // case routes.notificationDetailRoute:
    //   var newDatas = json.decode(json.encode(settings.arguments));
    //   var id = newDatas["id"] !=null ? newDatas["id"] : "";
    //   var jsonencode = newDatas["jsonencode"] !=null ? newDatas["jsonencode"] : "";
    //   return MaterialPageRoute(builder: (context) => NotificationDetailView(id:id,jsonencode:jsonencode));
    // case routes.languageRoute:
    //   return MaterialPageRoute(builder: (context) => LanguageView());
    case routes.emptyRoute:
      return MaterialPageRoute(
        builder: (context) => Scaffold(
          body: Center(
            child: Text('No path for ${settings.name}'),
          ),
        ),
      );
    default:
      return MaterialPageRoute(
        builder: (context) => Scaffold(
          body: Center(
            child: Text('No path for ${settings.name}'),
          ),
        ),
      );
  }
}
