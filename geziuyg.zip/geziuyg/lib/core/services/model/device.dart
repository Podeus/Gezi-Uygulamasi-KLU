class DeviceResponse {
  List<Device> devices;
  DeviceResponse({this.devices});
  DeviceResponse.fromJson(dynamic json) {
    devices = new List<Device>();
    json.forEach((v) {
      devices.add(new Device.fromJson(v));
    });
  }


}

class Device {
  String device_id;
  String message;
  String access_token;
  // String brand;
  // String model;
  // String os_version;
  // String os_type;
  // String push_token;
  // String app_version;
  // String local_language;

  Device({
    this.device_id,
    this.message,
    this.access_token,
    // this.brand,
    // this.model,
    // this.os_version,
    // this.os_type,
    // this.push_token,
    // this.app_version,
    // this.local_language,

  });
  Device.fromJson(Map<String, dynamic> json) {
    device_id = json['device_id'];
    message = json['message'];
    access_token = json['access_token'];
    // brand = json['brand'];
    // model = json['model'];
    // os_version = json['os_version'];
    // os_type = json['os_type'];
    // push_token = json['push_token'];
    // app_version = json['app_version'];
    // local_language = json['local_language'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['access_token'] = this.access_token;
    // data['brand'] = this.brand;
    // data['model'] = this.model;
    return data;
  }

}