import 'package:flutter/foundation.dart';

class Markers {
  final String muId;
  final String vehicle_id;
  final String user;
  final String plate;
  final String modelName;
  final String brandName;
  final String price;
  final String backupBatteryVoltage;
  final String mainSupplyVoltage;
  final String mainPowerRegulatedVoltage;
  final String speed;
  final String country;
  final String city;
  final String town;
  final String quarter;
  final String way;
  final String longitude;
  final String latitude;
  final String altitude;
  final String distance;
  final String speedDirection;
  final String type;
  final String driverId;
  final String lastDriverEventId;
  final String eventTimePeriod;
  final String cityCode;
  final String districtCode;
  final String state;
  final String operationMode;
  final String emergencyMode;
  final String engine;
  final String ignition;
  final String idleSpeed;
  final String overSpeed;
  final String shock;
  final String hood;
  final String door;
  final String distress;
  final String mainPower;
  final String backupBattery;
  final String mainPowerConn;
  final String backupBatteryConn;
  final String gpsConn;

  Markers({
    @required this.muId,
    @required this.vehicle_id,
    this.user,
    this.plate,
    this.modelName,
    this.brandName,
    this.price,
    this.backupBatteryVoltage,
    this.mainSupplyVoltage,
    this.mainPowerRegulatedVoltage,
    this.speed,
    this.country,
    this.city,
    this.town,
    this.quarter,
    this.way,
    this.longitude,
    this.latitude,
    this.altitude,
    this.distance,
    this.speedDirection,
    this.type,
    this.driverId,
    this.lastDriverEventId,
    this.eventTimePeriod,
    this.cityCode,
    this.districtCode,
    this.state,
    this.operationMode,
    this.emergencyMode,
    this.engine,
    this.ignition,
    this.idleSpeed,
    this.overSpeed,
    this.shock,
    this.hood,
    this.door,
    this.distress,
    this.mainPower,
    this.backupBattery,
    this.mainPowerConn,
    this.backupBatteryConn,
    this.gpsConn
  });

  Map<String, dynamic> toMap() {
    return {
      "muId": this.muId,
      "user": this.user,
      "vehicle_id": this.vehicle_id,
      "plate": this.plate,
      "modelName": this.modelName,
      "brandName": this.brandName,
      "price": this.price,
      "backupBatteryVoltage": this.backupBatteryVoltage,
      "mainSupplyVoltage": this.mainSupplyVoltage,
      "mainPowerRegulatedVoltage": this.mainPowerRegulatedVoltage,
      "speed": this.speed,
      "country": this.country,
      "city": this.city,
      "town": this.town,
      "quarter": this.quarter,
      "way": this.way,
      "longitude": this.longitude,
      "latitude": this.latitude,
      "altitude": this.altitude,
      "distance": this.distance,
      "speedDirection": this.speedDirection,
      "type": this.type,
      "driverId": this.driverId,
      "lastDriverEventId": this.lastDriverEventId,
      "eventTimePeriod": this.eventTimePeriod,
      "cityCode": this.cityCode,
      "districtCode": this.districtCode,
      "state": this.state,
      "operationMode": this.operationMode,
      "emergencyMode": this.emergencyMode,
      "engine": this.engine,
      "ignition": this.ignition,
      "idleSpeed": this.idleSpeed,
      "overSpeed": this.overSpeed,
      "shock": this.shock,
      "hood": this.hood,
      "door": this.door,
      "distress": this.distress,
      "mainPower": this.mainPower,
      "backupBattery": this.backupBattery,
      "mainPowerConn": this.mainPowerConn,
      "backupBatteryConn": this.backupBatteryConn,
      "gpsConn": this.gpsConn
    };
  }

  static Markers fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Markers(
      muId: map['muId'],
      user: map['user'],
      vehicle_id: map['vehicle_id'],
      plate: map['plate'],
      modelName: map['modelName'],
      brandName: map['brandName'],
      price: map['price'],
      backupBatteryVoltage: map['backupBatteryVoltage'],
      mainSupplyVoltage: map['mainSupplyVoltage'],
      mainPowerRegulatedVoltage: map['mainPowerRegulatedVoltage'],
      speed: map['speed'],
      country: map['country'],
      city: map['city'],
      town: map['town'],
      quarter: map['quarter'],
      way: map['way'],
      longitude: map['longitude'],
      latitude: map['latitude'],
      altitude: map['altitude'],
      distance: map['distance'],
      speedDirection: map['speedDirection'],
      type: map['type'],
      driverId: map['driverId'],
      lastDriverEventId: map['lastDriverEventId'],
      eventTimePeriod: map['eventTimePeriod'],
      cityCode: map['cityCode'],
      districtCode: map['districtCode'],
      state: map['state'],
      operationMode: map['operationMode'],
      emergencyMode: map['emergencyMode'],
      engine: map['engine'],
      ignition: map['ignition'],
      idleSpeed: map['idleSpeed'],
      overSpeed: map['overSpeed'],
      shock: map['shock'],
      hood: map['hood'],
      door: map['door'],
      distress: map['distress'],
      mainPower: map['mainPower'],
      backupBattery: map['backupBattery'],
      mainPowerConn: map['mainPowerConn'],
      backupBatteryConn: map['backupBatteryConn'],
      gpsConn: map['gpsConn']
    );
  }
}
