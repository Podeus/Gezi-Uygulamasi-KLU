import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class Sms {
  @JsonKey(name: "title")
  final String title;
  @JsonKey(name: "message")
  final String message;
  @JsonKey(name: "true_code")
  final String true_code;

  Sms({this.title, this.message, this.true_code});

  Sms.initial()
      : title = '',
        message = '',
        true_code = '';


  factory Sms.fromJson(Map<String, dynamic> json) {
    return Sms(
      title: json['title'],
      message: json['message'],
      true_code: json['true_code'],
    );
  }
  Map<String, dynamic> toJson() => _$SmsModelToJson(this);

  @override
  String toString() {
    return "$true_code".toString();
  }


  // Sms.fromJson(Map<String, dynamic> json) {
  //   true_code = json['true_code'];
  // }
  //
  // Map<String, dynamic> toJson() {
  //   final Map<String, dynamic> data = new Map<String, dynamic>();
  //   data['true_code'] = this.true_code;
  //   return data;
  // }
}
Map<String, dynamic> _$SmsModelToJson(Sms instance) => <String, dynamic>{
  'title': instance.title,
  'message': instance.message,
  'true_code': instance.true_code
};