class User {
  int id;
  String name;
  String surname;
  String username;
  String full_name;
  String email;
  String phone_number;
  String city;
  String town;
  String avatar;
  String created_at;
  String updated_at;

  User({
    this.id,
    this.name,
    this.surname,
    this.full_name,
    this.username,
    this.email,
    this.phone_number,
    this.city,
    this.town,
    this.avatar,
    this.created_at,
    this.updated_at,
  });

  User.initial()
      : id = 0,
        name = '',
        surname = '',
        full_name = '',
        username = '',
        email = '',
        phone_number = '',
        city = '',
        town = '',
        avatar = '',
        created_at = '',
        updated_at = '';

  User.fromJson(Map<String, dynamic> json) {
    id = json["user"]['id'];
    name = json["user"]['name'];
    surname = json["user"]['surname'];
    full_name = json["user"]['full_name'];
    username = json["user"]['username'];
    email = json["user"]['email'];
    phone_number = json["user"]['phone_number'];
    city = json["user"]['city'];
    town = json["user"]['town'];
    avatar = json["user"]['avatar'];
    created_at = json["user"]['created_at'];
    updated_at = json["user"]['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['surname'] = this.surname;
    data['full_name'] = this.full_name;
    data['username'] = this.username;
    data['email'] = this.email;
    data['phone_number'] = this.phone_number;
    data['city'] = this.city;
    data['town'] = this.town;
    data['avatar'] = this.avatar;
    data['created_at'] = this.created_at;
    data['updated_at'] = this.updated_at;
    return data;
  }
}
