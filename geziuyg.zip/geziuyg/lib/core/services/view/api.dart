import 'dart:convert';

import 'package:flutter_base/core/services/model/user.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
/// The service responsible for networking requests
class Api {
  static const endpoint = 'https://jsonplaceholder.typicode.com';

  var client = new http.Client();

  // Future<User> getUserProfile(int userId) async {
  //   // Get user profile for id
  //   var response = await client.get('$endpoint/users/$userId');
  //
  //   // Convert and return
  //   return User.fromJson(json.decode(response.body));
  // }

  // Future<dynamic> login(String username,String password) async {
  //   try {
  //     print("login username ${username}");
  //     print("login password ${password}");
  //     // var _data = await http.get(apiURL);
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     // print("prefs.getString('device_id') ${prefs.getString('device_id')}");
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'username': username,
  //       'password': password
  //     };
  //     final response = await client.post(
  //       loginActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     return json.decode(response.body);
  //   } catch (e) {
  //     print("Could Not Load Data getinfo: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> signup(
  //     String name,
  //     String surname,
  //     String username,
  //     String email,
  //     String phone_number,
  //     String password,
  //     String password_repeat,
  //     String born_date,
  // ) async {
  //   try {
  //     print("signup username ${username}");
  //     print("signup password ${password}");
  //     // var _data = await http.get(apiURL);
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     // print("prefs.getString('device_id') ${prefs.getString('device_id')}");
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'name': name,
  //       'surname': surname,
  //       'username': username,
  //       'email': email,
  //       'phone_number': phone_number,
  //       'password': password,
  //       'password_repeat': password_repeat,
  //       'born_date': born_date,
  //     };
  //     final response = await client.post(
  //       signupActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     return json.decode(response.body);
  //   } catch (e) {
  //     print("Could Not Load Data getinfo: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> forget(
  //     String username,
  //     String email,
  //     String phone_number,
  //     ) async {
  //   try {
  //     print("signup username ${username}");
  //     print("signup email ${email}");
  //     // var _data = await http.get(apiURL);
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     // print("prefs.getString('device_id') ${prefs.getString('device_id')}");
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'username': username,
  //       'email': email,
  //       'phone_number': phone_number
  //     };
  //     final response = await client.post(
  //       forgetActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     return json.decode(response.body);
  //   } catch (e) {
  //     print("Could Not Load Data getinfo: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> forgetAccept(
  //     String code,
  //     String password,
  //     String password_repeat,
  //     String type,
  //     String email,
  //     String username,
  //     String phone_number,
  //     ) async {
  //   try {
  //     print("forgetAccept code ${code}");
  //     // var _data = await http.get(apiURL);
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     // print("prefs.getString('device_id') ${prefs.getString('device_id')}");
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'code': code,
  //       'password': password,
  //       'password_repeat': password_repeat,
  //       'type': type,
  //       'email': email,
  //       'username': username,
  //       'phone_number': phone_number,
  //     };
  //     final response = await client.post(
  //       forgetAcceptActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     return json.decode(response.body);
  //   } catch (e) {
  //     print("Could Not Load Data getinfo: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> logout() async {
  //   print("clicked logout");
  //   SharedPreferences.getInstance().then((prefs) {
  //     prefs.setString("user_data", null);
  //   });
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //   };
  //   final response = await http.post(
  //     logoutActionUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //
  //   return json.decode(response.body);
  // }
  // Future<dynamic> checkUserAction() async {
  //   print("clicked checkUserAction");
  //   // SharedPreferences.getInstance().then((prefs) {
  //   //   prefs.setString("user_data", null);
  //   // });
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //   };
  //   final response = await http.post(
  //     checkUserActionUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //
  //   return json.decode(response.body);
  // }
  // Future<dynamic> setSettings(darkMode,notification) async {
  //   print("clicked setSettings");
  //   // SharedPreferences.getInstance().then((prefs) {
  //   //   prefs.setString("user_data", null);
  //   // });
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //     'dark_mode': darkMode !=null ? darkMode : null,
  //     'notification': notification !=null ? notification : null,
  //   };
  //   final response = await http.post(
  //     setSettingsUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //
  //   return json.decode(response.body);
  // }
  //
  // Map udata;
  // Map userData;
  //
  // // Future<dynamic> saveUserInfoAction(String new_json2,String savetype) async {
  // //   print("clicked api saveUserInfoAction");
  // //   SharedPreferences prefs = await SharedPreferences.getInstance();
  // //   var new_j = json.decode(new_json2);
  // //   var new_json = <String, String>{
  // //     'device_id': prefs.getString('device_id'),
  // //     'access_token': prefs.getString('access_token'),
  // //     'name':new_j["name"],
  // //     'surname':new_j["surname"],
  // //     'email':new_j["email"],
  // //     'tc':new_j["tc"],
  // //     'born_date':new_j["born_date"],
  // //     'save_type':savetype,
  // //   };
  // //   final response = await http.post(
  // //     saveUserInfoActionUrl,
  // //     headers: <String, String>{
  // //       'Content-Type': 'application/json; charset=UTF-8',
  // //     },
  // //     body: jsonEncode(new_json),
  // //   );
  // //   print("response.body ${response.body}");
  // //   return json.decode(response.body);
  // // }
  // // Future<dynamic> saveContractsAction() async {
  // //   print("clicked api saveContractsAction");
  // //   SharedPreferences prefs = await SharedPreferences.getInstance();
  // //   var new_json = <String, String>{
  // //     'device_id': prefs.getString('device_id'),
  // //     'access_token': prefs.getString('access_token'),
  // //     'count':"6",
  // //   };
  // //   final response = await http.post(
  // //     saveContractsActionUrl,
  // //     headers: <String, String>{
  // //       'Content-Type': 'application/json; charset=UTF-8',
  // //     },
  // //     body: jsonEncode(new_json),
  // //   );
  // //
  // //   return json.decode(response.body);
  // // }
  // Future<dynamic> get_content(id) async {
  //   print("clicked api get_content");
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //     'content_id':id,
  //   };
  //   final response = await http.post(
  //     contentget_headUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //
  //   return json.decode(response.body);
  // }
  // Future<dynamic> saveUserInfoAction(String new_json2,String savetype) async {
  //   print("clicked api saveUserInfoAction");
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_j = json.decode(new_json2);
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //     'name':new_j["name"],
  //     'surname':new_j["surname"],
  //     'email':new_j["email"],
  //     'tc':new_j["tc"],
  //     'born_date':new_j["born_date"],
  //     'save_type':savetype,
  //   };
  //   final response = await http.post(
  //     saveUserInfoActionUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //   print("response.body ${response.body}");
  //   return json.decode(response.body);
  // }
  // Future<dynamic> getAllNotifications() async {
  //   print("comed getAllNotifications api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token')
  //     };
  //     final response = await client.post(
  //       get_all_notificationUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data getAllNotifications: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> getCategoriesStoresFromCatgegoryId(String id) async {
  //   print("comed getCategoriesStoresFromCatgegoryId api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'id': id,
  //     };
  //     final response = await client.post(
  //       getCategoriesStoresFromCatgegoryIdUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data getCategoriesStoresFromCatgegoryId: $e");
  //     return null;
  //   }
  // }
  //
  // Future<dynamic> send_contact_form(String newjson) async {
  //   var json_yeni = json.decode(newjson);
  //   print("comed send_contact_form api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'type':json_yeni["type"],
  //       'subject':json_yeni["subject"],
  //       'options':json_yeni["options"],
  //       'message':json_yeni["message"],
  //       'image':json_yeni["image"],
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       contactFormActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data send_contact_form: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> get_coupons(String order) async {
  //   // var json_yeni = json.decode(newjson);
  //   print("comed get_coupons api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'favorite':"0",
  //       'order':order,
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       get_all_couponsUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data send_contact_form: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> get_my_favorite_coupons(String order) async {
  //   // var json_yeni = json.decode(newjson);
  //   print("comed get_my_favorite_coupons api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'favorite':"1",
  //       'order':order,
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       get_all_users_couponsUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data send_contact_form: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> get_my_favorite_stores(String order) async {
  //   // var json_yeni = json.decode(newjson);
  //   print("comed get_my_favorite_stores api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'favorite':"1",
  //       'order':order,
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       get_all_users_storesUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data send_contact_form: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> CouponsFavoriteAction(String id,String used) async {
  //   // var json_yeni = json.decode(newjson);
  //   print("comed CouponsFavoriteAction api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'coupon_id':id,
  //       'used':used,
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       couponsfavoriteActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data CouponsFavoriteAction: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> StoresFavoriteAction(String id) async {
  //   // var json_yeni = json.decode(newjson);
  //   print("comed StoresFavoriteAction api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'store_id':id
  //     };
  //     print("new_json ${new_json}");
  //     final response = await client.post(
  //       storesfavoriteActionUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data CouponsFavoriteAction: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> get_faq(String store,String popularity) async {
  //   print("comed get_faq api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       "store":store,
  //       "popularity":popularity,
  //     };
  //     final response = await client.post(
  //       contentget_get_faq_textUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data get_faq: $e");
  //     return null;
  //   }
  // }
  // Future<dynamic> getStoreFromId(String store_id) async {
  //   print("comed getStoreFromId api");
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //       'access_token': prefs.getString('access_token'),
  //       'store_id': store_id,
  //     };
  //     final response = await client.post(
  //       get_all_storesUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.encode(response.body) ${response.body}");
  //     return json.decode(json.decode(json.encode(response.body)));
  //   } catch (e) {
  //     print("Could Not Load Data getStoreFromId: $e");
  //     return null;
  //   }
  // }
  //
  // Future<dynamic> save_user_infos(String language) async {
  //   print("clicked save_auto_insert");
  //   // SharedPreferences.getInstance().then((prefs) {
  //   //   prefs.setString("user_data", null);
  //   // });
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var new_json = <String, String>{
  //     'device_id': prefs.getString('device_id'),
  //     'access_token': prefs.getString('access_token'),
  //     'language': language,
  //   };
  //   print(new_json);
  //   final response = await http.post(
  //     save_user_infosUrl,
  //     headers: <String, String>{
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(new_json),
  //   );
  //
  //   return json.decode(response.body);
  // }

}
