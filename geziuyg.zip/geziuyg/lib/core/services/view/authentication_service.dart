import 'dart:async';

import 'package:flutter_base/core/services/model/user.dart';
import 'package:flutter_base/core/services/model/sms.dart';

import 'package:flutter_base/core/locator.dart';
import 'api.dart';

class AuthenticationService {
  Api _api = locator<Api>();

  StreamController<User> userController = StreamController<User>();
  StreamController<Sms> smsController = StreamController<Sms>();

  Future<dynamic> login(String username,String password) async {
    // var fetchedUser = await _api.login(username,password);
    // print("fetchedUser ${fetchedUser}");
    // var hasUser = fetchedUser != null;
    // if(hasUser) {
    //   // userController.add(fetchedUser);
    // }
    //
    // return fetchedUser;
  }

  Future<dynamic> checkUserAction() async {
    // var fetchedUser = await _api.checkUserAction();
    // return fetchedUser;
  }

  // Future<dynamic> saveUserInfoAction(new_json) async {
  //   var fetchedUser = await _api.saveUserInfoAction(new_json,"");
  //   return fetchedUser;
  // }

  Future<bool> logout() async {
    // var fetchedUser = await _api.logout();
    return true;
  }

  // Future<dynamic> send_sms(String phoneNumber) async {
  //   var fetchedSms = await _api.smsgetdata(phoneNumber);
  //   return fetchedSms;
  // }
}