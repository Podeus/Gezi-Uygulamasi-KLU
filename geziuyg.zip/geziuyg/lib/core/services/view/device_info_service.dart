import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:device_info/device_info.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:package_info/package_info.dart';

import 'package:flutter_base/core/services/model/device.dart';
import 'package:http/http.dart' show Client;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_base/core/constants/api_urls.dart';

import 'package:flutter_base/core/generated/localization/language_constants.dart';
class DeviceInfoService {
  Client client = Client();
  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  Map<String, dynamic> _deviceData = <String, dynamic>{};

  Future<void> initPlatformState(token) async {
    Map<String, dynamic> deviceData;

    try {
      // print("burası 111");
      if (Platform.isAndroid) {
        // print("burası 1111222222");
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
      } else if (Platform.isIOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
      }
      // print("burası 111");
      // print('TEST deviceData ${deviceData}');

      // String json1 = jsonEncode(deviceData);
      //
      // Map<String, dynamic> new_datas = jsonDecode(json);

      // final json = jsonDecode(json1);
      // return Device.fromJson(json);

      // return jsonDecode(json);
      return registerOrUpdateAction(deviceData,token);
    } on PlatformException {
      deviceData = <String, dynamic>{
        'Error:': 'Failed to get platform version.'
      };
    }
  }
  Future<Device> registerOrUpdateAction(dynamic datas,String token) async {
    String json = jsonEncode(datas);
    // print("josn ${json}");
    Map<String, dynamic> new_datas = jsonDecode(json);
    Client client = Client();

    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String versionName = packageInfo.version;
    String versionCode = packageInfo.buildNumber;
    // print("versionName ${versionName}");
    // print("versionCode ${versionCode}");
    String defaultSystemLocale = Platform.localeName;
    // print('new_datas["brand"] ${new_datas["brand"]}');
    var new_json = <String, String>{
      'device_id': new_datas["device_id"],
      'brand': new_datas["brand"],
      'model': new_datas["model"],
      'os_version': new_datas["os_version"],
      'os_type': new_datas["os_type"],
      'push_token': token,
      'app_version': versionName,
      'local_language': defaultSystemLocale,
    };
    addDeviceIdToSF(new_datas["device_id"]);
    // print("new_json ${new_json}");
    // final response = await client.post(
    //   registerOrUpdateActionUrl,
    //   headers: <String, String>{
    //     'Content-Type': 'application/json; charset=UTF-8',
    //   },
    //   body: jsonEncode(new_json),
    // );
    // if (response.statusCode == 200) {
    //   // If the server did return a 201 CREATED response,
    //   // then parse the JSON.
    //   print("response.body ${response.body}");
    //   Map<String, dynamic> new_datas = jsonDecode(response.body);
    //   print("new_datas language ${new_datas}");
    //   // print("new_datas ${new_datas}");
    //   if(new_datas["access_token"] !=null){
    //     addAccesTokenToSF(new_datas["access_token"]);
    //   }
    //   if(new_datas["language"] !=null){
    //     print("language setLocale");
    //     // addLangToSF(new_datas["language"]);
    //     setLocale(new_datas["language"]);
    //   }
    //   if(new_datas["dark_mode"] !=null){
    //     addDarkMode(int.parse(new_datas["dark_mode"]));
    //     print('dark_mode int ${int.parse(new_datas["dark_mode"])}');
    //   }
    //   // return jsonDecode(response.body);
    //   return Device.fromJson(jsonDecode(response.body));
    // } else {
    //   // If the server did not return a 201 CREATED response,
    //   // then throw an exception.
    //   throw Exception('Failed to load album');
    // }
  }
  void addDarkMode(int dark_mode) async {
    try {
      // print("addAccesTokenToSF access_token ${access_token}");
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setInt('theme_preference', dark_mode);
      // print("burası");
    } catch (e) {
      print(e);
    }
  }
  void addAccesTokenToSF(String access_token) async {
    try {
      // print("addAccesTokenToSF access_token ${access_token}");
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString('access_token', access_token);
      // print("burası");
    } catch (e) {
      print(e);
    }
  }
  void addDeviceIdToSF(String device_id) async {
    try {
      // print("device_id ${device_id}");
      SharedPreferences prefs = await SharedPreferences.getInstance();
      // print("burası 21");
      prefs.setString('device_id', device_id);
      // print("burası 22");
    } catch (e) {
      print(e);
    }
  }
  void addLangToSF(String lang) async {
    try {
      // print("device_id ${device_id}");
      SharedPreferences prefs = await SharedPreferences.getInstance();
      print("dil değiştirildi ${lang}");
      prefs.setString('languageCode', lang);
      // print("burası 22");
    } catch (e) {
      print(e);
    }
  }
  Map<String, dynamic> _readAndroidBuildData(AndroidDeviceInfo build) {
    return <String, dynamic> {
      'device_id': build.androidId.toString(),
      'os_version': build.version.release.toString(),
      'os_type': "android",
      'brand': build.brand.toString(),
      'model': build.model.toString(),
      // 'version.securityPatch': build.version.securityPatch,
      // 'version.sdkInt': build.version.sdkInt,
      // 'version.previewSdkInt': build.version.previewSdkInt,
      // 'version.incremental': build.version.incremental,
      // 'version.codename': build.version.codename,
      // 'version.baseOS': build.version.baseOS,
      // 'board': build.board,
      // 'bootloader': build.bootloader,
      // 'device': build.device,
      // 'display': build.display,
      // 'fingerprint': build.fingerprint,
      // 'hardware': build.hardware,
      // 'host': build.host,
      // 'id': build.id,
      // 'manufacturer': build.manufacturer,
      // 'product': build.product,
      // 'supported32BitAbis': build.supported32BitAbis,
      // 'supported64BitAbis': build.supported64BitAbis,
      // 'supportedAbis': build.supportedAbis,
      // 'tags': build.tags,
      // 'type': build.type,
      // 'isPhysicalDevice': build.isPhysicalDevice,
      // 'systemFeatures': build.systemFeatures,
    };
  }

  Map<String, dynamic> _readIosDeviceInfo(IosDeviceInfo data) {
    return <String, dynamic>{
      'device_id': data.identifierForVendor,
      'os_version': "os_version",
      'os_type': "ios",
      'brand': "ios brand",
      'model': data.model,
      'name': data.name,
      'systemName': data.systemName,
      'systemVersion': data.systemVersion,
      'localizedModel': data.localizedModel,
      'isPhysicalDevice': data.isPhysicalDevice,
      'utsname.sysname:': data.utsname.sysname,
      'utsname.nodename:': data.utsname.nodename,
      'utsname.release:': data.utsname.release,
      'utsname.version:': data.utsname.version,
      'utsname.machine:': data.utsname.machine,
    };
  }

}
