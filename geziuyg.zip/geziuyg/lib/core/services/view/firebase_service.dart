import 'dart:async';
import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:http/http.dart' as http;
class FirebaseService {
  FirebaseAuth auth = FirebaseAuth.instance;
  final DialogService _dialogService = locator<DialogService>();
  final NavigationService _navigationService = locator<NavigationService>();
  Registration(String email,String password,name,surname) async{
    try {
      UserCredential userCredential = await auth.createUserWithEmailAndPassword(
          email: email,
          password: password
      );
      var userId;
      print("Registration");
      print(userCredential.user.isAnonymous);
      if(userCredential.user.email!=null){
        FirebaseFirestore db = FirebaseFirestore.instance;
        DocumentReference userRef = db.collection('users').doc();
        Map<String, dynamic> roomWithOffer = {
          'user_id': userCredential.user.uid,
          "email":userCredential.user.email,
          "name":name,
          "surname":surname,
          "online_status":false,
        };
        SendEmailVerify();
        await userRef.set(roomWithOffer);
        userId = userRef.id;
        return userId;
      }else{
        return null;
        // await locator<DialogService>().showDialog(
        //     title: "unlem",
        //     description: "Kayıt başarısız",
        //     buttonTitle: "Tamam"
        // );
      }
    } on FirebaseAuthException catch (e) {
      print("errorda");
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "Sağlanan şifre çok zayıf.",
            buttonTitle: "Tamam"
        );
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "Bu email ile daha önce kaydolunmuş",
            buttonTitle: "Tamam"
        );
      }
    } catch (e) {
      print("diğer errorda");
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "Bu email ile daha önce kaydolunmuş",
            buttonTitle: "Tamam"
        );
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "Bu email ile daha önce kaydolunmuş",
            buttonTitle: "Tamam"
        );
      }else{
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "${e.toString()}",
            buttonTitle: "Tamam"
        );
      }
      print(e.code);
      // print(e);
    }
  }
  Future<void> sendPushMessage(String _token,String title,String body) async {
    print("sending token : ${_token}");
    if (_token == null) {
      _token = "fQehA_gjRq6Z3yfvuKeLo_:APA91bHshj0pqCA0P1TiES2ysOZwTp7YBuiZqRPNUWoyBZR4A7-nluzEA7cRAtP1brR2ULJD9_SC6L6m8AvaiAFJYNKIifHEaRGVEsaEzN4N6U7Pu3C7jPwCTvkLUqzHjNhKDg3qGhnt";
      print('Unable to send FCM message, no token exists.');
      return;
    }
    try {
      await http.post(
        // Uri.parse('https://api.rnfirebase.io/messaging/send'),
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'key=AAAA_JlJVW4:APA91bHFa77G0KSbG4k6UW-NiZ_ag0SZS5b06lwTTxBG3vCMlxjObTxE3M0hSQm9s1uLnMLG-aloEAcm5akybUo3lZ_78o3-AqYX7Z97BGbV2aGC4L_NZQClnhTyJ1kfBNR83_Aw-W4p',
        },
        body: constructFCMPayload(_token,title,body),
      );
      print('FCM request for device sent!');
    } catch (e) {
      print(e);
    }
  }
  String constructFCMPayload(String token,String title,String body) {
    return jsonEncode({
      'to': token,
      'data': {
        'title': title,
        'body': body,
        'icon' : 'ic_stat_berichten',
        "image":"",
        "img_url":"",
        "picture":"",
        "summaryText" : title,
        "headsUp": true,
        "playSound": true,
        "enableLights": true,
        "color": "#c41e63",
        "style" : 'picture',
        "vibrate" : true,
        "vibrationPattern" : [2000, 1000, 500, 500],
        "sound" : true,
        "largeIcon" : "ic_large_app",
        "smallIcon" : "ic_launcher_foreground",
        "detail_id":""
      },
      'notification': {
        'title': title,
        'body': body,
        'icon' : 'ic_stat_berichten',
        'channel_id' : '1',
        'sound' : 'activated',
        "image":"",
        "img_url":"",
        "picture":"",
        'color' : '#c41e63',
        'iconColor' : '#c41e63',
        "msgcnt":1,
      },
      'priority' : 1,
    });
  }
  yeniYerEkle(
  {title,desc,price,image,work_hour,category}
      )async{
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    DocumentReference yerlerRef = db.collection('yerler').doc();
    var uuid = Uuid();
    var v4 = uuid.v4();
    var now = DateTime.now();
    var roomRef = db
        .collection('users')
        .where('user_id',isEqualTo: user.uid)
    ;
    print(user.uid);
    var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
      querySnapshot.docs.forEach((doc) async{
        // print("doc ${doc}");
        Map<String, dynamic> roomWithOffer = {
          'id': v4,
          'user': user.uid,
          'user_name': "${doc["name"]} ${doc["surname"]}",
          'title': title,
          'desc': desc,
          'price': price,
          'category': category,
          'work_hour': work_hour,
          'image': image,
          'date': now,
          'status': true,
          'point': 0,
          'point_count': 0,
        };
        await yerlerRef.set(roomWithOffer);
        var yerid = yerlerRef.id;
        if(yerid!=null){

          locator<DialogService>().showToast(title: "Yer ekleme başarılı",location:"ortada");
        }else{
          locator<DialogService>().showToast(title: "başarısız",location:"ortada");
        }
      });

    });


    return true;
  }
  yeniYorumEkle(
      {comment,product_id}
      )async{
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    DocumentReference yorumlarRef = db.collection('yorumlar').doc();
    var uuid = Uuid();
    var v4 = uuid.v4();
    var now = DateTime.now();
    var yorumRef = db
        .collection('yorumlar')
        .where('user',isEqualTo: user.uid)
        .where('product_id',isEqualTo: product_id)
    ;


    var roomRef = db
        .collection('users')
        .where('user_id',isEqualTo: user.uid)
    ;
    print(user.uid);
    var yorumroomSnapshot = await yorumRef.get().then((QuerySnapshot querySnapshot2) async{
      if(querySnapshot2.docs.length > 0 ){
        _dialogService.showToast(title: "Daha önce yorum yaptınız");
      }else{
        var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
          querySnapshot.docs.forEach((doc) async{
            // print("doc ${doc}");
            Map<String, dynamic> roomWithOffer = {
              'id': v4,
              'user': user.uid,
              'user_name': "${doc["name"]} ${doc["surname"]}",
              'comment': comment,
              'product_id': product_id,
              'date': now,
              'status': true,
            };
            await yorumlarRef.set(roomWithOffer);
            locator<DialogService>().showToast(title: "Yorum ekleme işlemi başarılı",location:"ortada");
            // var userId = yerlerRef.id;
          });

        });
      }



    });

    return true;
  }
  urunduzenle(urun_id,point)async{
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var roomRef = db
        .collection('yerler')
        .where('id',isEqualTo: urun_id)
    ;
    var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
      querySnapshot.docs.forEach((doc) async{
        // print("doc ${doc.id}");
        var old_point_count = doc["point_count"] !=null || doc["point_count"] !="" ? doc["point_count"] : 0;
        var old_point = doc["point"] !=null || doc["point"] !="" ? doc["point"] : 0;

        var point_count = old_point_count+1;
        var new_point_old = point_count * old_point;
        var new_point = (point + new_point_old) / point_count;
        DocumentReference userRef = db.collection('yerler').doc(doc.id);
        Map<String, dynamic> roomWithOffer = {
          'point': new_point,
          'point_count': point_count,
        };

        await userRef.update(roomWithOffer);
      });

    });
    return true;
  }
  yeniPuanEkle(
      {rating,product_id}
      )async{
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    DocumentReference puanlarRef = db.collection('puanlar').doc();
    var uuid = Uuid();
    var v4 = uuid.v4();
    var now = DateTime.now();
    var roomRef = db
        .collection('puanlar')
        .where('user',isEqualTo: user.uid)
        .where('product_id',isEqualTo: product_id)
    ;
    print(user.uid);
    var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
      if(querySnapshot.docs.length > 0 ){
        _dialogService.showToast(title: "Daha önce puan verdiniz");
      }else{
        Map<String, dynamic> roomWithOffer = {
          'id': v4,
          'user': user.uid,
          'rating': rating,
          'product_id': product_id,
          'date': now,
        };
        await puanlarRef.set(roomWithOffer);
        await urunduzenle(product_id,rating);
        locator<DialogService>().showToast(title: "Puan verme işlemi başarılı",location:"ortada");
      }

    });


    return true;
  }

  SignIn(email,password) async{
    var error = "";
    try {
      UserCredential userCredential = await auth.signInWithEmailAndPassword(
          email: email,
          password: password
      );
      if(userCredential.user.isAnonymous){
        _dialogService.showToast(title: "Giriş başarılı");
        return userCredential;
      }else{
        return false;
      }
    } on FirebaseAuthException catch (e) {

      if (e.code == 'user-not-found') {
        error = "user-not-found";
        await _dialogService.showDialog(
            title: "unlem",
            description: "Kullanıcı kaydı bulunamadı",
            buttonTitle: "Tamam"
        );
        // print('No user found for that email.1');
        return error;
      } else if (e.code == 'wrong-password') {
        error = "wrong-password";
        await locator<DialogService>().showDialog(
            title: "unlem",
            description: "Yanlış Şifre denemesi",
            buttonTitle: "Tamam"
        );
        // print('Wrong password provided for that user.1');
      }
      // _navigationService.navigateTo(routes.loginEmailRoute);
    }
    return true;
  }

  cancelOnlineStatus(bool online_status)async{
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var roomRef = db
        .collection('users')
        .where('user_id',isEqualTo: user.uid)
    ;
    var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
      querySnapshot.docs.forEach((doc) async{
        // print("doc ${doc.id}");
        DocumentReference userRef = db.collection('users').doc(doc.id);
        Map<String, dynamic> roomWithOffer = {
          'online_status': online_status,
        };
        await userRef.update(roomWithOffer);
      });

    });
    return true;
  }

  SendEmailVerify()async{
    var user = FirebaseAuth.instance.currentUser;

    if (user!= null && !user.emailVerified) {
      await user.sendEmailVerification();
    }
    return true;
  }
  UserVerify()async{
    // SendEmailVerify();
    var user = FirebaseAuth.instance.currentUser;
    if (user !=null ){
      return user;
    }else{
      return false;
    }
  }
  SignOut()async{
    await FirebaseAuth.instance.signOut().then((value) => print("çıkış yapıldı"));
    return true;
  }
}
