import 'dart:convert';

import 'package:flutter_base/core/services/model/user.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
/// The service responsible for networking requests
class LocationsApi {
  var client = new http.Client();


  // Future<dynamic> get_free_vehicles() async {
  //   try {
  //     SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var new_json = <String, String>{
  //       'device_id': prefs.getString('device_id'),
  //     };
  //     final response = await client.post(
  //       getFreeVehiclesUrl,
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //       },
  //       body: jsonEncode(new_json),
  //     );
  //     print("json.decode(response.body) ${json.decode(response.body)}");
  //     return json.decode(response.body);
  //     // return User.fromJson(json.decode(response.body));
  //     // var _json = json.decode(json.encode(_data.body));
  //     // print("getInfo ${_data.body}");
  //     // var _json = json.decode(_data.body);
  //     // var _newUser = User.fromJson(_json["user"]);
  //     // _newUser?.token = _json["access_token"];
  //     // prefs.setString('access_token',_json["access_token"]);
  //     // return _newUser;
  //   } catch (e) {
  //     print("Could Not Load Data getinfo: $e");
  //     return null;
  //   }
  // }

}
