import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter_base/core/constants/route_paths.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/services/view/device_info_service.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:path_provider/path_provider.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:connectivity/connectivity.dart';
// import 'package:audioplayers/audio_cache.dart';
// import 'package:audioplayers/audioplayers.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';


/// Define a top-level named handler which background/terminated messages will
/// call.
///
/// To verify things are working, check out the native platform logs.
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print('Handling a background message ${message.messageId}');
}

/// Create a [AndroidNotificationChannel] for heads up notifications
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title// description
  importance: Importance.high,
);

/// Initialize the [FlutterLocalNotificationsPlugin] package.
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
FlutterLocalNotificationsPlugin();
class PushNotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final NavigationService _navigationService = locator<NavigationService>();
  final DeviceInfoService _deviceInfoServiceService = locator<DeviceInfoService>();
  final DialogService _dialogService = locator<DialogService>();
  Future initialise() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      // I am connected to a mobile network.
      print("I am connected to a mobile network.");
      await initialiseFirebase();
    }else if(connectivityResult == ConnectivityResult.wifi) {
      print("I am connected to a wifi network.");
      await initialiseFirebase();
    }else {
      await _dialogService.showDialog(
          title: "İnternet Sorunu!",
          description: "İnternete bağlı değilsiniz, lütfen bağlantınızı kontrol edip tekrar deneyiniz.",
          buttonTitle: "Tamam"
      );
    }
  }
  static Future<dynamic> backgroundMessageHandler(Map<String, dynamic> message) {
    print("_backgroundMessageHandler");
    if (message.containsKey('data')) {
      // Handle data message
      final dynamic data = message['data'];
      print("_backgroundMessageHandler data: ${data}");
    }

    if (message.containsKey('notification')) {
      // Handle notification message
      final dynamic notification = message['notification'];
      print("_backgroundMessageHandler notification: ${notification}");
    }
    // AudioCache player = new AudioCache();
    // const alarmAudioPath = "sound/flutter_basesound.mp3"; 
    // player.play(alarmAudioPath);
    // try{
    //   // AudioCache player = new AudioCache();
    //   // const alarmAudioPath = "sound/flutter_basesound.mp3";
    //   // player.play(alarmAudioPath);
    // } catch (e) {
    //   // print("Could Not Load Data backgroundMessageHandler: $e");
    //   // return null;
    // }
  }
  Future initialiseFirebase() async {
// Set the background messaging handler early on, as a named top-level function
//     FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
//
//     /// Create an Android Notification Channel.
//     ///
//     /// We use this channel in the `AndroidManifest.xml` file to override the
//     /// default FCM channel to enable heads up notifications.
//     await flutterLocalNotificationsPlugin
//         .resolvePlatformSpecificImplementation<
//         AndroidFlutterLocalNotificationsPlugin>()
//         ?.createNotificationChannel(channel);
//
//     /// Update the iOS foreground notification presentation options to allow
//     /// heads up notifications.
//     await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
//       alert: true,
//       badge: true,
//       sound: true,
//     );
//
//     var connectivityResult = await (Connectivity().checkConnectivity());
//     if (connectivityResult == ConnectivityResult.mobile || connectivityResult == ConnectivityResult.wifi) {
//       // I am connected to a mobile network.
//       print("I am connected to a network.");
//     }else{
//       await _dialogService.showDialog(
//           title: "İnternet Sorunu!",
//           description: "İnternete bağlı değilsiniz, lütfen bağlantınızı kontrol edip tekrar deneyiniz.",
//           buttonTitle: "Tamam"
//       );
//     }
//
//     FirebaseMessaging.instance
//         .getInitialMessage()
//         .then((RemoteMessage message) {
//       if (message != null) {
//         // Navigator.pushNamed(context, '/message',
//         //     arguments: MessageArguments(message, true));
//       }
//     });
//
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       RemoteNotification notification = message.notification;
//       AndroidNotification android = message.notification?.android;
//
//       if (notification != null && android != null) {
//         flutterLocalNotificationsPlugin.show(
//             notification.hashCode,
//             notification.title,
//             notification.body,
//             NotificationDetails(
//               android: AndroidNotificationDetails(
//                 channel.id,
//                 channel.name,
//                 channel.description,
//                 // TODO add a proper drawable resource to android, for now using
//                 //      one that already exists in example app.
//                 icon: 'launch_background',
//               ),
//             ));
//       }
//     });
//
//     FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
//       print('A new onMessageOpenedApp event was published!');
//       // Navigator.pushNamed(context, '/message',
//       //     arguments: MessageArguments(message, true));
//     });



    // if (Platform.isIOS) {
    //   // request permissions if we're on android
    //   _fcm.requestNotificationPermissions(IosNotificationSettings());
    // }else{
    //   _fcm.requestNotificationPermissions();
    // }
    //
    // _fcm.configure(
    //   // Called when the app is in the foreground and we receive a push notification
    //   onMessage: (Map<String, dynamic> message) async {
    //     print('onMessage: $message');
    //     print('onMessage: $message');
    //     var title = "";
    //     var desc = "";
    //     if (Platform.isIOS) {
    //       title = message["aps"]["alert"]["title"];
    //       desc = message["aps"]["alert"]["body"];
    //     }else{
    //       title = message["notification"]["title"];
    //       desc = message["notification"]["body"];
    //     }
    //
    //     print("title ${title}");
    //     print("desc ${desc}");
    //     try{
    //       // AudioCache player = new AudioCache();
    //       // const alarmAudioPath = "sound/flutter_basesound.mp3";
    //       // player.play(alarmAudioPath);
    //     } catch (e) {
    //       print("Could Not Load Data onMessage: $e");
    //       return null;
    //     }
    //
    //
    //     await _dialogService.showDialog(
    //       title: title,
    //       description: desc,
    //       buttonTitle: "Tamam"
    //     );
    //   },
    //   // Called when the app has been closed comlpetely and it's opened
    //   // from the push notification.
    //   onLaunch: (Map<String, dynamic> message) async {
    //     print('onLaunch: $message');
    //     _serialiseAndNavigate(message);
    //   },
    //   // Called when the app is in the background and it's opened
    //   // from the push notification.
    //   onResume: (Map<String, dynamic> message) async {
    //     print('onResume: $message');
    //
    //     _serialiseAndNavigate(message);
    //   },
    //   onBackgroundMessage: backgroundMessageHandler
    // );
    //
    // _fcm.requestNotificationPermissions(
    //     const IosNotificationSettings(sound: true, badge: true, alert: true));
    // _fcm.onIosSettingsRegistered
    //     .listen((IosNotificationSettings settings) {
    //   print("Settings registered: $settings");
    // });
    // _fcm.getToken().then((String token) {
    //   assert(token != null);
    //   print("token : ${token}");
    //   addStringToSF(token);
    //   _sendDeviceInfo(token);
    // });
    //
    // if (kIsWeb) {
    //   // running on the web!
    // } else {
    //   _sendDeviceInfo("deneme");
    //   // NOT running on the web! You can check for additional platforms here.
    // }
  }
  void addStringToSF(String token_value) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString('push_token', token_value);
    } catch (e) {
      print(e);
    }
  }
  void getStringValuesSF() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      //Return String
      String token = prefs.getString('token');
    } catch (e) {
      print(e);
    }
  }

  void _sendDeviceInfo(String token) {
    _deviceInfoServiceService.initPlatformState(token);
  }

  void _serialiseAndNavigate(Map<String, dynamic> message) {
    var notificationData = message['data'];
    var view = notificationData['view'];

    if (view != null) {
      // Navigate to the create post view
      if (view == 'create_post') {
        _navigationService.navigateTo(homeRoute);
      }
    }
  }

}
