import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter_base/core/handlers/firebase_notification_handler.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/router.dart' as router;
import 'package:flutter_base/core/constants/route_paths.dart' as routes;

import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';

import 'package:flutter_base/core/managers/dialog_manager.dart';

import 'package:flutter_base/core/generated/localization/demo_localization.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';

import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:audioplayers/audioplayers.dart';
// bool USE_FIRESTORE_EMULATOR = false;
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // await FirebaseMessaging.onBackgroundMessage(_backgroundHandler);
  setupLocator();
  runApp(new MyApp());
}

Future<void> _backgroundHandler(RemoteMessage message) async{
  await Firebase.initializeApp();
  // try{
  //   print("ses çalıyor1");
  //   AudioCache player = new AudioCache();
  //   const alarmAudioPath = "sound/base.mp3";
  //   player.play(alarmAudioPath);
  // } catch (e) {
  //   print("Could Not Load Data backgroundMessageHandler: $e");
  //   return null;
  // }
  print("Handle background service $message");
  dynamic data = message.data["data"];
  if (data['title'] != null) {
    await FirebaseNotifications.showNotification(data["title"], data["body"]);
  }
}
class MyApp extends StatefulWidget {
  const MyApp({Key key}) : super(key: key);
  static void setLocale(BuildContext context, Locale newLocale) {
    _MyAppState state = context.findAncestorStateOfType<_MyAppState>();
    state.setLocale(newLocale);
  }

  @override
  _MyAppState createState() => _MyAppState();
}
class _MyAppState extends State<MyApp> {
  Locale _locale;
  setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }
  @override
  void didChangeDependencies() {
    getLocale().then((locale) {
      setState(() {
        this._locale = locale;
      });
    });
    super.didChangeDependencies();
  }

  final NavigationService _navigationService = locator<NavigationService>();
  final DialogService _dialogService = locator<DialogService>();

  final LoginViewModel _auth = LoginViewModel();
  final ThemeManager _model = ThemeManager();
  // This widget is the root of your application.
  FirebaseNotifications firebaseNotifications = new FirebaseNotifications();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      print("setupFirebase main");
      firebaseNotifications.setupFirebase(context);
    });
  }

  @override
  Widget build(BuildContext context) {

      return MultiProvider(
          providers: [
            ChangeNotifierProvider<LoginViewModel>.value(value: _auth),
            ChangeNotifierProvider<ThemeManager>.value(value: _model),
          ],
          child: MaterialApp(
            title: 'Gezi Uygulaması',
            debugShowCheckedModeBanner: false,
            // theme: model.theme,
            theme: ThemeManager().themeData,
            locale: _locale,
            supportedLocales: [
              Locale("tr", "TR"),
              Locale("en", "US")
            ],
            localizationsDelegates: [
              DemoLocalization.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            localeResolutionCallback: (locale, supportedLocales) {
              for (var supportedLocale in supportedLocales) {
                if (supportedLocale.languageCode == locale.languageCode &&
                    supportedLocale.countryCode == locale.countryCode) {
                  return supportedLocale;
                }
              }
              return supportedLocales.first;
            },
            builder: (context, child) =>
                Navigator(
                  key: locator<DialogService>().dialogNavigationKey,
                  onGenerateRoute: (settings) => MaterialPageRoute(builder: (context) => DialogManager(child: child)),
                ),
            navigatorKey: locator<NavigationService>().navigatorKey,
            onGenerateRoute: router.generateRoute,
            initialRoute: routes.splashRoute,
          )
      );

  }
}
