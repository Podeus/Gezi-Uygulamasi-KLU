import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/errors/login_validation_view.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/router.dart' as router;
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/dialog_service.dart';

import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
class ForgetAcceptView extends StatefulWidget {
  String email;
  String username;
  String type;
  String phone_number;
  ForgetAcceptView({this.email,this.username,this.type,this.phone_number});
  @override
  _ForgetAcceptViewState createState() => _ForgetAcceptViewState();
}

class _ForgetAcceptViewState extends State<ForgetAcceptView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final DialogService _dialogService = locator<DialogService>();
  TextEditingController codeController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordRepeatController = TextEditingController();

  _displaySnackBar(BuildContext context,String text) {
    final snackBar = SnackBar(content: Text(text!=null ? text : "error"));
    _scaffoldKey.currentState.showSnackBar(snackBar);
    return true;
  }
  @override
  Widget build(BuildContext context) {
    final _auth = Provider.of<LoginViewModel>(context, listen: false);
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    return Scaffold(
      key:_scaffoldKey,
      backgroundColor: _currentTheme.backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          // image: DecorationImage(
          //   image: AssetImage("asset/image/bg1.png"),
          //   fit: BoxFit.cover,
          // ),
        ),
        child: ListView(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height/2.5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(90)
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                        padding: const EdgeInsets.only(
                          bottom: 5,
                        ),
                        child: Text("Gezi Uygulaması")
                    ),
                  ),
                ],
              ),
            ),

            Container(
              height: MediaQuery.of(context).size.height * 0.45,
              width: MediaQuery.of(context).size.width,
              // padding: EdgeInsets.only(top: 62),
              child: Column(
                children: <Widget>[
                  Container(
                    width: MediaQuery.of(context).size.width * 0.95,
                    height: 45,
                    padding: EdgeInsets.only(
                        top: 4,left: 16, right: 16, bottom: 4
                    ),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(50)
                        ),
                        color: _currentTheme.cardColor,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    child: TextField(
                      controller: codeController,
                      onChanged: (text) {
                        print("code: $text");
                      },
                      decoration: InputDecoration(
                        labelText: codeController.text =="" ? '${getTranslated(context, 'code')}' : "",
                        border: InputBorder.none,
                        icon: Icon(Icons.code_outlined,
                          color: Color(0xFF26B13C),
                        ),
                        labelStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                        // hintText: 'Password',
                      ),
                    ),
                  ),
                  SizedBox(height: 15,),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.95,
                    height: 45,
                    padding: EdgeInsets.only(
                        top: 4,left: 16, right: 16, bottom: 4
                    ),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(50)
                        ),
                        color: _currentTheme.cardColor,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    child: TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: passwordController.text =="" ? '${getTranslated(context, 'password')}' : "",
                        border: InputBorder.none,
                        icon: Icon(Icons.vpn_key_outlined,
                          color: Color(0xFF26B13C),
                        ),
                        labelStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                        // hintText: 'Password',
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.95,
                    height: 45,
                    padding: EdgeInsets.only(
                        top: 4,left: 16, right: 16, bottom: 4
                    ),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(50)
                        ),
                        color: _currentTheme.cardColor,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    child: TextField(
                      controller: passwordRepeatController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: passwordRepeatController.text =="" ? '${getTranslated(context, 'repeat_password')}' : "",
                        border: InputBorder.none,
                        icon: Icon(Icons.vpn_key_outlined,
                          color: Color(0xFF26B13C),
                        ),
                        labelStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                        // hintText: 'Password',
                      ),
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () async {
                      // _auth.forgetAccept(
                      //     code: codeController.text,
                      //     password: passwordController.text,
                      //     password_repeat: passwordRepeatController.text,
                      //     type: widget.type,
                      //     username: widget.username,
                      //     email: widget.email,
                      //     phone_number: widget.phone_number,
                      // );
                    },
                    child: Container(
                      height: 45,
                      width: MediaQuery.of(context).size.width * 0.95,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFFFFFFFF),
                              Color(0xFFFFFFFF),
                            ],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.all(
                              Radius.circular(50)
                          ),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 3
                          )
                        ],
                      ),
                      child: Center(
                        child: Text('${getTranslated(context, 'update_password')}',
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 25,
            ),
            InkWell(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text("${getTranslated(context, 'have_you_got_account')}",style:TextStyle(color:_currentTheme.textSelectionHandleColor)),
                  Text("${getTranslated(context, 'login')}",style: TextStyle(color: Color(0xFF26B13C)),),
                ],
              ),
              onTap: (){
                locator<NavigationService>().navigateTo(routes.loginEmailRoute);
              },
            ),
          ],

        ),
      ),
    );
  }
}
