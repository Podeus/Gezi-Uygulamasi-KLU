import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
import 'package:flutter_base/core/locator.dart';

import 'package:flutter_base/core/services/view/dialog_service.dart';
// import 'package:select_form_field/select_form_field.dart';

import 'package:flutter_base/core/components/appbar/baseAppbar.dart';

import 'package:stacked/stacked.dart';

import 'package:flutter_base/core/services/model/language.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/main.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';


import 'package:font_awesome_flutter/font_awesome_flutter.dart';
class LanguageView extends StatefulWidget {
  @override
  _LanguageViewState createState() => _LanguageViewState();
}

class _LanguageViewState extends State<LanguageView> {
  void _changeLanguage(String text) async {
    Locale _locale = await setLocale(text);
    MyApp.setLocale(context, _locale);
  }
  // SingingCharacter _character = SingingCharacter.turkish;
  bool _isRadioSelected = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return ViewModelBuilder<LoginViewModel>.reactive(
        viewModelBuilder: () => LoginViewModel(),
        // onModelReady: (model) => model.getUserInfoAction(),
        builder: (context, model, child) =>
            Scaffold(
              appBar: BaseAppBar(
                title: Text("${getTranslated(context, 'change_language')}",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w700,color: _currentTheme.textSelectionColor)),
                // image: Image.asset("asset/image/logo.png",height: 30,),
                appBar: AppBar(),
                backgroundColor:Color(0xffe6e6e6),
                leading: (Navigator.canPop(context) ? IconButton(
                  icon: FaIcon(
                    FontAwesomeIcons.longArrowAltLeft,
                    color: Colors.black,
                    size: 25,
                  ),
                  onPressed: () => Navigator.pop(context),
                ) : null),
              ),
              // drawer: navigationDrawer(),
              backgroundColor:_currentTheme.backgroundColor,
              body: SingleChildScrollView(
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    child: Center(
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(height:25),
                            // DropdownButton<Language>(
                            //   iconSize: 30,
                            //   hint: Text(getTranslated(context, 'change_language')),
                            //   onChanged: (Language language) {
                            //     _changeLanguage(language);
                            //     print(language.languageCode);
                            //     model.save_auto_insert(null,null,language.languageCode);
                            //   },
                            //   items: Language.languageList()
                            //       .map<DropdownMenuItem<Language>>(
                            //         (e) => DropdownMenuItem<Language>(
                            //       value: e,
                            //       child: Container(
                            //         width: MediaQuery.of(context).size.width * 0.70,
                            //         child: Row(
                            //           mainAxisAlignment: MainAxisAlignment.spaceAround,
                            //           children: <Widget>[
                            //             Container(
                            //               width: MediaQuery.of(context).size.width * 0.30,
                            //               child: Text(
                            //                   e.flag,
                            //                   style: TextStyle(fontSize: 30),
                            //                 ),
                            //             ),
                            //             Container(
                            //               width: MediaQuery.of(context).size.width * 0.30,
                            //               child: Text(e.name)
                            //             ),
                            //           ],
                            //         ),
                            //       )
                            //     ),
                            //   )
                            //       .toList(),
                            // ),
                            // Column(
                            //   children: <Widget>[
                            //     RadioListTile<SingingCharacter>(
                            //       title: const Text('TÜRKÇE'),
                            //       value: SingingCharacter.turkish,
                            //       groupValue: _character,
                            //       onChanged: (SingingCharacter value) {
                            //         model.setLanguage("tr");
                            //         setState(() {
                            //           _character = value;
                            //         });
                            //       },
                            //     ),
                            //     RadioListTile<SingingCharacter>(
                            //       title: const Text('İNGİLİZCE'),
                            //       value: SingingCharacter.english,
                            //       groupValue: _character,
                            //       onChanged: (SingingCharacter value) {
                            //         model.setLanguage("en");
                            //         setState(() {
                            //           _character = value;
                            //         });
                            //       },
                            //     ),
                            //   ],
                            // ),
                            // LinkedLabelRadio(
                            //   label: 'TURKISH',
                            //   padding: EdgeInsets.symmetric(horizontal: 5.0),
                            //   value: model.language == "tr" ? false : true,
                            //   groupValue: _isRadioSelected,
                            //   onChanged: (bool newValue) {
                            //     print("model.language ${model.language}");
                            //     model.setLanguage("tr");
                            //     setState(() {
                            //       _isRadioSelected = newValue;
                            //     });
                            //   },
                            // ),
                            SizedBox(height: 20,),
                            // LinkedLabelRadio(
                            //   label: 'ENGLISH',
                            //   padding: EdgeInsets.symmetric(horizontal: 5.0),
                            //   value: model.language == "en" ? false : true,
                            //   groupValue: _isRadioSelected,
                            //   onChanged: (bool newValue) {
                            //     print("model.language ${model.language}");
                            //     model.setLanguage("en");
                            //     setState(() {
                            //       _isRadioSelected = newValue;
                            //     });
                            //   },
                            // ),
                            MyStatefulWidget(
                                activeLang:model.language,
                                onChanged : (code) {
                                  model.setLanguage(code);
                                }
                            ),
                            SizedBox(height:25),
                            Padding(
                              padding: EdgeInsets.all(10),
                              child:FlatButton(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(18.0),
                                      // side: BorderSide(color: _currentTheme.textSelectionColor)
                                  ),
                                  color: Color(0xFF9bcc4e),
                                  textColor: Color(0xFFffffff),
                                  padding: EdgeInsets.all(15.0),
                                  onPressed: () {
                                    _changeLanguage(model.language);
                                    // model.save_user_infos(model.language);
                                  },
                                  child: Container(
                                      width:MediaQuery.of(context).size.width * 0.8,
                                      child:Center(
                                        child:  Text(
                                          "${getTranslated(context, 'SAVE')}",
                                            style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,color: _currentTheme.textSelectionColor)
                                        ),
                                      )
                                  )
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
              ),
            )
    );
  }

}

class LinkedLabelRadio extends StatelessWidget {
  const LinkedLabelRadio({
    this.label,
    this.padding,
    this.groupValue,
    this.value,
    this.onChanged,
  });

  final String label;
  final EdgeInsets padding;
  final bool groupValue;
  final bool value;
  final Function onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: RadioListTile<bool>(
          title: Text(label),
          groupValue: groupValue,
          value: value,
          onChanged: (bool newValue) {
            // model.setLanguage("tr");
            print(newValue);
            onChanged(newValue);
          }
      ),
    );
  }
}


enum SingingCharacter { turkish, english, spanish , german}

/// This is the stateful widget that the main application instantiates.
class MyStatefulWidget extends StatefulWidget {
  final Function onChanged;
  final String activeLang;
  MyStatefulWidget({Key key,this.onChanged,this.activeLang}) : super(key: key);

  @override
  _MyStatefulWidgetState createState() => _MyStatefulWidgetState();
}

/// This is the private State class that goes with MyStatefulWidget.
class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  SingingCharacter _character = SingingCharacter.turkish;
  List<radioModel> wheredidyoufindusfList = [
    radioModel(
        index: 1,
        code: "tr",
        name: "Turkish",
        character: SingingCharacter.turkish
    ),
    radioModel(
        index: 2,
        code: "en",
        name: "English",
        character: SingingCharacter.english
    ),
    radioModel(
        index: 3,
        code: "es",
        name: "Spanish",
        character: SingingCharacter.spanish
    ),
    radioModel(
        index: 4,
        code: "de",
        name: "German",
        character: SingingCharacter.german
    ),
  ];
  int wheredidyoufindusid = 1;
  SingingCharacter wheredidyoufinduslang = SingingCharacter.turkish;
  String wheredidyoufindusradioItem = 'Turkish';
  @override
  void getlanguage() {
    if(widget.activeLang == "tr"){
      wheredidyoufindusid = 1;
    }else if(widget.activeLang == "en"){
      wheredidyoufindusid = 2;
    }else if(widget.activeLang == "es"){
      wheredidyoufindusid = 3;
    }else if(widget.activeLang == "de"){
      wheredidyoufindusid = 4;
    }
  }
  Widget build(BuildContext context) {
    print("active lang ${widget.activeLang}");
    if(widget.activeLang == "tr"){
      wheredidyoufindusid = 1;
    }else if(widget.activeLang == "en"){
      wheredidyoufindusid = 2;
    }else if(widget.activeLang == "es"){
      wheredidyoufindusid = 3;
    }else if(widget.activeLang == "de"){
      wheredidyoufindusid = 4;
    }
    return Column(
      children: <Widget>[
        Container(
            margin: EdgeInsets.only(left:10,right: 10),
            padding: EdgeInsets.all(10),
            width: MediaQuery.of(context).size.width * 0.90,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.48,
                      margin: EdgeInsets.only(left:15,bottom:15),
                      child: Column(
                        children:
                        wheredidyoufindusfList.map((data) => RadioListTile(
                          title: Text("${data.name}"),
                          groupValue: wheredidyoufindusid,
                          value: data.index,
                          onChanged: (val) {
                            widget.onChanged(data.code);
                            setState(() {
                              wheredidyoufinduslang = data.character;
                              wheredidyoufindusid = data.index;
                              _character = data.character;
                            });
                          },
                        )).toList(),
                      ),
                    )
                ),
              ],
            )
        ),
      ],
    );
  }
}

class radioModel {
  String name;
  String code;
  int index;
  SingingCharacter character;
  radioModel({this.name, this.index,this.character,this.code});
}