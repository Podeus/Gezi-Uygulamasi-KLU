import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/errors/login_validation_view.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/router.dart' as router;
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/dialog_service.dart';

import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
class LoginEmailView extends StatefulWidget {
  @override
  _LoginEmailViewState createState() => _LoginEmailViewState();
}

class _LoginEmailViewState extends State<LoginEmailView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final DialogService _dialogService = locator<DialogService>();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  // Initially password is obscure
  bool _passwordVisible = false;
  bool _passwordValidate = false;
  bool _usernameValidate = false;
  String _usernameError = "";
  String _passwordError = "";
  bool isEmail(String em) {
    String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = new RegExp(p);
    return regExp.hasMatch(em);
  }
  bool validateStructure(String value){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = new RegExp(pattern);
    return regExp.hasMatch(value);
  }
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    // TODO: implement dispose
    super.dispose();
  }
  _displaySnackBar(BuildContext context,String text) {
    final snackBar = SnackBar(content: Text(text!=null ? text : "error"));
    _scaffoldKey.currentState.showSnackBar(snackBar);
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final _auth = Provider.of<LoginViewModel>(context, listen: false);
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    return WillPopScope(
        onWillPop: () async => true,
        child:Scaffold(
          key:_scaffoldKey,
          backgroundColor: _currentTheme.backgroundColor,
          body: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                SizedBox(height: MediaQuery.of(context).size.height * 0.25,),
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(90)
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      Align(
                        alignment: Alignment.center,
                        child: Padding(
                            padding: const EdgeInsets.only(
                              top: 0,
                            ),
                            child: Text("Gezi Uygulaması")
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.95,
                  height: 45,
                  margin: EdgeInsets.only(top:35),
                  padding: EdgeInsets.only(
                      top: 4,left: 16, right: 16, bottom: 4
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFFf2f2f2),
                        Color(0xFFf2f2f2),
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(
                        Radius.circular(50)
                    ),
                    // color: _currentTheme.secondaryHeaderColor,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black12,
                          blurRadius: 1
                      )
                    ],
                  ),
                  child: TextField(
                    textAlign: TextAlign.left,
                    controller: usernameController,
                    onChanged: (text) {
                      print("username: $text");
                      setState(() {
                        usernameController.text !="" ? _usernameValidate = false : _usernameValidate = true;
                        _usernameError = "${getTranslated(context, 'email_hint')}";
                      });
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      // icon: Icon(Icons.person,
                      //   color: Color(0xFF26B13C),
                      // ),
                      hintStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                      hintText: '${getTranslated(context, 'email')}',
                    ),
                  ),
                ),
                _usernameValidate == true ? loginValidationView(
                    text: _usernameError
                ) : Text(""),
                Container(
                  width: MediaQuery.of(context).size.width * 0.95,
                  height: 45,
                  // margin: EdgeInsets.only(top: 32),
                  padding: EdgeInsets.only(
                      top: 4,left: 20, right: 5, bottom: 4
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFFf2f2f2),
                        Color(0xFFf2f2f2),
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(
                        Radius.circular(50)
                    ),
                    // color: _currentTheme.secondaryHeaderColor,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black12,
                          blurRadius: 1
                      )
                    ],
                  ),
                  child: TextFormField(
                      onChanged: (text) {
                        print("password: $text");
                        setState(() {
                          passwordController.text !="" ? _passwordValidate = false : _passwordValidate = true;
                          _passwordError = "${getTranslated(context, 'password_hint')}";
                        });
                      },
                      keyboardType: TextInputType.text,
                      controller: passwordController,
                      obscureText: !_passwordVisible,
                      textAlign: TextAlign.left,

                      decoration: InputDecoration(
                        // labelText: passwordController.text =="" ? 'Parola' : "",
                        border: InputBorder.none,
                        hintStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                        hintText: '${getTranslated(context, 'password')}',
                        // icon: Icon(Icons.vpn_key,
                        //   color: Color(0xFF26B13C),
                        // ),
                        // hintText: 'Password',
                        labelStyle: TextStyle(color: _currentTheme.textSelectionHandleColor),
                        suffixIcon: IconButton(
                          icon: Icon(
                            // Based on passwordVisible state choose the icon
                            _passwordVisible ==true
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: _currentTheme.textSelectionHandleColor,
                          ),
                          onPressed: () {
                            // Update the state i.e. toogle the state of passwordVisible variable
                            setState(() {
                              _passwordVisible = !_passwordVisible;
                            });
                          },
                        ),
                      ),
                      // validator: (val) {
                      //    if(val.length < 6){
                      //      setState(() {
                      //        _passwordValidate = true;
                      //      });
                      //    }
                      // },
                      onSaved: (val) => passwordController.text = val
                  ),
                ),

                _passwordValidate == true ? loginValidationView(
                    text: _passwordError
                ) : Text(""),

                InkWell(
                  onTap: () async {
                    setState(() {
                      usernameController.text !="" ? _usernameValidate = false : _usernameValidate = true;
                      _usernameError = "${getTranslated(context, 'email_hint')}";
                      passwordController.text !="" ? _passwordValidate = false : _passwordValidate = true;
                      _passwordError = "${getTranslated(context, 'password_hint')}";
                    });
                    // if(isEmail(usernameController.text)==false){
                    //   _usernameValidate = true;
                    //   _usernameError = "Email Syntax error";
                    // }
                    // if(passwordController.text.length < 6){
                    //   _passwordValidate = true;
                    //   _passwordError = "Password length can not small then 6";
                    // }
                    // if(validateStructure(passwordController.text) ==false){
                    //   _passwordValidate = true;
                    //   _passwordError = "must a-z 0-9 and *";
                    // }
                    print("isEmail(usernameController.text) ${isEmail(usernameController.text)}");
                    // await _dialogService.showDialog(
                    //     title: "Missing_information",
                    //     description: "Missing_information",
                    //     buttonTitle: "Ok"
                    // );
                    // _displaySnackBar(context,"You are successfuly loggend in");
                    if( usernameController.text !="" && passwordController.text!=""){
                      // _auth.login(username: usernameController.text,password:passwordController.text);
                      _auth.login(username: usernameController.text,password:passwordController.text);
                    }
                  },
                  child: Container(
                    height: 45,
                    width: MediaQuery.of(context).size.width/2.2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF999999),
                          Color(0xFF999999),
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.all(
                          Radius.circular(50)
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black38,
                            blurRadius: 1
                        )
                      ],
                    ),
                    child: Center(
                      child: Text('${getTranslated(context, 'signIn')}',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16
                          // fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                InkWell(
                  onTap: () async {
                    locator<NavigationService>().navigateTo(routes.signupRoute);
                  },
                  child: Container(
                    height: 45,
                    width: MediaQuery.of(context).size.width * 0.75,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFFFFFFFF),
                          Color(0xFFFFFFFF),
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.all(
                          Radius.circular(50)
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          blurRadius: 5,
                          spreadRadius: 1,
                          offset: Offset(0, 3),
                        )
                      ],
                    ),
                    child: Center(
                      child: RichText(
                        text: TextSpan(
                          text: '',
                          style:  TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold
                          ),
                          children: <TextSpan>[
                            TextSpan(text: ' ${getTranslated(context, 'register').toUpperCase()}',style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15,),

              ],
            ),
          ),
        ));
  }
}
