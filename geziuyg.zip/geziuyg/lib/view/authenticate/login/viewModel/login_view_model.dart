import 'dart:io';

import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:flutter_base/core/base/viewmodel/base_view_model.dart';
import 'package:flutter_base/core/services/view/firebase_service.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/authentication_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
class LoginViewModel extends BaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final AuthenticationService _authenticationService = locator<AuthenticationService>();
  final DialogService _dialogService = locator<DialogService>();

  final Api _Api = locator<Api>();
  final FirebaseService _FirebaseServiceApi = locator<FirebaseService>();

  bool _loggedIn = false;
  String _access_token;
  String _true_code;
  String _phone_number;
  String _currentText;
  String _user;


  bool get loggedIn => _loggedIn;
  String get true_code => _true_code;
  String get access_token => _access_token;
  String get phone_number => _phone_number;
  String get currentText => _currentText;
  String get user => _user;

  // List<Sms> _sms;
  // List<Sms> get sms => _sms;
  String _my_ref_code;
  String get my_ref_code => _my_ref_code;

  bool _notiBool = false;
  bool _darkmodeBool = false;
  bool get notiBool => _notiBool;
  bool get darkmodeBool => _darkmodeBool;
  String _language = "tr";
  String get language => _language;
  void setLanguage(String value) {
    _language = value;
    notifyListeners();
  }
  FirebaseAuth auth = FirebaseAuth.instance;
  void update_user_token(token)async{
    print("updateable token ${token}");
    var _prefs = await SharedPreferences.getInstance();
    _prefs.setString('push_token',token);
    var user = FirebaseAuth.instance.currentUser;
    if(user!=null){
      print("updated token ${token}");
      FirebaseFirestore db = FirebaseFirestore.instance;
      var roomRef = db
          .collection('users')
          .where('user_id',isEqualTo: user.uid)
      ;
      var roomSnapshot = await roomRef.get().then((QuerySnapshot querySnapshot) async{
        querySnapshot.docs.forEach((doc) async{
          print("doc ${doc.id}");
          DocumentReference userRef = db.collection('users').doc(doc.id);
          Map<String, dynamic> roomWithOffer;
          roomWithOffer = {
            'push_token': token
          };
          await userRef.update(roomWithOffer);
        });

      });
    }else{
      print("token updatede edilemedi 2");
    }
  }
  Stream<String> _tokenStream;
  Future<dynamic> checkUserAction() async {
    print("clicked checkUserAction");
    setBusy(true);
    await Future.delayed(Duration(seconds: 2));
    var push_token="";
    var user = FirebaseAuth.instance.currentUser;

    if(kIsWeb){
      print("web için update_user_token işlemi bekleniyor");
      var _messaging = FirebaseMessaging.instance;
      _messaging.getToken().then(update_user_token);
      _tokenStream = _messaging.onTokenRefresh;
      _tokenStream.listen(update_user_token);
    }else{
      var _prefs = await SharedPreferences.getInstance();
      push_token = _prefs.getString('push_token');
      if(push_token!=null){
        await update_user_token(push_token);
      }
    }


    // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.checkUserAction();
    final response = await _FirebaseServiceApi.UserVerify();
    if (response ==null) {
      print('checkUserAction Error ${response}');
      // setErrorMessage('Error has occured with the login');
    } else {
      print('checkUserAction response ${response}');
      if (response!=false){
        if(response.email!=null){

          _navigationService.navigateTo(routes.homeRoute);
        }else{
          _navigationService.navigateTo(routes.loginEmailRoute);
        }
      }else{
        _navigationService.navigateTo(routes.loginEmailRoute);
      }
    }
    setBusy(false);
  }
Future<void> login({
    @required String username,
    @required String password
  }) async {
  setBusy(true);
  // await Future.delayed(Duration(seconds: 2));
  try {

    var login = _FirebaseServiceApi.SignIn(username, password);
    if(login!=null){
      checkUserAction();
    }else{
      _dialogService.showToast(title: "Giriş başarısız");
    }
    setBusy(false);
    // print("login ${login}");
  } catch (e) {
    // _navigationService.navigateTo(routes.loginEmailRoute);
    print(e);
  }
  //
  setBusy(false);
}

  Future<dynamic> register({
    @required String username,
    @required String password,
     name,
     surname,
  })async {
    setBusy(true);
    await Future.delayed(Duration(seconds: 1));
    try {
      var kayitsonuc = _FirebaseServiceApi.Registration(username, password,name,surname);
      if(kayitsonuc!=null){
        await locator<DialogService>().showDialog(
            title: "Kayıt başarılı",
            description: "Kaydınız başarılı şimdi giriş yapabilirsiniz.",
            buttonTitle: "Tamam"
        );
        _navigationService.navigateTo(routes.loginEmailRoute);
        print("başarılı");
      }else{
        print("başarısız");
      }
      // print("kayitsonuc ${kayitsonuc.toString()}");

    } catch (e) {

    }
    //
    setBusy(false);
  }

  Future<dynamic> signOut()async {
    setBusy(true);
    await Future.delayed(Duration(seconds: 1));
    try {
      _FirebaseServiceApi.SignOut();
      var dialogconfirm = await _dialogService.showDialog(
          title: "Çıkış işlemi başarılı",
          description: "Yönlendiriliyorsunuz",
          buttonTitle: "Tamam"
      );
      if(dialogconfirm.confirmed==true){
        _navigationService.navigateTo(routes.loginEmailRoute);
      }
    } catch (e) {
      _navigationService.navigateTo(routes.loginEmailRoute);
      print(e);
    }
    //
    setBusy(false);
  }

}
