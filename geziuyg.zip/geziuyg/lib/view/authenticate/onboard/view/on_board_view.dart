import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/router.dart' as router;
import 'package:flutter_base/core/constants/route_paths.dart' as routes;

import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
// final kTitleStyle = TextStyle(
//   color: Colors.black,
//   fontFamily: 'CM Sans Serif',
//   fontSize: 35.0,
//   height: 1.5,
//   fontWeight: FontWeight.w700
// );
// final kTitleStyle2 = TextStyle(
//     color: Colors.black,
//     fontFamily: 'CM Sans Serif',
//     fontSize: 25.0,
//     height: 1.5,
//     fontWeight: FontWeight.w700
// );
//
// final kSubtitleStyle = TextStyle(
//   color: Colors.black,
//   fontSize: 18.0,
//   height: 1.2,
// );
class OnBoardView extends StatefulWidget {
  @override
  _OnBoardViewState createState() => _OnBoardViewState();
}

class _OnBoardViewState extends State<OnBoardView> {

  final int _numPages = 2;
  final PageController _pageController = PageController(initialPage: 0);
  int _currentPage = 0;

  List<Widget> _buildPageIndicator(Color backgroundColor) {
    List<Widget> list = [];
    for (int i = 0; i < _numPages; i++) {
      list.add(i == _currentPage ? _indicator(true,backgroundColor) : _indicator(false,backgroundColor));
    }
    return list;
  }


  Widget _indicator(bool isActive,Color backgroundColor) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 150),
      margin: EdgeInsets.symmetric(horizontal: 8.0),
      height: 4.0,
      width: isActive ? 50.0 : 40.0,
      decoration: BoxDecoration(
        color: isActive ? backgroundColor: backgroundColor,
        borderRadius: BorderRadius.all(Radius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    final kTitleStyle = TextStyle(
        color: _currentTheme.textSelectionColor,
        fontFamily: 'CM Sans Serif',
        fontSize: 35.0,
        height: 1.5,
        fontWeight: FontWeight.w700
    );
    final kSubtitleStyle = TextStyle(
      color: _currentTheme.textSelectionColor,
      fontSize: 18.0,
      height: 1.2,
    );
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Container(
          padding: EdgeInsets.only(top: 20.0,bottom: 10.0),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.1, 0.4, 0.7, 0.9],
              colors: [
                _currentTheme.backgroundColor,
                _currentTheme.backgroundColor,
                _currentTheme.backgroundColor,
                _currentTheme.backgroundColor,
              ],
            ),
          ),
          child: Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                      padding: EdgeInsets.only(top: 10.0,right: 20.0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child:GestureDetector(
                          onTap: (){
                            print("skip v");
                            // Navigator.pushNamed(context, routes.loginRoute);
                          },
                          child: Icon(
                            Icons.close,
                            color: Colors.grey,
                            size: 30.0,
                          ),
                        ),
                      )
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.77,
                    width: MediaQuery.of(context).size.width * 0.99,
                    child: PageView(
                      physics: ClampingScrollPhysics(),
                      controller: _pageController,
                      onPageChanged: (int page) {
                        setState(() {
                          _currentPage = page;
                        });
                      },
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(top:0.0,bottom:10.0,left:10,right:10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Center(
                                child: Image(
                                  image: AssetImage(
                                    'asset/image/onboard1.png',
                                  ),
                                  height: MediaQuery.of(context).size.height * 0.45,
                                  width: MediaQuery.of(context).size.width * 0.99,
                                ),
                              ),
                              SizedBox(height: 10.0),
                              Center(
                                child: Text(
                                  "Pick the store and \nselect coupon",
                                  textAlign: TextAlign.center,
                                  style: kTitleStyle,
                                ),
                              ),
                              SizedBox(height: 10.0),
                              Center(
                                child:Text(
                                  "Search or Find in featured tab, save to favourites and collect best coupons to start saving money",
                                  textAlign: TextAlign.center,
                                  style: kSubtitleStyle,
                                ),
                              ),

                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top:0.0,bottom:10.0,left:10,right:10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Image(
                                image: AssetImage(
                                  'asset/image/onboard2.png',
                                ),
                                height: MediaQuery.of(context).size.height * 0.45,
                                width: MediaQuery.of(context).size.width * 0.99,
                              ),
                              SizedBox(height: 10.0),
                              Center(
                                child: Text(
                                  "Use coupon or \ndeal and save",
                                  textAlign: TextAlign.center,
                                  style: kTitleStyle,
                                ),
                              ),
                              SizedBox(height: 10.0),
                              Center(
                                child:Text(
                                  "Use promo code or deal, If you want you can save coupon for later and use it in the perfect moment",
                                  textAlign: TextAlign.center,
                                  style: kSubtitleStyle,
                                ),
                              ),

                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Align(
                      alignment: FractionalOffset.bottomRight,
                      child: FlatButton(
                          onPressed: () {
                            if(_currentPage == _numPages - 1){
                              // Navigator.pushNamed(context, routes.loginRoute);
                            }else{
                              _pageController.nextPage(
                                duration: Duration(milliseconds: 500),
                                curve: Curves.ease,
                              );
                            }
                          },
                          child: Container(
                            height: 55,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF26B13C),
                                  Color(0xFF26B13C),
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              // boxShadow: [
                              //   BoxShadow(
                              //     color: Colors.grey.withOpacity(0.5),
                              //     spreadRadius: 5,
                              //     blurRadius: 7,
                              //     offset: Offset(0, 3), // changes position of shadow
                              //   ),
                              // ],
                              borderRadius: const BorderRadius.all(
                                Radius.circular(15.0),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: <Widget>[
                                Text(
                                    "Next",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 20.0,
                                        fontWeight: FontWeight.w400
                                    )
                                ),
                                SizedBox(width: 10.0),
                                Icon(
                                  Icons.arrow_forward_rounded,
                                  color: Colors.white,
                                  size: 22.0,
                                ),
                              ],
                            ),
                          )
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: _buildPageIndicator(_currentTheme.textSelectionColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      // bottomSheet: _currentPage == _numPages - 1
      //     ? Container(
      //   height: 100.0,
      //   width: double.infinity,
      //   color: Colors.white,
      //   child: GestureDetector(
      //     onTap: () => {
      //       Navigator.pushNamed(context, routes.homeRoute),
      //     },
      //     child: Center(
      //       child: Padding(
      //         padding: EdgeInsets.only(bottom: 10.0),
      //         child: Text(
      //           "LETS_START",
      //           style: TextStyle(
      //             color: Color(0xFF5B16D0),
      //             fontSize: 20.0,
      //             fontWeight: FontWeight.bold,
      //           ),
      //         ),
      //       ),
      //     ),
      //   ),
      // )
      //     : Text(''),
    );
  }
}
