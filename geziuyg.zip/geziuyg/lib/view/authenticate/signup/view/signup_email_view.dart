
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/core/components/forms/linkedLabelRadio.dart';
import 'package:flutter_base/core/components/forms/textFieldwithTopFieldName.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/router.dart' as router;
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/dialog_service.dart';

import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:stacked/stacked.dart';
class SignupEmailView extends StatefulWidget {
  @override
  _SignupEmailViewState createState() => _SignupEmailViewState();
}

class _SignupEmailViewState extends State<SignupEmailView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final _auth = Provider.of<LoginViewModel>(context, listen: false);
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // final _currentTheme = appThemeData[AppTheme.values[1]];
    return ViewModelBuilder<LoginViewModel>.reactive(
      viewModelBuilder: () => LoginViewModel(),
      onModelReady: (model) {
        // model.getUserInfoAction();
        // model.get_info_warnings("signup_1",null);
      },
      builder: (context, model, child) =>
     Scaffold(
      appBar: BaseAppBar(
        title: Text("Kayıt Ol",style: TextStyle(fontSize: 30,fontWeight: FontWeight.w700,color: _currentTheme.textSelectionColor)),
        // image: Image.asset("asset/image/logo.png",height: 30,),
        appBar: AppBar(),
        backgroundColor:Color(0xffe6e6e6),
        leading: (Navigator.canPop(context) ? IconButton(
          icon: FaIcon(
            FontAwesomeIcons.longArrowAltLeft,
            color: Colors.black,
            size: 25,
          ),
          onPressed: () => locator<NavigationService>().goBack(),
        ) : null),
      ),
      backgroundColor: _currentTheme.backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          // image: DecorationImage(
          //   image: AssetImage("asset/image/bg1.png"),
          //   fit: BoxFit.cover,
          // ),
          // boxShadow: [
          //   BoxShadow(
          //     color: Colors.grey[200],
          //   ),
          //   BoxShadow(
          //     color: Colors.transparent,
          //     spreadRadius: -12.0,
          //     blurRadius: 12.0,
          //   ),
          // ],
        ),
        child: TitleSection(),
      ),
    )
    );
  }



}
class TitleSection extends ViewModelWidget<LoginViewModel> {
  final _formKey = GlobalKey<FormState>();
  var user_data;
  var confirmed;


  @override
  void initState() {
  }
  @override
  void dispose() {
    // super.initState();


  }
  @override
  Widget build(BuildContext context, LoginViewModel model) {
    // _nameController.text = model.user_name;
    if(model.user == null){
      return FormWidget(array:model.user);
    }else{
      return Center(
        child: Text(""),
      );
    }
  }
}
class FormWidget extends StatefulWidget {
  String array ;
  FormWidget({this.array});
  @override
  _FormWidgetState createState() => _FormWidgetState();
}

class _FormWidgetState extends State<FormWidget> {
  var user_data;
  TextEditingController nameController = TextEditingController();
  TextEditingController surnameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController bransController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordRepeatController = TextEditingController();
  TextEditingController userTypeController = TextEditingController();

  TextEditingController veliadiController = TextEditingController();
  TextEditingController velitelefonController = TextEditingController();
  TextEditingController veliemailController = TextEditingController();
  final _bornController = TextEditingController();
  DateTime birthDate; // instance of DateTime
  String birthDateInString;
  DateTime oldbirthDateInString;
  // String initValue="Select your Birth Date";
  bool isDateSelected= false;
  String liveinCity = 'İstanbul';
  bool _gender = false;

  var new_json2 = [];
  bool isEmail(String em) {
    String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = new RegExp(p);
    return regExp.hasMatch(em);
  }
  bool validateStructure(String value){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = new RegExp(pattern);
    return regExp.hasMatch(value);
  }

  Widget getDivider(String name){
    return Row(
        children: <Widget>[
          Expanded(
            child: new Container(
                margin: const EdgeInsets.only(left: 20.0, right: 20.0),
                child: Divider(
                  color: Color(0xFF808080),
                  height: 10,
                  thickness: 1,
                )),
          ),

          Text("$name",style: TextStyle(color:Color(0xFF666666),fontSize: 12,fontWeight: FontWeight.bold),),

          Expanded(
            child: new Container(
                margin: const EdgeInsets.only(left: 20.0, right: 20.0),
                child: Divider(
                  color: Color(0xFF808080),
                  height: 10,
                  thickness: 1,
                )),
          ),
        ]
    );
  }
  @override
  void initState() {
    super.initState();

  }
  @override
  void dispose() {
    // super.initState();

  }

  @override
  Widget build(BuildContext context) {
    final _auth = Provider.of<LoginViewModel>(context, listen: false);
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];


    return _auth.busy == true ? Center(child: CircularProgressIndicator(),) :
    ListView(
      children: <Widget>[
        Container(
            margin: EdgeInsets.only(left:10,right: 10),
            padding: EdgeInsets.all(10),
            width: MediaQuery.of(context).size.width * 0.90,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Flexible(
                    child: Padding(
                      padding: EdgeInsets.only(left:15,right:15),
                      child: Text('${getTranslated(context, 'welcome')}',
                        style: TextStyle(color:Color(0xFF666666),fontSize: 15,fontWeight: FontWeight.bold,),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                    )
                ),
              ],
            )
        ),

        SizedBox(height: 30,),
        getDivider("${getTranslated(context, 'personal_information')}"),
        SizedBox(height: 15,),

        textFieldWithTopLabel(
            textController: nameController,
            name:"${getTranslated(context, 'name')}",
            color:_currentTheme.cardColor,
            textColor:_currentTheme.textSelectionHandleColor,
            type:"",
            context:context,
            readonly:false,
            enabled:false,
            border:0
        ),
        textFieldWithTopLabel(
            textController: surnameController,
            name:"${getTranslated(context, 'Surname')}",
            color:_currentTheme.cardColor,
            textColor:_currentTheme.textSelectionHandleColor,
            type:"",
            context:context,
            readonly:false,
            enabled:false,
            border:0
        ),
        textFieldWithTopLabel(
            textController: emailController,
            name:"${getTranslated(context, 'email_address')}",
            color:_currentTheme.cardColor,
            textColor:_currentTheme.textSelectionHandleColor,
            type:"",
            context:context,
            readonly:false,
            enabled:false,
            border:0
        ),
        textFieldWithTopLabel(
            textController: passwordController,
            name:"${getTranslated(context, 'password')}",
            color:_currentTheme.cardColor,
            textColor:_currentTheme.textSelectionHandleColor,
            type:"",
            context:context,
            readonly:false,
            enabled:false,
            border:0
        ),
        textFieldWithTopLabel(
            textController: passwordRepeatController,
            name:"${getTranslated(context, 'repeat_password')}",
            color:_currentTheme.cardColor,
            textColor:_currentTheme.textSelectionHandleColor,
            type:"",
            context:context,
            readonly:false,
            enabled:false,
            border:0
        ),
        SizedBox(height: 15,),
        InkWell(
          onTap: () async{
            if(passwordRepeatController.text == passwordController.text){
              if(
                  nameController.text!="" &&
                  surnameController.text!="" &&
                  emailController.text!="" &&
                  passwordController.text!=""
              ){

                _auth.register(
                  name: nameController.text,
                  surname: surnameController.text,
                  username: emailController.text,
                  password: passwordController.text,

                );

              }else{
                await locator<DialogService>().showDialog(
                    title: "unlem",
                    description: "Lütfen boşlukları doldurun",
                    buttonTitle: "Tamam"
                );
              }
            }else{
              await locator<DialogService>().showDialog(
                  title: "unlem",
                  description: "Şifreler eşleşmiyo",
                  buttonTitle: "Tamam"
              );
            }


          },
          child: Container(
            height: 45,
            width: MediaQuery.of(context).size.width * 0.95,
            margin: EdgeInsets.all(20),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF26B13C),
                    Color(0xFF2EC546),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.all(
                    Radius.circular(50)
                )
            ),
            child: Center(
              child: Text('${getTranslated(context, 'REGISTER')}',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold
                ),
              ),
            ),
          ),
        ),
        SizedBox(
          height: 35,
        ),
      ],

    );
  }
}

