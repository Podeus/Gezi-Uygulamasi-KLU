class TestModel {
  final String title;
  final String description;
  final String imagePath;

  TestModel(this.title, this.description, this.imagePath);
}
