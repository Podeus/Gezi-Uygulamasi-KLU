class HomeModel {
  final String title;
  final String description;
  final String imagePath;

  HomeModel(this.title, this.description, this.imagePath);
}
