import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/core/components/drawers/customDrawer/customDrawer.dart';
import 'package:flutter_base/core/components/forms/dropdownFieldWithList.dart';
import 'package:flutter_base/core/components/list-view/general_list_view.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/view/basic/home/viewModel/home_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';

import '../../../../core/services/view/dialog_service.dart';
import '../../../../core/services/view/navigation_service.dart';
enum AppState {
  free,
  picked,
  cropped,
}
class HomeView extends StatefulWidget {
  HomeView();
  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final DialogService _dialogService = locator<DialogService>();
  TextEditingController titleController = TextEditingController();
  TextEditingController descController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController workHourController = TextEditingController();
  TextEditingController imageController = TextEditingController();
  String selectedItem = "Parklar";

  String file;
  bool status = false;
  String base64Image;
  String errMessage = 'Error Uploading Image';
  var decodedBytes;

  File imageFile;
  AppState state;
  @override
  void initState() {
    state = AppState.free;
    super.initState();
  }
  @override
  void dispose() {
    super.dispose();
  }
  void _openImagePicker() async {
    final XFile imageFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    // var image = await ImagePicker.pickImage(source: ImageSource.camera);
    if (imageFile != null) {
      setState(() {
        // attachment = image.path;
        file = imageFile.path;
        base64Image = base64Encode(File(imageFile.path).readAsBytesSync());
        state = AppState.cropped;
      });
      // _cropImage();
      _dialogService.showToast(title: "${getTranslated(context, 'image_selected')}",location:"",color:Colors.green);
    }
  }
  void _clearImage() {
    imageFile = null;
    setState(() {
      state = AppState.free;
      decodedBytes = null;
      base64Image = null;
    });
    _dialogService.showToast(title: "${getTranslated(context, 'image_cleared')}",location:"",color:Colors.green);
  }
  void func2(value){

    print(selectedItem);
    selectedItem = value;
    setState(() {
      selectedItem = value;
    });
    print(value);
    print(selectedItem);
  }

  Widget forminside({controller,name}){
    return Container(
      width: MediaQuery.of(context).size.width * 0.95,
      height: 45,
      margin: EdgeInsets.only(top:5),
      padding: EdgeInsets.only(
          top: 4,left: 16, right: 16, bottom: 4
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFFf2f2f2),
            Color(0xFFf2f2f2),
          ],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.all(
            Radius.circular(50)
        ),
        // color: _currentTheme.secondaryHeaderColor,
        boxShadow: [
          BoxShadow(
              color: Colors.black12,
              blurRadius: 1
          )
        ],
      ),
      child: TextField(
        textAlign: TextAlign.left,
        controller: controller,
        // onChanged: (text) {
        //   print("username: $text");
        // },
        decoration: InputDecoration(
          border: InputBorder.none,
          // icon: Icon(Icons.person,
          //   color: Color(0xFF26B13C),
          // ),
          hintStyle: TextStyle(color: Colors.black),
          hintText: '$name',
        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    final Widget imageWidget = InkWell(
      onTap: () {
        if (state == AppState.free){
          print("AppState.free");
          // _pickImage();
          _openImagePicker();
        }else if (state == AppState.picked){
          print("AppState.picked");
          // _cropImage();
          _clearImage();
        }else if (state == AppState.cropped){
          print("AppState.cropped");
          _clearImage();
        }else{
          print("state ${state}");
          _dialogService.showToast(title: "${getTranslated(context, 'image_ready')}",location:"",color:Colors.green);
        }
      },
      child: Container(
          width: MediaQuery.of(context).size.width * 0.75,
          height: 45,
          margin: EdgeInsets.only(top: 10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                  Radius.circular(50)
              ),
              gradient: LinearGradient(
                colors: [
                  Color(0xFFf2f2f2),
                  Color(0xFFf2f2f2),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: [
                BoxShadow(
                    color: Colors.black12,
                    blurRadius: 5
                )
              ]
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(width: 15,),
              base64Image!=null ? Icon(Icons.close,size: 25,color: Colors.red,):Icon(Icons.attach_file_rounded,size: 25,color: Color(0xff262626),),
              SizedBox(width: 15,),
              Text(base64Image!=null ? "${getTranslated(context, 'My_Profile_Photo_passive')}" :  "${getTranslated(context, 'upload_file')}",style:TextStyle(fontSize: 16,color: Color(0xff262626))),
            ],
          )
      ),
    );

    mydialog(model)async {
      return await locator<DialogService>().showDialog(
          title: "İnternet Sorunu!",
          description: "İnternete bağlı değilsiniz, lütfen bağlantınızı kontrol edip tekrar deneyiniz.",
          buttonTitle: "Tamam",
          customWidget : Container(
            child: Column(
              children: [
                forminside(name:"Başlık", controller:titleController),
                forminside(name:"İçerik", controller:descController),
                forminside(name:"Ücret", controller:priceController),
                forminside(name:"Çalışma Saatleri", controller:workHourController),
                forminside(name:"Resim url", controller:imageController),
                Container(
                    margin: EdgeInsets.only(top: 10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(20)
                        ),
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFFf2f2f2),
                            Color(0xFFf2f2f2),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 5
                          )
                        ]
                    ),
                    height: 45,
                    width: MediaQuery.of(context).size.width * 0.75,
                    // margin: EdgeInsets.only(left:5),
                    child:
                    DropdownFieldWithList(
                      selectedItem:selectedItem,
                      dropdownMenuItems: [
                        "Parklar","Kütüphaneler","Tarihi Yerler","Oteller",
                        "Marketler","İbadet Yerleri","Otoparklar"
                      ].map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child:new Row(
                              children:[
                                Container(
                                  height: 45,
                                  padding:new EdgeInsets.only(top:10.0,left:10.0,right:15.0),
                                  decoration: BoxDecoration(
                                    // color: dropdownValue == 2 ? Colors.white : Colors.black12,
                                  ),
                                  child: Column(
                                    children: [
                                      Padding(
                                          padding:new EdgeInsets.only(top:5.0,left: 10),
                                          child: Center(
                                            child: Text(
                                              value,
                                              style:TextStyle(fontSize: 16,color: Color(0xff262626)),
                                              textAlign: TextAlign.center,
                                            ),
                                          )
                                      ),
                                    ],
                                  ),
                                ),
                              ]
                          ),
                        );
                      }).toList(),
                      onChanged:(String value) async{
                        await func2(value);
                        Navigator.of(context, rootNavigator: true).pop();
                        mydialog(model);
                      },
                      // onChanged:(String newvalue) {
                      //     selectedItem=newvalue;
                      //     setState(() {
                      //       selectedItem = newvalue;
                      //     });
                      // },
                    )
                ),
                // imageWidget,
                SizedBox(height: 15,),
                InkWell(
                  onTap: () {
                    print("kaydet");
                    if(
                    (titleController.text == "" || titleController.text == null) ||
                        (descController.text == "" || descController.text == null) ||
                        (imageController.text == "" || imageController.text == null) ||
                        (selectedItem == "" || selectedItem == null)
                    ){
                      locator<DialogService>().showToast(title: "Boşlukları doldurunuz",location:"ortada",color:Colors.black);
                    }else{
                      model.yeniYerEkle(
                        title: titleController.text,
                        desc:descController.text,
                        price:priceController.text,
                        work_hour:workHourController.text,
                        // image:base64,
                        // image:"https://i.picsum.photos/id/655/200/200.jpg?hmac=skyBShySCLoGXt4Gy91C5mmi2yQeWaqtypiJFwTKM4M",
                        image:imageController.text,
                        category:selectedItem,
                      );
                      setState(() {
                        titleController.text = "";
                        descController.text = "";
                        priceController.text = "";
                        workHourController.text = "";
                        workHourController.text = "";
                        imageController.text = "";
                      });
                      Navigator.of(context, rootNavigator: true).pop();
                    }
                  },
                  child: Container(
                      width: MediaQuery.of(context).size.width * 0.75,
                      height: 45,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.red
                      ),
                      child: Center(
                        child: Text("Kaydet",style: TextStyle(color: Colors.white),),
                      )
                  ),
                )
              ],
            ),
          )
      );
    }
    return ViewModelBuilder<HomeViewModel>.reactive(
        viewModelBuilder: () => HomeViewModel(),
        onModelReady: (model) {
          model.checkUserAction();
        },
        builder: (context, model, child) =>
            WillPopScope(
                onWillPop: () async => false,
                child:Scaffold(
                  // floatingActionButton: FloatingActionButton(
                  //   onPressed: () async{
                  //     // StatefulBuilder(
                  //     //   builder: (context, setState) => AlertDialog(
                  //     //     title: Text("Change Status"),
                  //     //     content: Container(
                  //     //       padding: EdgeInsets.symmetric(horizontal: 8.0),
                  //     //       decoration: BoxDecoration(
                  //     //           border: Border.all(color: Colors.grey, width: 1),
                  //     //           borderRadius: BorderRadius.circular(5)),
                  //     //       child: DropdownButtonHideUnderline(
                  //     //         child: DropdownButton(
                  //     //             hint: Text('Choose'),
                  //     //             onChanged: (String changedValue) {
                  //     //               setState(() {
                  //     //                 selectedItem = changedValue;
                  //     //                 print(selectedItem);
                  //     //               });
                  //     //             },
                  //     //             value: selectedItem,
                  //     //             items: <String>[
                  //     //               'None',
                  //     //               'Chocolate',
                  //     //               'Vanilla',
                  //     //               'ButterCream'
                  //     //             ].map((String value) {
                  //     //               return new DropdownMenuItem<String>(
                  //     //                 value: value,
                  //     //                 child: new Text(value),
                  //     //               );
                  //     //             }).toList()),
                  //     //       ),
                  //     //     ),
                  //     //
                  //     //   ),
                  //     // );
                  //     setState(() {
                  //       titleController.text = "";
                  //       descController.text = "";
                  //       priceController.text = "";
                  //       workHourController.text = "";
                  //       imageController.text = "";
                  //     });
                  //     mydialog(model);
                  //   },
                  //   child: Icon(Icons.add),
                  // ),
                    appBar: BaseAppBar(
                      title: Text(" "),
                      // image: Image.asset("asset/image/logo.png",height: 30,),
                      appBar: AppBar(),
                      backgroundColor: _currentTheme.backgroundColor,
                      leading: (Navigator.canPop(context) ? IconButton(
                        icon: Icon(Icons.menu, color: _currentTheme.textSelectionColor),
                        onPressed: () => _scaffoldKey.currentState.openDrawer(),
                      ) : null),
                      widgets : <Widget>[

                      ],
                    ),
                    key: _scaffoldKey,
                    drawer: customDrawer("HomeView"),
                    backgroundColor: _currentTheme.backgroundColor,
                    body: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 5.0),
                            Container(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.only(left:18,right: 18),
                                child: Text(
                                  'Merhaba, ${model.name !=null ? model.name : "..."}',
                                  style: TextStyle(
                                      color: _currentTheme.textSelectionColor,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 30),
                                )
                            ),
                            SizedBox(height: 20),
                            // TitleSection()
                            Container(
                              margin: EdgeInsets.only(left: 15,bottom: 15),
                              child: Text("İstanbul Kategorileri"),
                            ),
                            Container(
                              height: MediaQuery.of(context).size.height * 0.35,
                              child: CategoriesListView(
                                itemCount: 7,
                                onListItem: [
                                  {"id":"1","name":"Parklar"},
                                  {"id":"2","name":"Kütüphaneler"},
                                  {"id":"3","name":"Tarihi Yerler"},
                                  {"id":"4","name":"Oteller"},
                                  {"id":"5","name":"Marketler"},
                                  {"id":"6","name":"İbadet Yerleri"},
                                  {"id":"7","name":"Otoparklar"},
                                ],
                                scroll: true,
                                onClickAction: (id,name) {
                                  locator<NavigationService>().navigateTo(routes.categoryRoute,arguments: {"id":id,"name":name});
                                },
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 10),
                              child: Text("Favoriler",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w700),),
                            ),
                            Container(
                              height: 200,
                              child: HorizontalProductListView(
                                itemCount: model.favori_yerler.length > 0 ? model.favori_yerler.length: 0,
                                onListItem: model.favori_yerler.length > 0 ? model.favori_yerler: [],
                                scroll: true,

                              ),
                            )
                          ],
                        )
                    )
                )
            )
    );
  }
}
class HorizontalProductListView extends StatelessWidget {
  final int itemCount;
  final int currentIndex;
  final bool scroll;
  final List onListItem;

  const HorizontalProductListView({Key key,
    this.itemCount,
    this.onListItem,
    this.currentIndex,
    this.scroll,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      shrinkWrap: true,
      padding:  EdgeInsets.only(top: 10,bottom: 10),
      itemBuilder: (context, index) => buildCard(context, index),
    );
  }

  Widget buildCard(BuildContext context, int index) {
    return Container(
        child: Row(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            GestureDetector(
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Container(
                    margin:EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      // gradient: LinearGradient(
                      //   colors: [
                      //     Color(0xFF000000),
                      //     Color(0xFF000000),
                      //   ],
                      //   begin: Alignment.centerLeft,
                      //   end: Alignment.centerRight,
                      // ),
                      image: onListItem[index]["image"] !=null ? DecorationImage(
                        fit: BoxFit.cover,
                        image:  NetworkImage(onListItem[index]["image"]) ,
                      ) : null,
                      border: Border.all(
                          color: Colors.white,
                          width: 1.0
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(15.0),
                      ),
                    ),
                    width: 60,
                    height: 60,
                    // child: Center(
                    //   child: Text(
                    //     "Nike",
                    //     style: TextStyle(
                    //         fontSize: 20,fontWeight: FontWeight.w700,color: Colors.white
                    //     ),
                    //   ),
                    // )
                  ),
                  Container(
                    margin:EdgeInsets.only(right: 15,top:15),
                    // width: MediaQuery.of(context).size.width * 0.2,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        new Padding(
                          padding: new EdgeInsets.only(
                              left: 0.0,
                              right: 0.0,
                              bottom: 8.0,
                              top: 5.0),
                          child: new Text(
                            onListItem[index]["title"],
                            textAlign: TextAlign.left,
                            style: new TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        new Padding(
                          padding: new EdgeInsets.only(
                              left: 0.0,
                              right: 4.0,
                              bottom: 4.0),
                          child: new Text(
                            "${onListItem[index]["point"]} Puan",
                            style: new TextStyle(
                              color: Colors.grey[500],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              onTap: () {
                print("go to detail page 2");
                locator<NavigationService>().navigateTo(routes.productViewRoute,arguments: {"id":onListItem[index]["id"]});
                // _modalBottomSheetMenu(context);
              },
            ),
          ],
        )
    );
  }

}
class CategoriesListView extends StatelessWidget {
  final int itemCount;
  final bool scroll;
  final List onListItem;
  final Function onClickAction;

  const CategoriesListView({Key key,
    this.itemCount,
    this.onListItem,
    this.scroll,
    this.onClickAction,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return onListItem.length > 0 ? GridView.count(
      // Create a grid with 2 columns. If you change the scrollDirection to
      // horizontal, this produces 2 rows.
      crossAxisCount: 3,
      childAspectRatio: 1.5,
      mainAxisSpacing: 0.0,
      crossAxisSpacing: 1.0,
      // Generate 100 widgets that display their index in the List.
      children: List.generate(itemCount, (index) => buildCard(context, index)),
    ):
    Container(
      child: Center(
        child: new Padding(
          padding: new EdgeInsets.all(50.0),
          child: Text("Henüz bulunmamaktadır"),
        ),
      ),
    );
  }
  Widget buildCard(BuildContext context, int index) {
    return Container(
        // padding: new EdgeInsets.all(.0),
        margin: new EdgeInsets.all(3.0),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(
            Radius.circular(15.0),
          ),
          // color: Colors.black,
          // border: Border.all(
          //     color: Colors.white,
          //     width: 1.0
          // ),
        ),
        child: new Column(
          children: [
            InkWell(
              onTap: () {
                onClickAction(onListItem[index]["id"],onListItem[index]["name"]);
              },
              child: Container(
                  // width: MediaQuery.of(context).size.width * 0.9,
                  height: 75,
                  decoration: BoxDecoration(
                    // image: DecorationImage(
                    //   image: NetworkImage(onListItem[index]["image"]),
                    //   fit: BoxFit.contain,
                    // ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 2,
                        offset: Offset(0, 2), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text("${onListItem[index]["name"]}"),
                  )
              ),
            ),
          ],
        )
    );
  }
}
class radioModel {
  String name;
  int index;
  radioModel({this.name, this.index});
}