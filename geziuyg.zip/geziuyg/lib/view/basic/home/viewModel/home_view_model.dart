import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:flutter_base/core/base/viewmodel/base_view_model.dart';
import 'package:flutter_base/core/services/view/firebase_service.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/authentication_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
class HomeViewModel extends BaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final DialogService _dialogService = locator<DialogService>();
  // final PushNotificationService _pushNotificationService = locator<PushNotificationService>();
  final Api _Api = locator<Api>();
  final FirebaseService _FirebaseServiceApi = locator<FirebaseService>();

  String _name;
  String get name => _name;

  Future<dynamic> checkUserAction() async {
    print("clicked checkUserAction");
    setBusy(true);
    // await Future.delayed(Duration(seconds: 1));
    // var _prefs = await SharedPreferences.getInstance();
    // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.checkUserAction();
    final response = await _FirebaseServiceApi.UserVerify();
    if (response ==null) {
      print('checkUserAction Error ${response}');
      // setErrorMessage('Error has occured with the login');
    } else {
      var user = FirebaseAuth.instance.currentUser;
      FirebaseFirestore db = FirebaseFirestore.instance;
      var userRef = FirebaseFirestore.instance
          .collection('users')
          .where('user_id', isEqualTo: user.uid)
      ;
      var roomSnapshot = await userRef.get().then((QuerySnapshot querySnapshot) {
        var newname = "";
        querySnapshot.docs.forEach((doc) {
          newname = "${doc["name"]}";
        });
      print("newname ${newname}");
        _name = "${newname}";
        notifyListeners();
      });
    }
    getir_yerler(null, null, "1");
    setBusy(false);
  }
  List _yerler = List();
  List get yerler => _yerler;
  List _favori_yerler = List();
  List get favori_yerler => _favori_yerler;
  List _yorumlar = List();
  List get yorumlar => _yorumlar;
  getir_yerler(String order,id,favoriler) async {
    setBusy(true);
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var yerlerRef;
    _favori_yerler = [];
    notifyListeners();
    if (favoriler == "1"){
      yerlerRef = FirebaseFirestore.instance
          .collection('yerler')
          .where('point', isGreaterThanOrEqualTo: 4)
      ;
      var roomSnapshot = await yerlerRef.get().then((QuerySnapshot querySnapshot) {
        querySnapshot.docs.forEach((doc) {
          var newvalue = {
            "id":"${doc["id"]}",
            "title":"${doc["title"]}",
            "desc":"${doc["desc"]}",
            "price":"${doc["price"]}",
            "work_hour":"${doc["work_hour"]}",
            "category":"${doc["category"]}",
            "image":"${doc["image"]}",
            "point":"${doc["point"]}",
          };
          _favori_yerler.add(newvalue);
          notifyListeners();
        });
      });
    }else{

      if(id!=null) {
        yerlerRef = FirebaseFirestore.instance
            .collection('yerler')
            .where('id', isEqualTo: id)
        ;
      }else{
        yerlerRef = FirebaseFirestore.instance
            .collection('yerler')
            .where('category', isEqualTo: order)
        ;
      }
      var roomSnapshot = await yerlerRef.get().then((QuerySnapshot querySnapshot) {
        querySnapshot.docs.forEach((doc) {
          var newvalue = {
            "id":"${doc["id"]}",
            "title":"${doc["title"]}",
            "desc":"${doc["desc"]}",
            "price":"${doc["price"]}",
            "work_hour":"${doc["work_hour"]}",
            "category":"${doc["category"]}",
            "image":"${doc["image"]}",
            "point":"${doc["point"]}",
          };
          _yerler.add(newvalue);
          notifyListeners();
        });
      });
    }
    setBusy(false);
  }
  getir_yorumlar(String order) async {
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var yerlerRef = FirebaseFirestore.instance
        .collection('yorumlar')
        .where('product_id',isEqualTo: order)
      ;
    _yorumlar = [];
    notifyListeners();
    var roomSnapshot = await yerlerRef.get().then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        var newvalue = {
              "id":"${doc["id"]}",
              'user': "${doc["user"]}",
              'user_name': "${doc["user_name"]}",
              'comment': "${doc["comment"]}",
              'product_id': "${doc["product_id"]}",
              'date': "${doc["date"]}",
              'status': "${doc["status"]}",
            };
        _yorumlar.add(newvalue);
        notifyListeners();
      });
    });
  }
  Future<dynamic> yeniYerEkle(
      {title,desc,price,image,work_hour,category}
      ) async {
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var sonuc = _FirebaseServiceApi.yeniYerEkle(
      title: title,
      desc:desc,
      price:price,
      work_hour:work_hour,
      image:image,
      category:category,
    );
    getir_yerler(null, null, "1");
  }
  Future<dynamic> yeniYorumEkle(
      {comment,product_id}
      ) async {
    // var user = FirebaseAuth.instance.currentUser;
    // FirebaseFirestore db = FirebaseFirestore.instance;
    var sonuc = _FirebaseServiceApi.yeniYorumEkle(
      comment: comment,
      product_id:product_id
    );
    getir_yorumlar(product_id);
  }

  Future<dynamic> yeniPuanEkle(
      {rating,product_id}
      ) async {
    var user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore db = FirebaseFirestore.instance;
    var sonuc = _FirebaseServiceApi.yeniPuanEkle(
        rating: rating,
      product_id:product_id
    );
  }
  double _rating;
  double get rating => _rating;
  void setRating(double value) {
    _rating = value;
    notifyListeners();
  }
}
