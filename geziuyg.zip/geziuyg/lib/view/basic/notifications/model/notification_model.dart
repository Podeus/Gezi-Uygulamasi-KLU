class NotificationModel {
  final String title;
  final String description;
  final String imagePath;

  NotificationModel(this.title, this.description, this.imagePath);
}
