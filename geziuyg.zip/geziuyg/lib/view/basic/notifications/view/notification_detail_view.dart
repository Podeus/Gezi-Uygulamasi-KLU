import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/button/icon_text_button.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/view/basic/notifications/viewModel/notification_view_model.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
class NotificationDetailView extends StatelessWidget {
  String id;
  String jsonencode;
  NotificationDetailView({this.id,this.jsonencode});

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    // var new_data = json.decode(this.jsonencode);
    // print("new_data ${new_data}");
    print("id ${id}");
    return ViewModelBuilder<NotificationViewModel>.reactive(
        viewModelBuilder: () => NotificationViewModel(),
        onModelReady: (model) => model.getStoreFromId(id),
        builder: (context, model, child) =>
            Scaffold(
                appBar: BaseAppBar(
                  title: Text("Notifications"),
                  backgroundColor: _currentTheme.backgroundColor,
                  appBar: AppBar(),
                  leading: (Navigator.canPop(context) ? IconButton(
                    icon: Icon(Icons.arrow_back_ios, color: _currentTheme.textSelectionColor),
                    onPressed: () => locator<NavigationService>().goBack(),
                  ) : null),
                ),
                backgroundColor: _currentTheme.backgroundColor,
                body: SafeArea(
                  child: SingleChildScrollView(
                      child:
                      Column(
                        children: <Widget>[
                          Container(
                            child: Stack(
                              alignment: Alignment.topLeft,
                              // overflow: Overflow.visible,
                              children: <Widget>[
                                Row(children: <Widget>[
                                  Expanded(child:
                                  Container(
                                    height: 175.0,
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            fit: BoxFit.cover,
                                            image: model.busy == true ? AssetImage("asset/image/onboard1.png") : model.store_detail !=null ? NetworkImage("https://edumag.net/wp-content/uploads/2015/10/mcdonalds.jpg") : AssetImage("asset/image/onboard1.png")
                                        )
                                    ),
                                  )
                                    ,)
                                ],
                                ),
                                Positioned(
                                  top: 140.0,
                                  left: 10.0,
                                  child: Container(
                                    height: 75.0,
                                    width: 177.0,
                                    decoration: BoxDecoration(
                                      // shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: model.busy == true ? AssetImage("asset/image/onboard1.png") : model.store_detail !=null ? NetworkImage(model.store_detail[0]["logo"]) : AssetImage("asset/image/onboard1.png"),
                                      ),
                                      border: Border.all(
                                          color: Colors.white,
                                          width: 1.0
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(20.0),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 150.0,
                                  right: 10.0,
                                  child: Container(
                                      height: 50.0,
                                      width: 100.0,
                                      decoration: BoxDecoration(
                                        // shape: BoxShape.circle,
                                        border: Border.all(
                                            color: Colors.white,
                                            width: 3.0
                                        ),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(15.0),
                                        ),
                                      ),
                                      child: IconTextButton(
                                        onPressed: () {
                                          model.StoresFavoriteAction(id);
                                          print('model.store_detail[0]["favorite"] ${model.store_detail[0]}');
                                        },
                                        icon: Icon(Icons.bookmark_border),
                                        sizedboxWidth: 10,
                                        fontSize: 16,
                                        text: "Save",
                                        backgroundColor: _currentTheme.cardColor,
                                        buttonColor: _currentTheme.secondaryHeaderColor,
                                        textColor: _currentTheme.textSelectionColor,
                                        favorite: model.favorite !=null ? model.favorite : "0",
                                      )
                                  ),
                                ),
                              ],
                            )
                            ,
                          ),
                          Container(
                            alignment: Alignment.bottomCenter,
                            height: 90.0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(width: 15.0,),
                                Text("${model.store_detail !=null ? model.store_detail[0]["name"] : ""}", style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 28.0,
                                    color: _currentTheme.textSelectionColor
                                ),),
                              ],
                            ),
                          ),
                          SizedBox(height: 12.0,),
                          Container(
                            alignment: Alignment.centerLeft,
                            height: 70.0,
                            child: ListView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemCount: model.categories !=null ? model.categories.length : 0,
                              padding: new EdgeInsets.all(15.0),
                              itemBuilder: (context, index) {
                                return
                                  Container(
                                    margin: const EdgeInsets.only(left: 10.0),
                                    height: 65,
                                    child: FlatButton(
                                        padding: EdgeInsets.only(left:10,right:10),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12.0),
                                          // side: BorderSide(color: Color(0xFFF2F2F2))
                                        ),
                                        onPressed: () {
                                          print("go to category page");
                                          // locator<NavigationService>().navigateTo(routes.homeRoute);
                                          locator<NavigationService>().navigateTo(routes.categoryRoute,arguments: {"detail":json.encode(model.categories[index])});
                                        },
                                        color:_currentTheme.secondaryHeaderColor,
                                        textColor: _currentTheme.textSelectionColor,
                                        child: Text(
                                            "${model.categories[index]["name"]}",
                                            style: TextStyle(fontSize: 14,color:Colors.black)
                                        ),
                                    ),
                                  );
                              },
                            ),
                          ),
                          Divider(),
                          Container(
                            padding: EdgeInsets.only(left:16,right: 16,top:15),
                            child: TextField(
                              onTap: () {
                                print("here");
                                // Navigator.of(context).push(MaterialPageRoute(builder: (context) => SearchDetailView()));
                                // searchController.clear();
                              },
                              onChanged: (string){
                                // Navigator.of(context).push(MaterialPageRoute(builder: (context) => SearchDetailView()));
                                // searchController.clear();
                              },
                              controller: searchController,
                              autofocus: false,
                              style: TextStyle(fontSize: 17.0, color: _currentTheme.secondaryHeaderColor),
                              decoration: InputDecoration(
                                suffixIcon: Icon(Icons.search,color: Color(0xFF808080),),
                                filled: true,
                                fillColor: _currentTheme.secondaryHeaderColor,
                                hintText: 'Search',
                                hintStyle: TextStyle(color:Color(0xFF808080)),
                                contentPadding:
                                const EdgeInsets.only(left: 14.0, bottom: 12.0, top: 12.0),
                                focusedBorder: OutlineInputBorder(
                                  // borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                enabledBorder: UnderlineInputBorder(
                                  // borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 12.0,),
                          Container(
                              width: MediaQuery.of(context).size.width,
                              // height: MediaQuery.of(context).size.height,
                              color: _currentTheme.canvasColor,
                              padding: EdgeInsets.all(5),
                              child: Column(
                                children: [
                                  SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          padding: EdgeInsets.only(left:13),
                                          child: Text(
                                            'Most Popular',
                                            style: TextStyle(
                                                color: _currentTheme.textSelectionColor,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 16),
                                          )
                                      ),
                                      GestureDetector(
                                        onTap : (){
                                          print("show more");
                                        },
                                        child: Container(
                                            alignment: Alignment.topRight,
                                            padding: EdgeInsets.only(right:13),
                                            child: Row(
                                              children: [
                                                Text(
                                                  'Show More',
                                                  style: TextStyle(
                                                      color: Color(0xFF26B13C),
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 16),
                                                ),
                                                Icon(Icons.arrow_forward_ios,size: 20,color: Color(0xFF26B13C),)
                                              ],
                                            )
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              )
                          ),
                          // Container(
                          //   color: _currentTheme.canvasColor,
                          //   child: CouponsListView(
                          //     onListItem:model.coupons !=null ? model.coupons : [],
                          //     backgroundColor: _currentTheme.cardColor,
                          //     textColor: _currentTheme.textSelectionColor,
                          //     buttonColor: _currentTheme.secondaryHeaderColor,
                          //     itemCount: model.coupons !=null ? model.coupons.length : 0,
                          //     scroll:false,
                          //     onClickAction: (ids,used) => {model.CouponsFavoriteAction(ids,used),model.getStoreFromId(id)},
                          //   ),
                          // )
                        ],
                      )
                  ),
                )
            )
    );
  }
}
// class TitleSection extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final _themeManager = Provider.of<ThemeManager>(context, listen: true);
//     final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
//     return CouponsListView(
//       onListItem:[
//         {
//           "discountText":"10%",
//           "title":"-10% when buying minimum 2 products",
//           "company":"Nike",
//           "companyLogo":"https://dbfukofby5ycr.cloudfront.net/m34/1/1536/d1908/70f22-i.png",
//           "usesText":"999999",
//           "lastuseText":"13 min",
//           "code": "F8GRE9SDF",
//         },
//         {
//           "discountText":"30%",
//           "title":"-30% when buying minimum 2 products",
//           "company":"Adidas",
//           "companyLogo":"https://dbfukofby5ycr.cloudfront.net/m34/1/1536/d1908/70f22-i.png",
//           "usesText":"999999",
//           "lastuseText":"14 min",
//           "code": "F8GRE9SDC",
//         },
//         {
//           "discountText":"50%",
//           "title":"-50% when buying minimum 2 products",
//           "company":"McDonald",
//           "companyLogo":"https://dbfukofby5ycr.cloudfront.net/m34/1/1536/d1908/70f22-i.png",
//           "usesText":"999999",
//           "lastuseText":"11 min",
//           "code": "F8GRE9SDS",
//         }
//       ],
//       backgroundColor: _currentTheme.cardColor,
//       textColor: _currentTheme.textSelectionColor,
//       buttonColor: _currentTheme.secondaryHeaderColor,
//       itemCount:3,
//       scroll:false,
//     );
//
//   }
// }
