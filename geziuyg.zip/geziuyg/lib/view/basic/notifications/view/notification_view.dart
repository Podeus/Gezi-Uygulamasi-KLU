import 'dart:convert';
import 'dart:convert';
import 'package:flutter_base/core/components/list-view/notification_list_view.dart';
import 'package:flutter_base/view/basic/notifications/viewModel/notification_view_model.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';

import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/constants/api_urls.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/view/basic/home/viewModel/home_view_model.dart';
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
// import 'package:json_dynamic_widget/json_dynamic_widget.dart';

import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';

class NotificationView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return ViewModelBuilder<NotificationViewModel>.reactive(
        viewModelBuilder: () => NotificationViewModel(),
        onModelReady: (model) => model.getAllNotifications(),
        builder: (context, model, child) =>
        new Scaffold(
          appBar: BaseAppBar(
            title: Text("Notifications"),
            backgroundColor: _currentTheme.backgroundColor,
            appBar: AppBar(),
            leading: (Navigator.canPop(context) ? IconButton(
              icon: Icon(Icons.arrow_back_ios, color: _currentTheme.textSelectionColor),
              onPressed: () => locator<NavigationService>().goBack(),
            ) : null),
          ),
          backgroundColor: _currentTheme.canvasColor,
          body: Container(
              child:  Center(
                  child: model.all_noti !=null ? Column(
                    children: [
                      SizedBox(
                        height: 15,
                      ),
                      TitleSection()
                    ],
                  ) :
                  model.busy == true ? Center(child: CircularProgressIndicator()) :
                  Column(
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 3.0,right:3.0,top:10.0,bottom: 10.0),
                          child: Image.asset("onboard1.png",width: 250)
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 3.0,right:3.0,top:10.0,bottom: 10.0),
                        child: Text("hello .....",style: TextStyle(fontSize: 15),textAlign: TextAlign.left),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 3.0,right:3.0,top:30.0,bottom: 10.0),
                        child: Text("You_have_no_notifications_yet",style: TextStyle(fontSize: 15),textAlign: TextAlign.left),
                      ),
                    ],
                  )
              )
          ),
          // bottomNavigationBar : Container(
          //   child:createDrawerFooter(onTap: () =>Navigator.pushNamed(context, routes.homeRoute),
          //   ),
          // )
        )
    );
  }
}

class TitleSection extends ViewModelWidget<NotificationViewModel> {
  @override
  Widget build(BuildContext context, NotificationViewModel model) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return Expanded(
      child: RefreshIndicator(
        onRefresh: () => model.getAllNotifications(),
        child:model.busy == true
            ? Center(child: const CircularProgressIndicator())
            : model.all_noti.length > 0
            ? NotificationListView(
                onListItem:model.all_noti,
                itemCount:model.all_noti.length,
                scroll:true,
                backgroundColor:_currentTheme.cardColor,
                textColor:_currentTheme.textSelectionColor,
                canvasColor:_currentTheme.canvasColor,
              )
            : Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.notifications,
                  color: Colors.grey, size: 50.0),
              Text(
                "You have no notifications yet",
                style: new TextStyle(
                    fontSize: 15.0, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}






