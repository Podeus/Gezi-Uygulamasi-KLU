import 'dart:convert';
import 'package:flutter_base/core/base/viewmodel/base_view_model.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:flutter_base/core/base/model/base_model.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/authentication_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter_base/core/services/model/sms.dart';
// import 'package:flutter_base/core/resources/pages/phoneverifyPage.dart';


class NotificationViewModel extends BaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final DialogService _dialogService = locator<DialogService>();
  // final PushNotificationService _pushNotificationService = locator<PushNotificationService>();
  // final PushNotificationService _pushNotificationService = locator<PushNotificationService>();
  final Api _Api = locator<Api>();
  List<dynamic> _all_noti;
  List<dynamic> get all_noti => _all_noti;
  List<dynamic> _store_detail;
  List<dynamic> get store_detail => _store_detail;
  List<dynamic> _categories;
  List<dynamic> get categories => _categories;
  List<dynamic> _coupons;
  List<dynamic> get coupons => _coupons;
  String _favorite = "0";
  String get favorite => _favorite;

  Future<dynamic> getAllNotifications() async {
    // print("clicked getAllNotifications");
    // setBusy(true);
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.getAllNotifications();
    // if (response ==null) {
    //   print('get_free_vehicles Error ${response}');
    //   // setErrorMessage('Error has occured with the login');
    // } else {
    //   print('get_free_vehicles response ${response}');
    //   _all_noti = response["data"];
    //   notifyListeners();
    //   // return _all_noti;
    // }
    // setBusy(false);
  }

  Future<dynamic> getStoreFromId(String id) async {
    // print("clicked getStoreFromId");
    // setBusy(true);
    // final response = await _Api.getStoreFromId(id);
    // if (response ==null) {
    //   print('getStoreFromId Error ${response}');
    //   // setErrorMessage('Error has occured with the login');
    // } else {
    //   print('getStoreFromId response ${response["data"]}');
    //
    //   _store_detail = response["data"];
    //   if(_store_detail !=null){
    //     _favorite = _store_detail[0]["favorite"];
    //   }
    //   _categories = response["categories"];
    //   _coupons = response["coupons"];
    //   notifyListeners();
    //
    //   await Future.delayed(Duration(seconds: 1));
    //   // return _all_noti;
    // }
    // setBusy(false);
  }

  Future<dynamic> StoresFavoriteAction(String id) async {
    // print("clicked CouponsFavoriteAction");
    // setBusy(true);
    // // var _prefs = await SharedPreferences.getInstance();
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.StoresFavoriteAction(id);
    // if (response ==null) {
    //   print('StoresFavoriteAction Error ${response}');
    //   // setErrorMessage('Error has occured with the login');
    // } else {
    //   print('StoresFavoriteAction response ${response}');
    //   // _user = json.decode(response["user"]);
    //   // _coupons = response["data"];
    //   print('response["favorite"] ${response["content"]["favorite"]}');
    //   if(response!=null){
    //     _favorite = response["content"]["favorite"];
    //   }
    //   notifyListeners();
    // }
    // setBusy(false);
  }

  Future<dynamic> CouponsFavoriteAction(String id,String used) async {
    // print("clicked CouponsFavoriteAction");
    // setBusy(true);
    // // var _prefs = await SharedPreferences.getInstance();
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.CouponsFavoriteAction(id,used);
    // if (response ==null) {
    //   print('CouponsFavoriteAction Error ${response}');
    //   // setErrorMessage('Error has occured with the login');
    // } else {
    //   print('CouponsFavoriteAction response ${response}');
    //   // _user = json.decode(response["user"]);
    //   // _coupons = response["data"];
    //   // notifyListeners();
    // }
    // setBusy(false);
  }

}
