class SettingsModel {
  final String title;
  final String description;
  final String imagePath;

  SettingsModel(this.title, this.description, this.imagePath);
}
