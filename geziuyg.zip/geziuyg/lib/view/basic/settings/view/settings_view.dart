import 'dart:math';
import 'dart:io' as io;
import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/core/components/customSwitch/customSwitch.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/view/basic/settings/viewModel/settings_view_model.dart';
// import 'package:persist_theme/persist_theme.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';

import '../../../../core/generated/localization/language_constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import "package:flutter_base/core/components/string/string_extension.dart";
import 'package:url_launcher/url_launcher.dart';
class SettingsView extends StatefulWidget {
  @override
  _SettingsViewState createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    // Theme.of(context).textTheme.headline;
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    print("_themeManager.themeDataIndex ${_themeManager.themeDataIndex}");
    // final _currentTheme = _themeManager.currentTheme;
    _launchURL(url) async {
      // const url = 'https://twitter.com/';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }
    return ViewModelBuilder<SettingsViewModel>.reactive(
        viewModelBuilder: () => SettingsViewModel(),
        onModelReady: (model) => model.checkUserAction(),
        builder: (context, model, child) =>
            Scaffold(
                appBar: BaseAppBar(
                  title: Text('${getTranslated(context, 'settings')}',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w700,color: _currentTheme.textSelectionColor),),
                  // image: Image.asset("asset/image/logo.png",height: 30,),
                  appBar: AppBar(),
                  backgroundColor:Color(0xffe6e6e6),
                  leading: (Navigator.canPop(context) ? IconButton(
                    icon: FaIcon(
                      FontAwesomeIcons.longArrowAltLeft,
                      color: Colors.black,
                      size: 25,
                    ),
                    onPressed: () => locator<NavigationService>().goBack(),
                  ) : null),
                ),
                // key: _scaffoldKey,
                // drawer: standartDrawer("SettingsView"),
                backgroundColor: _currentTheme.backgroundColor,
                body: Container(
                  padding: EdgeInsets.zero,
                  color: _currentTheme.backgroundColor,
                  child: ListView(
                    children: [
                      // DarkModeSwitch(),
                      SizedBox(height: 15,),
                      createDrawerBodyItem(
                        // image: "asset/image/kisisel.png",
                        icon:  Icon(
                          Icons.notifications,
                          color: _currentTheme.primaryColorLight,
                          size: 23.0,
                        ),
                        iconColor: Color(0xFF26B13C),
                        textColor: _currentTheme.textSelectionColor,
                        swichWidget:true,
                        onChanged: (){
                          model.toggleNotifications();
                          model.setSettings(model.darkmodeBool == true ? "1" : "0",model.notiBool == true ? "1" : "0");
                        },
                        onChangedvalue: model.notiBool,
                        topMargin: 15,
                        text: '${getTranslated(context, 'notifications')}',
                        // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                        topPadding: 0,
                        bottomDivider:false,
                        bottombigDivider:true,
                        active: 0,
                      ),

                      createDrawerBodyItem(
                        icon:  Icon(
                          Icons.device_thermostat,
                          color: _themeManager.themeDataIndex == 1 ? _currentTheme.primaryColorDark : _currentTheme.primaryColorLight,
                          size: 23.0,
                        ),
                        swichWidget:true,
                        onChanged: (){
                          model.toggleDarkmode();
                          print("_themeManager.themeDataIndex ${_themeManager.themeDataIndex}");
                          var theme = AppTheme.values[_themeManager.themeDataIndex == 1 ? 0 : 1];
                          _themeManager.setTheme(theme);
                          model.setSettings(model.darkmodeBool == true ? "1" : "0",model.notiBool == true ? "1" : "0");
                        },
                        onChangedvalue: model.darkmodeBool,
                        iconColor: _themeManager.themeDataIndex == 0 ? _currentTheme.primaryColorDark : _currentTheme.primaryColorLight,
                        textColor: _currentTheme.textSelectionColor,
                        topMargin: 5,
                        text: '${getTranslated(context, 'Dark_mode')}',
                        // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                        topPadding: 0,
                        bottomDivider:false,
                        bottombigDivider:true,
                        active: 0,
                      ),

                      createDrawerBodyItem(
                        icon:  Icon(
                          Icons.language,
                          color: _currentTheme.primaryColorLight,
                          size: 23.0,
                        ),
                        iconColor: Color(0xFFF39B34),
                        textColor: _currentTheme.textSelectionColor,
                        topMargin: 5,
                        text: '${getTranslated(context, 'change_language').capitalize()}',
                        onTap: () =>
                            locator<NavigationService>().navigateTo(routes.languageRoute),
                        // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                        topPadding: 0,
                        bottomDivider:false,
                        bottombigDivider:true,
                        active: 0,
                      ),

                      io.Platform.isAndroid ? createDrawerBodyItem(
                        icon:  Icon(
                          Icons.star,
                          color: _currentTheme.primaryColorLight,
                          size: 23.0,
                        ),
                        iconColor: Color(0xFFF39B34),
                        textColor: _currentTheme.textSelectionColor,
                        topMargin: 5,
                        text: '${getTranslated(context, 'Rate_App')}',
                        onTap: () =>
                            _launchURL("https://play.google.com/store/apps/details?id=com.mimikgroup.visualartsinfluencer"),
                        // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                        topPadding: 0,
                        bottomDivider:false,
                        bottombigDivider:true,
                        active: 0,
                      )  : Container(),

                      createDrawerBodyItem(
                        icon:  Icon(
                          Icons.send,
                          color: _themeManager.themeDataIndex == 0 ? _currentTheme.primaryColorDark : _currentTheme.primaryColorLight,
                          size: 23.0,
                        ),
                        iconColor: _themeManager.themeDataIndex == 0 ? Color(0xFFE6E6E6) : _currentTheme.primaryColorDark,
                        textColor: _currentTheme.textSelectionColor,
                        topMargin: 5,
                        text: '${getTranslated(context, 'Send_Feedback')}',
                        // onTap: () =>
                        //     locator<NavigationService>().navigateTo(routes.contactRoute,arguments: {"store":"15"}),
                        // leftMargin: widget.currentPage =="HomeView" ? 0 : 0,
                        topPadding: 0,
                        bottomDivider:false,
                        bottombigDivider:true,
                        active: 0,
                      )
                    ],
                  ),
                )
            )
    );
  }
}

Widget createDrawerBodyItem({
  Icon icon,
  String image,
  String image2,
  String text,
  GestureTapCallback onTap,
  GestureTapCallback onChanged,
  bool onChangedvalue,
  double leftPadding,
  double topPadding,
  double topMargin,
  double leftMargin,
  int active,
  Color textColor,
  bool bottomDivider,
  bool bottombigDivider,
  Color iconColor,
  bool swichWidget,
}) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
          height: 35.0,
          padding: EdgeInsets.only(left:5),
          // margin: EdgeInsets.only(top:topMargin !=null ? topMargin : 0,left:leftMargin !=null ? leftMargin : 0,right:leftMargin !=null ? leftMargin : 0),
          child:InkWell(
            onTap: onTap,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                image !=null ?
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                  child: Image.asset(image,height: 20,),
                ) : Container(),
                icon !=null ?
                Container(
                  padding: EdgeInsets.only(left: 0.0,top:0,bottom:1),
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: iconColor,
                  ),
                  child: icon,
                ) : Text(""),
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                  child: Text(text,style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,color: textColor !=null ? textColor : Colors.black),),
                ),
                image2 !=null ?
                Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:0),
                  child: Image.asset(image2,height: 20,),
                ) : Container(),
                Expanded(child: Container()),
                swichWidget == true ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      onTap: onChanged,
                      behavior: HitTestBehavior.translucent,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            CustomSwitch(
                                switched : onChangedvalue
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ) : Padding(
                  padding: EdgeInsets.only(left: 8.0,top:0,bottom:1),
                  child: Icon(Icons.arrow_forward_ios_rounded,color: textColor,),
                ),
              ],
            ),
          )
        // decoration: active==1 ? new BoxDecoration(
        //     color: Color(0xFF26B13C),
        //     borderRadius: new BorderRadius.only(
        //         topLeft: const Radius.circular(5.0),
        //         topRight: const Radius.circular(5.0),
        //         bottomLeft: const Radius.circular(5.0),
        //         bottomRight: const Radius.circular(5.0)
        //     )
        // ) : null,
      ),
      bottomDivider == true ? Container(
        height: 1,
        padding: EdgeInsets.only(left:0,right: 25,top:5,bottom: 5),
        margin: EdgeInsets.only(bottom: 5),
        child: Divider(
          height:2,
          thickness: 1,
          color: Color(0xFFe6e6e6),
        ),
      ) : Container(),
      bottombigDivider == true ? Container(
          height: 15,
          width: double.infinity,
          color: Color(0xFFf2f2f2),
          child: Text("")
      ) : Container(),
    ],
  );
}

