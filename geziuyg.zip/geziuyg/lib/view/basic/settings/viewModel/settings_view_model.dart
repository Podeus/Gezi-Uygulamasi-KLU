import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:flutter_base/core/base/viewmodel/base_view_model.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/authentication_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsViewModel extends BaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final DialogService _dialogService = locator<DialogService>();
  // final PushNotificationService _pushNotificationService = locator<PushNotificationService>();
  final Api _Api = locator<Api>();
  bool _notiBool = false;
  bool _darkmodeBool = false;
  bool get notiBool => _notiBool;
  bool get darkmodeBool => _darkmodeBool;
  String _content;
  String get content => _content;
  Future<dynamic> get_content(String id) async {
    // setBusy(true);
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.get_content(id);
    // if (response ==null) {
    //   setErrorMessage('Error has occured with the login');
    // } else {
    //   _content = json.encode(response["data"]["content"]);
    //   print("_content ${_content}");
    //   // await _dialogService.showDialog(
    //   //     title: response["title"],
    //   //     description: response["message"],
    //   //     buttonTitle: "Tamam"
    //   // );
    //   // return json.encode(response["data"]);
    // }
    // //
    // setBusy(false);
  }
  Future setSettings(String darkMode,String notification) async {
    // setBusy(true);
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.setSettings(darkMode,notification);
    //
    // print(" response setSettings içince ${response.toString()}");
    // if(response != null){
    //   // setErrorMessage(null);
    //   print("setSettings geldi");
    //   print(response);
    //   notifyListeners();
    //
    //   // _navigationService.navigateTo(routes.loginRoute);
    // }
    // setBusy(false);
  }
  Future<dynamic> checkUserAction() async {
    setBusy(true);
    await Future.delayed(Duration(seconds: 1));

    try {
      // final response = await _Api.checkUserAction();
      // var _prefs = await SharedPreferences.getInstance();
      // print("checkUserAction ${response}");
      // print("checkUserAction ${response["access_token"]}");
      // if (response ==null) {
      //   setErrorMessage('Error has occured with the login');
      // } else {
      //   if(response["login"]==true) {
      //     setLogin(true);
      //     // _prefs.setString("user_name", response["user"]["full_name"]);
      //     _darkmodeBool = response["device"]["dark_mode"] =="1" ? true : false;
      //     _notiBool = response["device"]["notification"] =="1" ? true : false;
      //     notifyListeners();
      //   }
      // }
    } catch (e) {
      print(e);
    }
    //
    setBusy(false);
  }

  Future<void> toggleDarkmode() {
    _darkmodeBool = !_darkmodeBool;
    notifyListeners();
  }
  Future<void> toggleNotifications() {
    _notiBool = !_notiBool;
    notifyListeners();
  }

}
