class SplashModel {
  final String title;
  final String description;
  final String imagePath;

  SplashModel(this.title, this.description, this.imagePath);
}
