import 'package:flutter/material.dart';
import 'package:flutter_base/core/constants/api_urls.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/locator.dart';
import 'package:provider/provider.dart';
// import 'package:flutter_base/src/models/auth.dart';
import 'package:flutter_base/view/authenticate/login/viewModel/login_view_model.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
class SplashView extends StatefulWidget {
  @override
  _SplashViewState createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("Splash Page");
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    print("_themeManager.themeDataIndex ${_themeManager.themeDataIndex}");
    return ViewModelBuilder<LoginViewModel>.reactive(
        viewModelBuilder: () => LoginViewModel(),
        onModelReady: (model) {
          model.checkUserAction();
          print("model.darkmodeBool ${model.darkmodeBool}");
          var theme = AppTheme.values[model.darkmodeBool ==true ? 1 : 0];
          _themeManager.setTheme(theme);
        },
        builder: (context, model, child) =>
            WillPopScope(
                onWillPop: () async => false,
                child:
                Scaffold(
                  backgroundColor: _currentTheme.backgroundColor,
                  body: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text("Gezi Uygulaması"),
                        SizedBox(height: 25,),
                        CircularProgressIndicator(backgroundColor: Color(0xFF26B13C),),
                      ],
                    ),
                  )
                )
            )
    );

  }
}