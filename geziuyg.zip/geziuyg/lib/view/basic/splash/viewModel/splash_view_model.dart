import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter_base/core/locator.dart';
import 'package:flutter_base/core/services/view/api.dart';
import 'package:flutter_base/core/base/viewmodel/base_view_model.dart';
import 'package:flutter_base/core/services/view/navigation_service.dart';
import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/services/view/authentication_service.dart';
// import 'package:flutter_base/core/services/view/push_notification_services.dart';
import 'package:flutter_base/core/services/view/dialog_service.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashViewModel extends BaseViewModel {
  final NavigationService _navigationService = locator<NavigationService>();
  final DialogService _dialogService = locator<DialogService>();
  // final PushNotificationService _pushNotificationService = locator<PushNotificationService>();
  final Api _Api = locator<Api>();

  List<dynamic> _all_noti;

  List<dynamic> get all_noti => _all_noti;

  Future<dynamic> getAllNotifications() async {
    // print("clicked getAllNotifications");
    // setBusy(true);
    // await Future.delayed(Duration(seconds: 1));
    // // await Future.delayed(Duration(seconds: 1));
    // final response = await _Api.getAllNotifications();
    // if (response ==null) {
    //   print('get_free_vehicles Error ${response}');
    //   // setErrorMessage('Error has occured with the login');
    // } else {
    //   print('get_free_vehicles response ${response}');
    //   _all_noti = response["data"];
    //   notifyListeners();
    //   return _all_noti;
    // }
    // setBusy(false);
  }

}
