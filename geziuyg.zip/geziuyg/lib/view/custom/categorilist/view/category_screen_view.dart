import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/forms/textFieldwithTopFieldName.dart';

import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';

import '../../../../core/locator.dart';
import '../../../../core/services/view/navigation_service.dart';
import '../../../basic/home/viewModel/home_view_model.dart';
import 'package:stacked/stacked.dart';
class CategoryScreenView extends StatefulWidget {
  String id;
  String name;
  CategoryScreenView({this.id,this.name});
  @override
  _CategoryScreenViewState createState() => _CategoryScreenViewState();
}

class _CategoryScreenViewState extends State<CategoryScreenView> {
  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return ViewModelBuilder<HomeViewModel>.reactive(
        viewModelBuilder: () => HomeViewModel(),
        onModelReady: (model) {
          // model.checkUserAction();
          model.getir_yerler(widget.name,null,null);
        },
        builder: (context, model, child) =>
            Scaffold(
                appBar: BaseAppBar(
                  title: Text("${widget.name}",style: TextStyle(color: Colors.black),),
                  // image: Image.asset("asset/image/logo.png",height: 30,),
                  appBar: AppBar(),
                  backgroundColor: _currentTheme.backgroundColor,
                  leading: (Navigator.canPop(context) ? IconButton(
                    icon: Icon(Icons.arrow_back, color: _currentTheme.textSelectionColor),
                    onPressed: () => Navigator.pop(context),
                  ) : null),
                  widgets : <Widget>[
                  ],
                ),
                body: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          height: MediaQuery.of(context).size.height * 0.85,
                          child: GeneralListView(
                            itemCount: model.yerler.length > 0 ? model.yerler.length : 0,
                            onListItem: model.yerler.length > 0 ? model.yerler : [],
                            onClickAction: (id,title,desc,image,price,work_hour,point){
                                locator<NavigationService>().navigateTo(routes.productViewRoute,arguments: {
                                  "id":id,
                                });
                            },
                          ),
                        )
                      ],
                    )
                )
            )
    );
  }
}

class GeneralListView extends StatelessWidget {
  final int itemCount;
  final bool scroll;
  final List onListItem;
  final Function onClickAction;

  const GeneralListView({Key key,
    this.itemCount,
    this.onListItem,
    this.scroll,
    this.onClickAction,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return onListItem.length > 0 ? ListView.builder(
      physics: scroll== false ? NeverScrollableScrollPhysics() : null,
      shrinkWrap: true,
      // scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      padding: new EdgeInsets.all(0.0),
      itemBuilder: (context, index) => buildCard(context, index),
    ) : Container(
      child: Center(
        child: Text("İçerik yok "),
      ),
    );
  }
  Widget buildCard(BuildContext context, int index) {
    return InkWell(
      onTap: (){
        onClickAction(
          onListItem[index]["id"],
          onListItem[index]["title"],
          onListItem[index]["desc"],
          onListItem[index]["image"],
          onListItem[index]["price"],
          onListItem[index]["work_hour"],
          onListItem[index]["point"],
        );
      },
      child: Container(
        margin: EdgeInsets.all(10),
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          // image: DecorationImage(
          //   image: NetworkImage(onListItem[index]["image"]),
          //   fit: BoxFit.contain,
          // ),
          borderRadius: BorderRadius.all(Radius.circular(15)),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 2), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    // child: Image.asset("${onListItem[index]["image"]}",height: 50,width: 50,)
                    child: Image.network("${onListItem[index]["image"]}",height: 50,width: 50,fit: BoxFit.cover,)
                ),
                Container(
                  margin: EdgeInsets.only(left: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width:MediaQuery.of(context).size.width * 0.70,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("${onListItem[index]["title"]}"),
                            Text("Puan : ${onListItem[index]["point"]}"),
                          ],
                        ),
                      ),
                      Text("${onListItem[index]["desc"]}"),
                    ],
                  ),
                ),

              ],
            ),

            SizedBox(height: 15,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                onListItem[index]["price"] !=null && onListItem[index]["price"] !="" ? Text("Fiyat : ${onListItem[index]["price"]}") :Container(),
                Text("Çalışma saatler: ${onListItem[index]["work_hour"]}"),
              ],
            ),
            SizedBox(height: 5,),
          ],
        ),
      ),
    );
  }

}
