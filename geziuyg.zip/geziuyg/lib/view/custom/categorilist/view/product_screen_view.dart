import 'package:flutter/material.dart';
import 'package:flutter_base/core/components/forms/textFieldwithTopFieldName.dart';

import 'package:flutter_base/core/constants/route_paths.dart' as routes;
import 'package:flutter_base/core/components/appbar/baseAppbar.dart';
import 'package:flutter_base/core/generated/localization/language_constants.dart';
import 'package:flutter_base/core/init/notifier/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:flutter_base/core/init/theme/app_themes.dart';

import '../../../../core/locator.dart';
import '../../../../core/services/view/navigation_service.dart';
import '../../../basic/home/viewModel/home_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
class ProductScreenView extends StatefulWidget {
  String id;
  String title;
  String desc;
  String price;
  String image;
  String work_hour;
  String point;
  ProductScreenView({this.id,this.title,this.desc,this.price,this.image,this.work_hour,this.point});
  @override
  _ProductScreenViewState createState() => _ProductScreenViewState();
}

class _ProductScreenViewState extends State<ProductScreenView> {
  TextEditingController yorumController = TextEditingController();
  var title = "";
  var desc = "";
  var work_hour = "";
  var price = "";
  var image;
  var point = "";
  @override
  Widget build(BuildContext context) {
    final _themeManager = Provider.of<ThemeManager>(context, listen: true);
    final _currentTheme = appThemeData[AppTheme.values[_themeManager.themeDataIndex]];
    return ViewModelBuilder<HomeViewModel>.reactive(
        viewModelBuilder: () => HomeViewModel(),
        onModelReady: (model) {
          // model.checkUserAction();
          model.getir_yorumlar(widget.id);
          model.getir_yerler(null,widget.id,null);
        },
        builder: (context, model, child) {
          if(model.yerler.length > 0){
            title = model.yerler[0]["title"];
            desc = model.yerler[0]["desc"];
            price = model.yerler[0]["price"];
            work_hour = model.yerler[0]["work_hour"];
            image = model.yerler[0]["image"];
            point = model.yerler[0]["point"];
          }
          print("image : ${image}");
          return  Scaffold(
              appBar: BaseAppBar(
                title: Text("${title}",style: TextStyle(color: Colors.black),),
                // image: Image.asset("asset/image/logo.png",height: 30,),
                appBar: AppBar(),
                backgroundColor: _currentTheme.backgroundColor,
                leading: (Navigator.canPop(context) ? IconButton(
                  icon: Icon(Icons.arrow_back, color: _currentTheme.textSelectionColor),
                  onPressed: () => Navigator.pop(context),
                ) : null),
                widgets : <Widget>[
                ],
              ),
              body: model.busy ==true ? Container():SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height * .35,
                      color: Colors.grey,
                      padding: EdgeInsets.symmetric(vertical: 18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          image !=null || image !="" ? Image.network(
                            "${image}",
                            fit: BoxFit.contain,
                            color: Colors.grey,
                            colorBlendMode: BlendMode.multiply,
                            width: MediaQuery.of(context).size.width,
                            height: 200,
                          ) : Container(),
                          SizedBox(height: 18),
                          // Row(
                          //   mainAxisAlignment: MainAxisAlignment.center,
                          //   children: imagePreviews,
                          // ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width * 0.75,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${title}",
                                      style: Theme.of(context).textTheme.headline6,
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    price !=null ?Text(
                                      "Fiyat :${price}",
                                      style: Theme.of(context).textTheme.subtitle2.copyWith(
                                        color: Theme.of(context).colorScheme.secondary,
                                      ),
                                    ) : Container(),
                                  ],
                                ),
                              ),
                              Container(
                                child: Text("Puan :${point}"),
                              )
                            ],
                          ),
                          SizedBox(height: 12),
                          Text(
                            "Çalışma Saatleri :${work_hour}",
                            style: Theme.of(context).textTheme.subtitle2.copyWith(
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          SizedBox(height: 12),
                          Text(
                            "${desc}" ,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText2
                                .copyWith(height: 1.5),
                          ),
                          SizedBox(
                            height: 18,
                          ),

                          SizedBox(
                            height: 18,
                          ),

                          Container(
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.only(left: 0.0,top:0,bottom:0),
                              child:
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(child: Text("Puan Ver"),margin: EdgeInsets.only(left: 5),),
                                  Row(
                                    children: [
                                      Container(
                                        width:MediaQuery.of(context).size.width * 0.5,
                                        child: RatingBar.builder(
                                          itemSize: 35.0,
                                          initialRating: 0,
                                          minRating: 1,
                                          direction: Axis.horizontal,
                                          allowHalfRating: false,
                                          itemCount: 5,
                                          itemPadding: EdgeInsets.only(left:0),
                                          itemBuilder: (context, _) => Icon(
                                              Icons.star,
                                              color: Colors.yellow,
                                              size:10
                                          ),
                                          onRatingUpdate: (rating) {
                                            model.setRating(rating);
                                          },
                                        ),
                                      ),
                                      InkWell(
                                          onTap: () {
                                            model.yeniPuanEkle(
                                                rating: model.rating,product_id: widget.id
                                            );
                                          },
                                          child: Container(
                                            width: 85,
                                            child: Center(
                                              child: Text("Puan Gönder",style: TextStyle(fontSize: 15,color: Color(0xff808080),fontWeight: FontWeight.bold),),
                                            ),
                                          )
                                      )
                                    ],
                                  )
                                ],
                              )
                          ),
                          SizedBox(
                            height: 18,
                          ),
                          Text("veya"),
                          SizedBox(
                            height: 18,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width * 0.90,
                                height: 45,
                                padding: EdgeInsets.only(
                                    top: 0,right: 0, bottom: 0
                                ),
                                decoration: BoxDecoration(
                                  // borderRadius: BorderRadius.all(
                                  //     Radius.circular(10)
                                  // ),
                                  // color: Colors.white,
                                  // boxShadow: [
                                  //   BoxShadow(
                                  //       color: Colors.black12,
                                  //       blurRadius: 5
                                  //   )
                                  // ]
                                ),
                                child: TextField(
                                  // key: Key('__RIKEY2__${name}'),
                                  // autovalidate: false,
                                  controller: yorumController,


                                  // validator: (value){
                                  //   return value.length < 2 ? 'Name must be greater than two characters' : null;
                                  // },
                                  decoration: InputDecoration(
                                    border: UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey.withOpacity(0.5),
                                        width: 0.1,
                                        style: BorderStyle.solid,
                                      ),
                                    ),
                                    prefixText: "",
                                    suffixIcon:
                                    Container(
                                      // decoration: BoxDecoration(
                                      //   // border: Border.all(
                                      //   //     color: Color(0xFFFFBC00), //  0xFF0071BC
                                      //   //     width: 1.0
                                      //   // ),
                                      //   borderRadius: const BorderRadius.only(
                                      //     bottomRight: Radius.circular(10.0),
                                      //     topRight: Radius.circular(10.0),
                                      //   ),
                                      //   color: Color(0xffE6E6E6),
                                      // ),
                                        width: 65,
                                        child: InkWell(
                                          onTap: () {
                                            print("deneme");
                                            model.yeniYorumEkle(
                                                comment: yorumController.text,product_id: widget.id
                                            );
                                          },
                                          child: Center(
                                            child: Text("Gönder",style: TextStyle(fontSize: 15,color: Color(0xff808080),fontWeight: FontWeight.bold),),
                                          ),
                                        )
                                    ),
                                    // border: InputBorder.none,
                                    hintText: 'Yorum Yaz',
                                    hintStyle: TextStyle(color:Colors.grey),

                                    // labelText: 'Ad',
                                  ),
                                ),
                              ),
                              // Divider(
                              //   thickness: 0.5,
                              //   color: Theme.of(context).disabledColor,
                              // ),
                              SizedBox(
                                height: 20,
                              ),
                              //list comments
                              YorumListView(
                                itemCount: model.yorumlar.length > 0 ? model.yorumlar.length : 0,
                                onListItem: model.yorumlar.length > 0 ? model.yorumlar : [],
                                scroll: false,
                              ),
                              //child comment
                              //endchild comment
                              SizedBox(
                                height: 15,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )
          );
        }
    );
  }

}

class YorumListView extends StatelessWidget {
  final int itemCount;
  final bool scroll;
  final List onListItem;
  final Function onClickAction;

  const YorumListView({Key key,
    this.itemCount,
    this.onListItem,
    this.scroll,
    this.onClickAction,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return onListItem.length > 0 ? ListView.builder(
      physics: scroll== false ? NeverScrollableScrollPhysics() : null,
      shrinkWrap: true,
      // scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      padding: new EdgeInsets.all(0.0),
      itemBuilder: (context, index) => buildCard(context, index),
    ) : Container(
      child: Center(
        child: Text("Henüz Yorum Yok "),
      ),
    );
  }
  Widget buildCard(BuildContext context, int index) {
    // DateTime myDateTime = DateTime.parse(onListItem[index]["date"]);

    return Container(
      constraints: BoxConstraints(
        maxHeight: double.infinity,
      ),
      margin: EdgeInsets.only(right: 16, left: 16),
      child: ListView(
        padding: EdgeInsets.only(top: 20),
        shrinkWrap: true,
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text.rich(
                  TextSpan(
                    children: [
                      WidgetSpan(
                        child: Container(
                          margin: EdgeInsets.only(right: 8.0),
                          width: 20,
                          height: 20,
                          decoration: new BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            image: new DecorationImage(
                              image: AssetImage(
                                // ApiRoutes.postImageUrl + 'https://naijacrawl.com/logo/logo.webp',
                                'asset/images/calling_face.png',

                              ),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      TextSpan(
                        text: "${onListItem[index]["user_name"]}",
                        style: TextStyle(
                            fontSize: 16,
                            color: Theme.of(context).highlightColor),
                      ),
                    ],
                  ),
                ),
                Text(
                  "",
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            "${onListItem[index]["comment"]}",
            style: TextStyle(
                fontSize: 14, color: Theme.of(context).disabledColor),
            textAlign: TextAlign.left,
          ),
        ],
      ),
    );
  }

}
